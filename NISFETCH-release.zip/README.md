# NISFETCH v2.8.7 — Uptime Grammar Fix

Correct English singular/plural forms in Uptime: `1 hour` / `2 hours`, `1 min` / `2 mins`.

Built on v2.8.6 KDE Fast Path. All modules, logos, Tux default, and performance optimizations are preserved.

Install (no sudo):

```sh
unzip -o NISFETCH-v2.8.7-uptime-fix.zip -d nisfetch-build
cd nisfetch-build
sh install.sh
```
