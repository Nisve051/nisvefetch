#!/bin/sh
set -eu
cd "$(dirname "$0")"
if command -v cc >/dev/null 2>&1; then CC=cc; elif command -v clang >/dev/null 2>&1; then CC=clang; else echo 'Install gcc or clang first' >&2; exit 1; fi
"$CC" -std=c11 -O2 -Wall -Wextra -Werror nisfetch.c -o nisfetch.new -lm
if [ -n "${PREFIX:-}" ] && [ -d "${PREFIX}/bin" ]; then
  destination="${PREFIX}/bin"
else
  destination="${HOME}/.local/bin"
fi
mkdir -p "$destination"
if [ -f "$destination/nisfetch" ]; then
  cp "$destination/nisfetch" "$destination/nisfetch.backup"
fi
install -m 755 nisfetch.new "$destination/nisfetch"
rm -f nisfetch.new
printf 'Installed: %s/nisfetch\n' "$destination"
"$destination/nisfetch" --version
if [ "$destination" = "${HOME}/.local/bin" ]; then
  case ":${PATH}:" in *":${HOME}/.local/bin:"*) ;; *)
    printf 'To use command nisfetch, add this directory to PATH:\n  export PATH="$HOME/.local/bin:$PATH"\n'
    ;;
  esac
fi
