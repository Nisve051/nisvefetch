#define _XOPEN_SOURCE 700
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/statvfs.h>
#include <pwd.h>
#include <ctype.h>
#include <stdint.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <math.h>
#include <time.h>
#include <locale.h>
#include <wchar.h>
#include <limits.h>
#include <sys/statvfs.h>
#include <sys/stat.h>

#define R "\033[0m"
#define MAX_ROWS 128
#define C "\033[1;38;2;255;201;48m"
#define ACCENT "\033[1;38;2;255;224;113m"
#define SOFT "\033[1;38;2;228;231;236m"
#define MUTED "\033[38;2;155;160;171m"
#include "nis_tux.h"
#include "nis_distro_pixels.h"
/* Pixel-art scaling: integer nearest-neighbour, two vertical pixels per cell. */
static void tux_row_scaled(size_t row,int width,int height){
 for(int x=0;x<width;x++){
  size_t sx=(size_t)x*TUX_W/(size_t)width;
  size_t sy1=(size_t)(row*2)*TUX_H/(size_t)(height*2);
  size_t sy2=(size_t)(row*2+1)*TUX_H/(size_t)(height*2);
  if(sy1>=TUX_H)sy1=TUX_H-1;
  if(sy2>=TUX_H)sy2=TUX_H-1;
  const unsigned char *top=&tux_rgb[(sy1*TUX_W+sx)*3];
  const unsigned char *bottom=&tux_rgb[(sy2*TUX_W+sx)*3];
  printf("\033[38;2;%u;%u;%um\033[48;2;%u;%u;%um▀",top[0],top[1],top[2],bottom[0],bottom[1],bottom[2]);
 }
 fputs(R,stdout);
}

typedef struct {const char *name,*color;int height;const char *rows[8];} DistroLogo;
static const DistroLogo distro_logos[]={
 {"arch","#1793d1",7,{"       /\\       ","      /  \\      ","     /\\   \\     ","    /      \\    ","   /   ,,   \\   ","  /   |  |  -\\  "," /_-''    ''-_\\ "}},
 {"debian","#d70a53",7,{"    _____     ","   /  __ \\    ","  |  /    |   ","  |  \\___-    ","  -_          ","    --_       ",""}},
 {"ubuntu","#e95420",7,{"    .--.     ","  /  __  \\   "," |  (  )  |  ","  \\  --  /   ","    '--'     ","",""}},
 {"fedora","#51a2da",7,{"   ______    ","  / ____ \\   "," | |  __| |  "," | | |__  |  "," |  \\___| |  ","  \\______/   ",""}},
 {"manjaro","#35bf5c",7,{" |\\  | | | | "," | \\ | | | | "," |  \\| | | | "," | | | | | | "," |_| |_| |_| ","",""}},
 {"linuxmint","#87cf3e",7,{"  __________  "," /  ______  \\ "," | |  __  | | "," | | |  | | | "," | |_|  |_| | "," \\__________/ ",""}},
 {"opensuse","#73ba25",7,{"    _______   ","  /  ___  \\  "," /  /   \\  \\ "," | |  () | | "," \\  \\___/  / ","  \\_______/  ",""}},
 {"gentoo","#b7a2d3",7,{"   ______    ","  /  __  \\   "," /  /  \\  \\  "," | |   /  /  "," \\  \\__/  /  ","  \\______/   ",""}},
 {"alpine","#0d597f",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / /  \\ \\   ","  /_/    \\_\\  ","",""}},
 {"nixos","#7ebae4",7,{"  \\  /\\  /   ","   \\/  \\/    ","  /\\  /\\    "," /  \\/  \\   "," \\  /\\  /   ","  \\/  \\/    ",""}},
 {"android","#3ddc84",7,{"   /\\    /\\  ","  /  \\__/  \\ "," |  o    o | "," |          | "," |__________| ","  |  |  |  | ",""}},
 {"termux","#80cbc4",7,{"  __________ "," | >_       |"," |          |"," |__________|","","",""}},
 {"void","#478061",7,{"    ______    ","   / ____ \\   ","  | |    | |  ","  | |____| |  ","   \\______/   ","",""}},
 {"artix","#10a0cc",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / ____ \\   ","  /_/    \\_\\  ","",""}},
 {"endeavouros","#7f3fbf",7,{"       /\\     ","      /  \\    ","     / /\\ \\   ","    / /  \\ \\  ","   /_/____\\_\\ ","",""}},
 {"kali","#557c94",7,{"   __       ","  /  \\___   "," /  / __ \\  "," |  \\___/ / ","  \\______/  ","",""}},
 {"raspbian","#c51a4a",7,{"   .-''-.   ","  / .--. \\  "," | (____) | ","  \\ (__) /  ","   '----'   ","",""}},
 {"slackware","#526db0",7,{"   _______   ","  |   S   |  ","  |_______|  ","","","",""}},
 {"redhat","#ee0000",7,{"   _______   ","  /       \\  "," |  REDHAT  | ","  \\_______/  ","","",""}},
 {"popos","#48b9c7",7,{"  __________ "," |  POP!_   |"," |__________|","","","",""}},
};
static const DistroLogo *find_logo(const char *name){
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)
  if(!strcmp(name,distro_logos[i].name))return &distro_logos[i];
 return NULL;
}
static int distro_width(const DistroLogo *logo){
 int width=0;for(int i=0;i<logo->height;i++){int n=(int)strlen(logo->rows[i]);if(n>width)width=n;}
 return width;
}
static void distro_row(const DistroLogo *logo,int row,int width){
 unsigned int r=255,g=255,b=255;
 sscanf(logo->color+1,"%2x%2x%2x",&r,&g,&b);
 const char *line=logo->rows[row];int n=(int)strlen(line);
 printf("\033[1;38;2;%u;%u;%um",r,g,b);
 for(int i=0;i<width;i++)putchar(i<n?line[i]:' ');
 fputs(R,stdout);
}
static void list_logos(void){
 puts("tux (default)");
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)puts(distro_logos[i].name);
}

/* User-supplied logo artwork, same 58x72 pixel canvas as the default Tux. */
static const unsigned char *distro_pixels(const char *name){
 if(!strcmp(name,"arch"))return logo_arch;
 if(!strcmp(name,"debian"))return logo_debian;
 if(!strcmp(name,"fedora"))return logo_fedora;
 if(!strcmp(name,"popos"))return logo_popos;
 if(!strcmp(name,"kali"))return logo_kali;
 if(!strcmp(name,"linuxmint"))return logo_linuxmint;
 if(!strcmp(name,"redhat"))return logo_redhat;
 if(!strcmp(name,"gentoo"))return logo_gentoo;
 if(!strcmp(name,"opensuse"))return logo_opensuse;
 if(!strcmp(name,"slackware"))return logo_slackware;
 if(!strcmp(name,"alpine"))return logo_alpine;
 if(!strcmp(name,"void"))return logo_void;
 if(!strcmp(name,"manjaro"))return logo_manjaro;
 if(!strcmp(name,"nixos"))return logo_nixos;
 if(!strcmp(name,"android"))return logo_android;

 return NULL;
}
/* Truecolor upper/lower half-block renderer; alpha zero uses terminal default
   background, so the logo has no ugly opaque rectangle. */
static void pixel_logo_bounds(const unsigned char *img,int *top,int *bottom){
 int first=DISTRO_H,last=-1;
 for(int y=0;y<DISTRO_H;y++)
  for(int x=0;x<DISTRO_W;x++)
   if(img[(y*DISTRO_W+x)*4+3]>=96){
    if(y<first)first=y;
    if(y>last)last=y;
   }
 if(last<first){first=0;last=DISTRO_H-1;}
 *top=first;*bottom=last+1;
}
static void pixel_logo_row(const unsigned char *img,size_t row,int width,int height,int crop_top,int crop_bottom){
 for(int x=0;x<width;x++){
  size_t sx=(size_t)x*DISTRO_W/(size_t)width;
  size_t sy1=(size_t)crop_top+(size_t)(row*2)*(size_t)(crop_bottom-crop_top)/(size_t)(height*2);
  size_t sy2=(size_t)crop_top+(size_t)(row*2+1)*(size_t)(crop_bottom-crop_top)/(size_t)(height*2);
  if(sy1>=DISTRO_H)sy1=DISTRO_H-1;
  if(sy2>=DISTRO_H)sy2=DISTRO_H-1;
  const unsigned char *top=&img[(sy1*DISTRO_W+sx)*4];
  const unsigned char *bottom=&img[(sy2*DISTRO_W+sx)*4];
  /* Transparent pixels must be BLACK, not terminal default foreground.
     Otherwise an upper-half block paints white stripes in empty regions. */
  if(top[3]>=96)printf("\033[38;2;%u;%u;%um",top[0],top[1],top[2]);
  else fputs("\033[38;2;0;0;0m",stdout);
  if(bottom[3]>=96)printf("\033[48;2;%u;%u;%um",bottom[0],bottom[1],bottom[2]);
  else fputs("\033[48;2;0;0;0m",stdout);
  fputs("▀",stdout);
 }
 fputs(R,stdout);
}
/* Small JSONC reader: strings, booleans, numbers, arrays, objects, comments.
   Unknown keys are ignored; invalid config is reported, never executed. */
typedef struct {const char *p;int error;} Json;
static void jspace(Json *j){
 for(;;){while(isspace((unsigned char)*j->p))j->p++;
  if(j->p[0]=='/'&&j->p[1]=='/'){j->p+=2;while(*j->p&&*j->p!='\n')j->p++;continue;}
  if(j->p[0]=='/'&&j->p[1]=='*'){j->p+=2;while(*j->p&&!(j->p[0]=='*'&&j->p[1]=='/'))j->p++;if(*j->p)j->p+=2;else j->error=1;continue;}
  break;
 }
}
static int jstring(Json *j,char *out,size_t cap){
 jspace(j);if(*j->p!='"'){j->error=1;return 0;}j->p++;
 size_t n=0;
 while(*j->p&&*j->p!='"'){
  unsigned char c=(unsigned char)*j->p++;
  if(c=='\\'){c=(unsigned char)*j->p++;if(!c){j->error=1;return 0;}
   if(c=='n')c='\n';else if(c=='t')c='\t';else if(c=='r')c='\r';
   else if(c=='u'){/* Skip 4 hex digits; no unicode keys are needed. */
    for(int k=0;k<4;k++){if(!isxdigit((unsigned char)*j->p)){j->error=1;return 0;}j->p++;}
    c='?';
   }
  }
  if(n+1<cap)out[n++]=(char)c;else j->error=1;
 }
 if(*j->p!='"'){j->error=1;return 0;}j->p++;if(cap)out[n]=0;return !j->error;
}
static void jskip(Json *j,int depth){
 if(depth>32){j->error=1;return;}jspace(j);
 if(*j->p=='"'){char v[512];jstring(j,v,sizeof v);return;}
 if(*j->p=='{'||*j->p=='['){
  char end=*j->p++=='{'?'}':']';jspace(j);
  while(*j->p&&*j->p!=end&&!j->error){
   if(*j->p==','||*j->p==':'){j->p++;continue;}
   jskip(j,depth+1);jspace(j);
  }
  if(*j->p==end)j->p++;else j->error=1;return;
 }
 if(!*j->p){j->error=1;return;}
 while(*j->p&&!isspace((unsigned char)*j->p)&&*j->p!=','&&*j->p!=']'&&*j->p!='}')j->p++;
}
static int jkey(Json *j,char *key,size_t cap){
 jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}
 if(*j->p==','){j->p++;jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}}
 jstring(j,key,cap);jspace(j);if(*j->p==':')j->p++;else j->error=1;
 return !j->error;
}
static char cfg_order[8192]="";
static char cfg_logo_type[64]="tux";
static int cfg_logo=1,cfg_palette=1,cfg_auto=1,cfg_logo_width=0,cfg_gap=2;
static int cfg_key[3]={255,201,48},cfg_val[3]={228,231,236};
static void cfg_color(const char *v,int rgb[3]){
 if(strlen(v)!=7||v[0]!='#')return;
 unsigned int a,b,c;if(sscanf(v+1,"%2x%2x%2x",&a,&b,&c)==3){rgb[0]=(int)a;rgb[1]=(int)b;rgb[2]=(int)c;}
}
static void cfg_value(Json *j,char *v,size_t cap){
 jspace(j);if(*j->p=='"')jstring(j,v,cap);
 else {size_t n=0;while(*j->p&&*j->p!=','&&*j->p!='}'&&*j->p!=']'&&!isspace((unsigned char)*j->p)){
 if(n+1<cap)v[n++]=*j->p;
 j->p++;
 }v[n]=0;}
}
static void cfg_section(Json *j,const char *section){
 jspace(j);if(*j->p!='{'){j->error=1;return;}j->p++;
 char key[128],val[128];
 while(jkey(j,key,sizeof key)&&!j->error){
  if(*j->p=='{'||*j->p=='['){jskip(j,0);continue;}
  cfg_value(j,val,sizeof val);
  if(!strcmp(section,"logo")){
   if(!strcmp(key,"enabled"))cfg_logo=strcmp(val,"false")!=0;
   else if(!strcmp(key,"autoScale"))cfg_auto=strcmp(val,"false")!=0;
   else if(!strcmp(key,"width"))cfg_logo_width=atoi(val);
   else if(!strcmp(key,"type"))snprintf(cfg_logo_type,sizeof cfg_logo_type,"%.63s",val);
  }else if(!strcmp(section,"display")){
   if(!strcmp(key,"palette"))cfg_palette=strcmp(val,"false")!=0;
   else if(!strcmp(key,"gap"))cfg_gap=atoi(val);
   else if(!strcmp(key,"keyColor"))cfg_color(val,cfg_key);
   else if(!strcmp(key,"valueColor"))cfg_color(val,cfg_val);
  }
 }
}
static int cfg_parse(const char *source){
 Json j={source,0};jspace(&j);if(*j.p!='{')return 0;j.p++;
 char key[128];
 while(jkey(&j,key,sizeof key)&&!j.error){
  jspace(&j);
  if(!strcmp(key,"logo")||!strcmp(key,"display"))cfg_section(&j,key);
  else if(!strcmp(key,"modules")){
   if(*j.p!='['){j.error=1;break;}j.p++;
   cfg_order[0]=0;
   while(!j.error){
    jspace(&j);if(*j.p==']'){j.p++;break;}
    if(*j.p==','){j.p++;continue;}
    char name[128];if(!jstring(&j,name,sizeof name))break;
    size_t len=strlen(cfg_order),n=strlen(name);
    if(len+n+2>=sizeof cfg_order){j.error=1;break;}
    if(len)strcat(cfg_order,":");
    strcat(cfg_order,name);
   }
  }else jskip(&j,0);
 }
 jspace(&j);return !j.error&&!*j.p;
}
static int cfg_load(const char *path,int required){
 FILE *f=fopen(path,"rb");if(!f){if(required)fprintf(stderr,"Cannot open config: %s\n",path);return !required;}
 if(fseek(f,0,SEEK_END)){fclose(f);return 0;}
 long n=ftell(f);rewind(f);
 if(n<0||n>262144){fprintf(stderr,"Config too large: %s\n",path);fclose(f);return 0;}
 char *buf=malloc((size_t)n+1);if(!buf){fclose(f);return 0;}
 size_t got=fread(buf,1,(size_t)n,f);fclose(f);buf[got]=0;
 int ok=got==(size_t)n&&cfg_parse(buf);free(buf);
 if(!ok)fprintf(stderr,"Invalid JSONC config: %s\n",path);
 return ok;
}
static char info[MAX_ROWS][512];
static int ninfo=0;
static char info_id[MAX_ROWS][64];
#define LABEL_WIDTH 16

static const char *selected_modules=NULL;
static int module_enabled(const char *name){
 if(!selected_modules)return 1;
 const char *p=selected_modules;size_t n=strlen(name);
 while(*p){while(*p==':'||*p==' '||*p=='\n')p++;
  if(!strncmp(p,name,n)&&(p[n]==':'||p[n]==0||p[n]==' '||p[n]=='\n'))return 1;
  while(*p&&*p!=':'&&*p!='\n')p++;
 }
 return 0;
}
static const char *all_modules="title:separator:os:host:kernel:uptime:packages:display:desktop:wm:wmtheme:theme:plasmatheme:icons:font:cursor:session:terminal:cpu:gpu:memory:swap:disk:homedisk:localip:locale:board:bios:chassis:shell:processes:loadavg:datetime:timezone:hostname:architecture:cpucores:cpufreq:battery:brightness:bluetooth:network:diskusage:diskfilesystem:termux:androidversion:androidsdk:androidmanufacturer:androidmodel:androidsoc:bootid:virtualization:editor:users:language:distro:osversion:kernelversion:kernelarch:machineid:cpuvendor:cpumodel:cpubogomips:cpuload:memtotal:memavailable:swaptotal:swapfree:diskfree:disktotal:diskpercent:rootfs:mounts:interfaces:ipv4:ipv6:gateway:dns:username:uid:gid:home:path:shellversion:terminaltype:displayserver:sessiondesktop:xdgconfig:xdgcache:xdgdata:pid:parentpid:threads:systemd:init:cgroup:entropy:thermalzones:fans:batterycount:powerstate:androiddevice:androidboard:androidfingerprint:androidsecuritypatch:termuxprefix:termuxhome:timezoneoffset:epoch:week:dayofyear:bootdate:procversion:filesystems:environment";
static const char *module_names[]={"title","separator","os","host","kernel","uptime","packages","display","desktop","wm","wmtheme","theme","plasmatheme","icons","font","cursor","session","terminal","cpu","gpu","memory","swap","disk","homedisk","localip","locale","board","bios","chassis","shell","processes","loadavg","datetime","timezone","hostname","architecture","cpucores","cpufreq","battery","brightness","bluetooth","network","diskusage","diskfilesystem","termux","androidversion","androidsdk","androidmanufacturer","androidmodel","androidsoc","bootid","virtualization","editor","users","language","distro","osversion","kernelversion","kernelarch","machineid","cpuvendor","cpumodel","cpubogomips","cpuload","memtotal","memavailable","swaptotal","swapfree","diskfree","disktotal","diskpercent","rootfs","mounts","interfaces","ipv4","ipv6","gateway","dns","username","uid","gid","home","path","shellversion","terminaltype","displayserver","sessiondesktop","xdgconfig","xdgcache","xdgdata","pid","parentpid","threads","systemd","init","cgroup","entropy","thermalzones","fans","batterycount","powerstate","androiddevice","androidboard","androidfingerprint","androidsecuritypatch","termuxprefix","termuxhome","timezoneoffset","epoch","week","dayofyear","bootdate","procversion","filesystems","environment"};
static int valid_modules(const char *list){
 char buf[8192];snprintf(buf,sizeof buf,"%s",list);
 for(char *p=strtok(buf,": \t\r\n");p;p=strtok(NULL,": \t\r\n")){
  int found=0;
  for(size_t i=0;i<sizeof module_names/sizeof module_names[0];i++)if(!strcmp(p,module_names[i])){found=1;break;}
  if(!found){fprintf(stderr,"Unknown module: %s\n",p);return 0;}
 }
 return 1;
}
static void add(const char *label,const char *value) {
 if(ninfo>=MAX_ROWS)return;
 snprintf(info[ninfo],sizeof info[0],"\033[1;38;2;%d;%d;%dm%-*s" R "\033[38;2;%d;%d;%dm%s" R,
 cfg_key[0],cfg_key[1],cfg_key[2],LABEL_WIDTH,label,cfg_val[0],cfg_val[1],cfg_val[2],value&&*value?value:"Unknown");
 ninfo++;
}
static void add_module(const char *name,const char *label,const char *value){
 if(module_enabled(name)){int prev=ninfo;add(label,value);if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);}
}
static void trim(char *s){size_t n=strlen(s);while(n&&(s[n-1]=='\n'||s[n-1]=='\r'||isspace((unsigned char)s[n-1])))s[--n]=0;}
static int is_termux(void){
 const char *p=getenv("PREFIX");
 return (p&&strstr(p,"com.termux")) || access("/data/data/com.termux/files/usr",F_OK)==0;
}
static void property(const char *key,char *out,size_t cap){
 out[0]=0;
 if(!is_termux())return;
 char cmd[160];snprintf(cmd,sizeof cmd,"getprop %s 2>/dev/null",key);
 FILE *f=popen(cmd,"r");if(f){if(fgets(out,(int)cap,f))trim(out);pclose(f);}
}
static void motherboard(char *out,size_t cap){
 if(is_termux()){
  char model[256]="",brand[128]="";
  property("ro.product.model",model,sizeof model);
  property("ro.product.manufacturer",brand,sizeof brand);
  if(*model){snprintf(out,cap,"%s%s%s",brand,(*brand&&!strstr(model,brand))?" ":"",model);return;}
  snprintf(out,cap,"Android device");return;
 }
 char board[256]="",vendor[256]="",product[256]="";
 FILE *f=fopen("/sys/class/dmi/id/board_name","r");
 if(f){if(fgets(board,sizeof board,f))trim(board);fclose(f);}
 f=fopen("/sys/class/dmi/id/board_vendor","r");
 if(f){if(fgets(vendor,sizeof vendor,f))trim(vendor);fclose(f);}
 if(!*board||!strcmp(board,"Default string")||!strcmp(board,"To be filled by O.E.M.")||!strcmp(board,"Not Specified")){
  f=fopen("/sys/class/dmi/id/product_name","r");
  if(f){if(fgets(product,sizeof product,f))trim(product);fclose(f);}
  if(*product)snprintf(board,sizeof board,"%s",product);
 }
 if(!*board){snprintf(out,cap,"Unknown motherboard");return;}
 if(*vendor && !strstr(board,vendor))snprintf(out,cap,"%s %s",vendor,board);
 else snprintf(out,cap,"%s",board);
}
static void osname(char *out,size_t cap){
 if(is_termux()){
  char ver[80]="";property("ro.build.version.release",ver,sizeof ver);
  snprintf(out,cap,"Android%s%s (Termux)",*ver?" ":"",ver);return;
 }
 snprintf(out,cap,"Linux"); FILE *f=fopen("/etc/os-release","r");if(!f)return;
 char *line=NULL;size_t sz=0;
 while(getline(&line,&sz,f)>0){if(strncmp(line,"PRETTY_NAME=",12)==0){char *v=line+12;trim(v);if(*v=='\"'){v++;char *end=strrchr(v,'\"');if(end)*end=0;}snprintf(out,cap,"%s",v);break;}}
 free(line);fclose(f);
}
static void cpuinfo(char *out,size_t cap){
 if(is_termux()){
  property("ro.soc.model",out,cap);
  if(!*out)property("ro.board.platform",out,cap);
  if(*out)return;
 }
 snprintf(out,cap,"Unknown");FILE *f=fopen("/proc/cpuinfo","r");if(!f)return;
 char line[512];while(fgets(line,sizeof line,f)){if(!strncmp(line,"model name",10)||!strncmp(line,"Hardware",8)){
 char *v=strchr(line,':');if(v){v++;while(isspace((unsigned char)*v))v++;trim(v);snprintf(out,cap,"%s",v);break;}}}fclose(f);
}

static unsigned long long read_khz(const char *path){
 FILE *f=fopen(path,"r");unsigned long long v=0;
 if(f){if(fscanf(f,"%llu",&v)!=1)v=0;fclose(f);}return v;
}
static void cpu_max_frequency(char *cpu,size_t cap){
 unsigned long long best=0;
 DIR *d=opendir("/sys/devices/system/cpu/cpufreq");
 if(d){struct dirent *e;
  while((e=readdir(d))){
   if(strncmp(e->d_name,"policy",6))continue;
   char path[512];
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/cpuinfo_max_freq",e->d_name);
   unsigned long long v=read_khz(path);
   if(!v){snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/scaling_max_freq",e->d_name);v=read_khz(path);}
   if(v>best)best=v;
  }
  closedir(d);
 }
 if(!best)best=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
 if(!best)return;
 size_t n=strlen(cpu);
 if(n+24<cap)snprintf(cpu+n,cap-n," @ %.2f GHz",best/1000000.0);
}
static void terminal_name(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Termux");return;}
 /* TERM describes capabilities, not the terminal emulator. */
 const char *v=getenv("KONSOLE_VERSION");
 if(v&&*v){snprintf(out,cap,"Konsole");return;}
 v=getenv("KITTY_WINDOW_ID");if(v&&*v){snprintf(out,cap,"kitty");return;}
 v=getenv("WEZTERM_PANE");if(v&&*v){snprintf(out,cap,"WezTerm");return;}
 v=getenv("ALACRITTY_WINDOW_ID");if(v&&*v){snprintf(out,cap,"Alacritty");return;}
 v=getenv("GHOSTTY_RESOURCES_DIR");if(v&&*v){snprintf(out,cap,"Ghostty");return;}
 v=getenv("WT_SESSION");if(v&&*v){snprintf(out,cap,"Windows Terminal");return;}
 v=getenv("TERM_PROGRAM");
 if(v&&*v && strcmp(v,"vscode")!=0){snprintf(out,cap,"%s",v);return;}
 if(v&&strcmp(v,"vscode")==0){snprintf(out,cap,"VS Code");return;}
 /* Walk process ancestry: shell -> terminal (also works when env is absent). */
 pid_t pid=getppid();
 for(int i=0;i<12 && pid>1;i++){
  char path[96],comm[128]="",statline[2048];
  snprintf(path,sizeof path,"/proc/%ld/comm",(long)pid);
  FILE *f=fopen(path,"r");
  if(f){if(fgets(comm,sizeof comm,f))trim(comm);fclose(f);}
  const char *name=NULL;
  if(strstr(comm,"konsole"))name="Konsole";
  else if(strstr(comm,"kitty"))name="kitty";
  else if(strstr(comm,"alacritty"))name="Alacritty";
  else if(strstr(comm,"wezterm"))name="WezTerm";
  else if(strstr(comm,"gnome-terminal"))name="GNOME Terminal";
  else if(strstr(comm,"ghostty"))name="Ghostty";
  else if(strstr(comm,"xfce4-terminal"))name="Xfce Terminal";
  else if(strstr(comm,"foot"))name="foot";
  else if(strstr(comm,"tilix"))name="Tilix";
  else if(strstr(comm,"terminator"))name="Terminator";
  else if(strstr(comm,"xterm"))name="xterm";
  if(name){snprintf(out,cap,"%s",name);return;}
  snprintf(path,sizeof path,"/proc/%ld/stat",(long)pid);
  f=fopen(path,"r");if(!f)break;
  if(!fgets(statline,sizeof statline,f)){fclose(f);break;}fclose(f);
  char *p=strrchr(statline,')');if(!p)break;
  char state;long ppid=0;
  if(sscanf(p+1," %c %ld",&state,&ppid)!=2)break;
  if(ppid<=1||ppid==pid)break;
  pid=(pid_t)ppid;
 }
 const char *term=getenv("TERM");snprintf(out,cap,"%s",term&&*term?term:"Unknown");
}
static void meminfo(char *out,size_t cap){
 FILE *f=fopen("/proc/meminfo","r");unsigned long long total=0,avail=0;
 if(f){char key[80],unit[20];unsigned long long v;
 while(fscanf(f,"%79s %llu %19s",key,&v,unit)==3){if(!strcmp(key,"MemTotal:"))total=v;if(!strcmp(key,"MemAvailable:"))avail=v;}
 fclose(f);}
 if(total){
  double pct=100.0*(total-avail)/total;
  const char *color=pct<50.0?"\033[1;32m":pct<=75.0?"\033[1;33m":"\033[1;31m";
  snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%\033[0m)",
           (total-avail)/1048576.,total/1048576.,color,pct);
  return;
 }

 snprintf(out,cap,"Unavailable");
}
static int cache_read(const char *key,char *out,size_t cap,long ttl){
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[512],file[640];struct stat st;
 if(base&&*base)snprintf(dir,sizeof dir,"%s/nisfetch",base);
 else if(home&&*home)snprintf(dir,sizeof dir,"%s/.cache/nisfetch",home);
 else return 0;
 snprintf(file,sizeof file,"%s/%s",dir,key);
 if(stat(file,&st)||time(NULL)-st.st_mtime>ttl)return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 int ok=fgets(out,(int)cap,f)!=NULL;fclose(f);
 if(ok)trim(out);
 return ok&&*out;
}
static void cache_write(const char *key,const char *value){
 if(!value||!*value)return;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[1024],file[1200],parent[512];
 if(base&&*base)snprintf(parent,sizeof parent,"%s",base);
 else if(home&&*home)snprintf(parent,sizeof parent,"%s/.cache",home);
 else return;
 mkdir(parent,0700);snprintf(dir,sizeof dir,"%s/nisfetch",parent);mkdir(dir,0700);
 snprintf(file,sizeof file,"%s/%s",dir,key);
 FILE *f=fopen(file,"w");if(f){fprintf(f,"%s\n",value);fclose(f);}
}
static unsigned long count_lines(const char *cmd){
 FILE *f=popen(cmd,"r");unsigned long n=0;
 if(f){if(fscanf(f,"%lu",&n)!=1)n=0;pclose(f);}return n;
}
/* Directory-based package counting avoids spawning pacman for the native count.
   Foreign packages still require pacman's sync-db classification; cache that
   classification and invalidate it when the local package DB directory changes. */
static unsigned long count_subdirs(const char *path){
 DIR *d=opendir(path);if(!d)return 0;
 unsigned long n=0;struct dirent *e;
 while((e=readdir(d))!=NULL){
  if(e->d_name[0]=='.')continue;
  {
   char file[PATH_MAX];struct stat st;
   if(snprintf(file,sizeof file,"%s/%s",path,e->d_name)<(int)sizeof file &&
      stat(file,&st)==0 && S_ISDIR(st.st_mode))n++;
  }
 }
 closedir(d);return n;
}
static unsigned long foreign_packages(void){
 char buf[80];struct stat db,cache;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char file[PATH_MAX];
 if(base&&*base)snprintf(file,sizeof file,"%s/nisfetch/foreign_count",base);
 else if(home&&*home)snprintf(file,sizeof file,"%s/.cache/nisfetch/foreign_count",home);
 else file[0]=0;
 /* Local package changes invalidate the cached count. Sync DB changes may
    also reclassify packages, so bound the cache lifetime to 1 hour. */
 if(file[0] && stat("/var/lib/pacman/local",&db)==0 &&
    stat(file,&cache)==0 && cache.st_mtime>=db.st_mtime &&
    time(NULL)-cache.st_mtime<3600 && cache_read("foreign_count",buf,sizeof buf,3600)){
  char *end;unsigned long n=strtoul(buf,&end,10);
  if(end!=buf && !*end)return n;
 }
 unsigned long n=count_lines("pacman -Qmq 2>/dev/null | wc -l");
 snprintf(buf,sizeof buf,"%lu",n);cache_write("foreign_count",buf);
 return n;
}
static unsigned long flatpak_apps(void){
 unsigned long n=0;
 const char *home=getenv("HOME");char path[PATH_MAX];
 n+=count_subdirs("/var/lib/flatpak/app");
 if(home&&*home && snprintf(path,sizeof path,"%s/.local/share/flatpak/app",home)<(int)sizeof path)
  n+=count_subdirs(path);
 return n;
}
static void packages_uncached(char *out,size_t cap){
 struct {const char *path,*cmd,*name;} managers[]={
  {"/var/lib/dpkg/status","dpkg-query -W -f='${db:Status-Abbrev}\n' 2>/dev/null | grep -c '^ii'","dpkg"},
  {"/var/lib/rpm","rpm -qa 2>/dev/null | wc -l","rpm"},
  {"/var/lib/apk/db/installed","apk info 2>/dev/null | wc -l","apk"},
  {"/var/db/pkg","pkg info 2>/dev/null | wc -l","pkg"}
 };
 out[0]=0;
 size_t used=0;
 if(is_termux()){
  unsigned long n=count_lines("dpkg-query -W -f='${db:Status-Abbrev}\n' 2>/dev/null | grep -c '^ii'");
  if(n){snprintf(out,cap,"%lu (dpkg/Termux)",n);return;}
 }
 if(access("/var/lib/pacman/local",F_OK)==0){
  /* Native = pacman -Qn; foreign = pacman -Qm (usually AUR). */
  unsigned long total=count_subdirs("/var/lib/pacman/local");
  unsigned long foreign=foreign_packages();
  unsigned long native=total>=foreign?total-foreign:0;
  if(native)used+=(size_t)snprintf(out+used,cap-used,"%lu (pacman)",native);
  if(foreign && used<cap)used+=(size_t)snprintf(out+used,cap-used,"%s%lu (AUR/foreign)",used?", ":"",foreign);
 }else{
  for(size_t i=0;i<sizeof managers/sizeof managers[0];i++){
   if(access(managers[i].path,F_OK)!=0)continue;
   unsigned long n=count_lines(managers[i].cmd);
   if(n){used=(size_t)snprintf(out,cap,"%lu (%s)",n,managers[i].name);break;}
  }
 }
 /* Flatpak apps across user and system installations, if installed. */
 unsigned long flat=flatpak_apps();
 if(flat && used<cap)snprintf(out+used,cap-used,"%s%lu (flatpak)",used?", ":"",flat);
 if(!*out)snprintf(out,cap,"Unavailable");
}
static void packages(char *out,size_t cap){
 if(cache_read("packages",out,cap,15))return;
 packages_uncached(out,cap);
 if(*out && strcmp(out,"Unavailable"))cache_write("packages",out);
}
static const char *env_or(const char *name,const char *fallback){const char *v=getenv(name);return v&&*v?v:fallback;}


static void command_first(const char *cmd,char *out,size_t cap){
 out[0]=0;
 FILE *f=popen(cmd,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 pclose(f);
}
static void ini_value(const char *path,const char *section,const char *key,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 char line[512];int active=0;
 while(fgets(line,sizeof line,f)){
  trim(line);
  if(line[0]=='['){active=(strlen(line)==strlen(section)+2 && line[1+strlen(section)]==']' && !strncmp(line+1,section,strlen(section)));continue;}
  if(active && !strncmp(line,key,strlen(key)) && line[strlen(key)]=='='){
   snprintf(out,cap,"%s",line+strlen(key)+1);break;
  }
 }
 fclose(f);
}
static void config_file(char *out,size_t cap,const char *name){
 const char *base=getenv("XDG_CONFIG_HOME");
 if(base&&*base)snprintf(out,cap,"%s/%s",base,name);
 else snprintf(out,cap,"%s/.config/%s",env_or("HOME",""),name);
}
static void swapinfo(char *out,size_t cap){
 struct sysinfo s;if(sysinfo(&s)){snprintf(out,cap,"Unavailable");return;}
 unsigned long long total=(unsigned long long)s.totalswap*s.mem_unit;
 unsigned long long used=(unsigned long long)(s.totalswap-s.freeswap)*s.mem_unit;
 if(!total){snprintf(out,cap,"Disabled");return;}
 snprintf(out,cap,"%.2f GiB / %.2f GiB",used/1073741824.,total/1073741824.);
}
static void displayinfo(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Android display");return;}
 command_first("command -v xrandr >/dev/null && xrandr --current 2>/dev/null | awk '/\\*/ {print $1 \" @ \" $2; exit}'",out,cap);
 if(!*out)snprintf(out,cap,"Unavailable");
}
static void kde_read(const char *file,const char *group,const char *key,char *out,size_t cap){
 char path[512];config_file(path,sizeof path,file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 /* KDE configuration can be inherited from system defaults. */
 snprintf(path,sizeof path,"/etc/xdg/%s",file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 const char *xdg=getenv("XDG_CONFIG_DIRS");
 if(xdg&&*xdg){
  char *copy=strdup(xdg);if(!copy)return;
  char *save=NULL;
  for(char *dir=strtok_r(copy,":",&save);dir;dir=strtok_r(NULL,":",&save)){
   if(snprintf(path,sizeof path,"%s/%s",dir,file)>=(int)sizeof path)continue;
   ini_value(path,group,key,out,cap);if(*out)break;
  }
  free(copy);
 }
}
static void kde_command(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* KDE's own configuration reader understands merged configuration. */
 char cmd[512];
 if(snprintf(cmd,sizeof cmd,
    "if command -v kreadconfig6 >/dev/null 2>&1; then kreadconfig6 --file %s --group %s --key %s 2>/dev/null; "
    "elif command -v kreadconfig5 >/dev/null 2>&1; then kreadconfig5 --file %s --group %s --key %s 2>/dev/null; fi",
    file,group,key,file,group,key)>=(int)sizeof cmd)return;
 command_first(cmd,out,cap);
}
static void kde_setting(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* First read KDE's native INI files. Cache only the expensive KDE fallback,
    including missing keys; never cache the native path. */
 out[0]=0;
 kde_read(file,group,key,out,cap);
 if(*out)return;
 char cache_key[192],cached[512];
 snprintf(cache_key,sizeof cache_key,"kde_%s_%s_%s",file,group,key);
 if(cache_read(cache_key,cached,sizeof cached,60)){
  if(strcmp(cached,"__NISFETCH_EMPTY__"))snprintf(out,cap,"%.*s",(int)cap-1,cached);
  return;
 }
 kde_command(file,group,key,out,cap);
 cache_write(cache_key,*out?out:"__NISFETCH_EMPTY__");
}
static int is_kde(void){
 const char *d=getenv("XDG_CURRENT_DESKTOP");
 return d&&(strstr(d,"KDE")||strstr(d,"Plasma"));
}
/* Resolve only selected KDE modules, rather than eagerly resolving all six
   settings (and fontconfig) for every single-module request. */
static void themeinfo(char *wmtheme,size_t wtcap,char *theme,size_t tcap,
                      char *icons,size_t icap,char *font,size_t fcap,
                      char *cursor,size_t ccap,char *plasma,size_t pcap){
 const int want_wm=module_enabled("wmtheme");
 const int want_theme=module_enabled("theme");
 const int want_icons=module_enabled("icons");
 const int want_font=module_enabled("font");
 const int want_cursor=module_enabled("cursor");
 const int want_plasma=module_enabled("plasmatheme");
 if(!is_kde()){
  if(want_wm)snprintf(wmtheme,wtcap,"N/A");
  if(want_theme)snprintf(theme,tcap,"N/A");
  if(want_icons)snprintf(icons,icap,"N/A");
  if(want_font)snprintf(font,fcap,"N/A");
  if(want_cursor)snprintf(cursor,ccap,"N/A");
  if(want_plasma)snprintf(plasma,pcap,"N/A");
  return;
 }
 if(want_wm){
  kde_setting("kwinrc","org.kde.kdecoration2","theme",wmtheme,wtcap);
  if(!*wmtheme)kde_setting("kwinrc","org.kde.kdecoration2","library",wmtheme,wtcap);
  if(!*wmtheme)snprintf(wmtheme,wtcap,"Breeze (assumed default)");
 }
 if(want_theme){
  kde_setting("kdeglobals","General","ColorScheme",theme,tcap);
  if(!*theme)snprintf(theme,tcap,"Breeze (assumed default)");
 }
 if(want_icons){
  kde_setting("kdeglobals","Icons","Theme",icons,icap);
  if(!*icons)snprintf(icons,icap,"breeze (assumed default)");
 }
 if(want_font){
  kde_setting("kdeglobals","General","font",font,fcap);
  if(!*font){
   if(!cache_read("fontconfig_family",font,fcap,300)){
    command_first("fc-match -f '%{family}\n' sans-serif 2>/dev/null",font,fcap);
    if(*font)cache_write("fontconfig_family",font);
   }
   if(!*font)snprintf(font,fcap,"Not configured");
   else {size_t n=strlen(font);if(n<fcap)snprintf(font+n,fcap-n," (fontconfig)");}
  }
  char *comma=strchr(font,',');if(comma)*comma=0;
 }
 if(want_cursor){
  kde_setting("kcminputrc","Mouse","cursorTheme",cursor,ccap);
  if(!*cursor)snprintf(cursor,ccap,"Breeze (assumed default)");
 }
 if(want_plasma){
  kde_setting("plasmarc","Theme","name",plasma,pcap);
  if(!*plasma)snprintf(plasma,pcap,"Breeze (assumed default)");
 }
}
static void kde_display(char *out,size_t cap){
 /* KScreen DBus startup is relatively costly; keep the exact result for 30s. */
 if(cache_read("display",out,cap,30))return;
 if(is_kde()){
  char line[512];
  command_first("if command -v kscreen-doctor >/dev/null 2>&1; then kscreen-doctor -o 2>/dev/null | grep -m1 -E '([0-9]{3,5}x[0-9]{3,5})|([0-9]{3,5}/[0-9]{3,5})'; fi",line,sizeof line);
  /* The full kscreen-doctor line is verbose; extract a resolution. */
  for(char *p=line;*p;p++){
   if(p[0]>='0'&&p[0]<='9'){
    unsigned w,h;
    if(sscanf(p,"%ux%u",&w,&h)==2&&w>=320&&h>=200&&w<20000&&h<20000){
     snprintf(out,cap,"%ux%u (Wayland)",w,h);cache_write("display",out);return;
    }
   }
  }
 }
 displayinfo(out,cap);
 if(*out && strcmp(out,"Unavailable"))cache_write("display",out);
}
static void wm_info(char *out,size_t cap){
 const char *desktop=getenv("XDG_CURRENT_DESKTOP");
 if(desktop&&(strstr(desktop,"KDE")||strstr(desktop,"Plasma")))snprintf(out,cap,"KWin (%s)",env_or("XDG_SESSION_TYPE","Unknown"));
 else if(desktop&&strstr(desktop,"Hyprland"))snprintf(out,cap,"Hyprland");
 else snprintf(out,cap,"Unavailable");
}
static void disk_path(const char *path,char *out,size_t cap){
 struct statvfs v;if(statvfs(path,&v)){snprintf(out,cap,"Unavailable");return;}
 double t=(double)v.f_blocks*v.f_frsize,used=(double)(v.f_blocks-v.f_bfree)*v.f_frsize;
 double pct=t?100*used/t:0;
 const char *c=pct<50?"\033[1;32m":pct<=75?"\033[1;33m":"\033[1;31m";
 snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%" R ")",used/1073741824.,t/1073741824.,c,pct);
}
static void palette_row(int row){
 for(int i=0;i<8;i++)printf("\033[48;5;%dm   ",row*8+i);
 fputs(R,stdout);
}

static int read_temp(const char *path,double *celsius){
 FILE *f=fopen(path,"r");if(!f)return 0;
 long val=0;int ok=fscanf(f,"%ld",&val)==1;fclose(f);
 if(!ok||val< -30000||val>150000)return 0;
 *celsius=val/1000.0;return 1;
}
static int sensor_temp(const char *driver,double *value){
 DIR *d=opendir("/sys/class/hwmon");if(!d)return 0;
 struct dirent *e;int found=0;
 while((e=readdir(d))){
  if(strncmp(e->d_name,"hwmon",5))continue;
  char path[512],name[128];
  snprintf(path,sizeof path,"/sys/class/hwmon/%s/name",e->d_name);
  FILE *f=fopen(path,"r");if(!f)continue;
  if(!fgets(name,sizeof name,f)){fclose(f);continue;}fclose(f);trim(name);
  if(strcmp(name,driver))continue;
  for(int i=1;i<=4;i++){
   snprintf(path,sizeof path,"/sys/class/hwmon/%s/temp%d_input",e->d_name,i);
   if(read_temp(path,value)){found=1;break;}
  }
  if(found)break;
 }
 closedir(d);return found;
}
static void temp_suffix(char *out,size_t cap,const char *driver1,const char *driver2){
 double temp;
 if(sensor_temp(driver1,&temp)||sensor_temp(driver2,&temp)){
  const char *color=temp<50?"\033[1;32m":temp<=75?"\033[1;33m":"\033[1;31m";
  size_t n=strlen(out);
  if(n<cap)snprintf(out+n,cap-n," (%s%.0f°C\033[0m)",color,temp);
 }
}
static void gpu_short_uncached(char *out,size_t cap){
 char line[1024]="",raw[512]="";
 /* Renderer can distinguish cards sharing the same PCI device ID. */
 command_first("LC_ALL=C glxinfo -B 2>/dev/null | grep -m1 'OpenGL renderer string:'",line,sizeof line);
 if(*line){
  char *p=strchr(line,':');
  if(p){p++;while(isspace((unsigned char)*p))p++;
   char *end=strstr(p," (");if(end)*end=0;
   if(strstr(p,"Radeon RX ") || strstr(p,"GeForce ") || strstr(p,"Arc ")){
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C vulkaninfo --summary 2>/dev/null | grep -m1 'deviceName[[:space:]]*='",line,sizeof line);
 if(*line){
  char *p=strchr(line,'=');if(p){p++;while(isspace((unsigned char)*p))p++;
   if(strstr(p,"Radeon RX ")||strstr(p,"GeForce ")||strstr(p,"Arc ")){
    char *end=strstr(p," (");if(end)*end=0;
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C lspci -mm 2>/dev/null | grep -Ei 'VGA compatible controller|3D controller|Display controller' | head -n 1",line,sizeof line);
 char *parts[8]={0};int n=0;
 for(char *p=line;*p&&n<8;){
  if(*p!='"'){p++;continue;}p++;parts[n++]=p;
  char *end=strchr(p,'"');if(!end)break;*end=0;p=end+1;
 }
 if(n>=3)snprintf(raw,sizeof raw,"%s",parts[2]);
 else if(n>=2)snprintf(raw,sizeof raw,"%s",parts[n-1]);
 else {snprintf(out,cap,"Unavailable (pciutils)");return;}
 /* Ambiguous PCI identifiers are displayed as a family, not a guessed SKU. */
 if(strstr(raw,"6700/6700 XT/6750 XT") || strstr(raw,"6800M/6850M XT")){
  snprintf(out,cap,"AMD Radeon RX 6700 series (Navi 22)");return;
 }
 const char *mark=strstr(raw,"[Radeon ");
 if(mark){mark++;char *end=strchr((char*)mark,']');if(end)*end=0;snprintf(out,cap,"AMD %s",mark);}
 else snprintf(out,cap,"%s",raw);
}
static void gpu_short(char *out,size_t cap){
 if(cache_read("gpu",out,cap,86400))return;
 gpu_short_uncached(out,cap);
 if(*out && !strstr(out,"Unavailable"))cache_write("gpu",out);
}
/* Shorten only the ambiguous GPU model, never the temperature suffix. */
static void fit_gpu(char *gpu,size_t cap,int max_visible){
 const char *suffix=strrchr(gpu,'(');
 if(!suffix || suffix==gpu || suffix[-1]!=' ')return;
 size_t base=(size_t)(suffix-gpu)-1;
 int suffix_width=0;
 for(const char *p=suffix;*p;){
  if(p[0]==27 && p[1]=='['){p+=2;while(*p && *p!='m')p++;if(*p)p++;}
  else {unsigned char c=(unsigned char)*p;p+=c>=240?4:c>=224?3:c>=192?2:1;suffix_width++;}
 }
 int keep=max_visible-suffix_width-1;
 if(keep<4)return;
 if((int)base<=keep)return;
 char result[512];
 int n=keep-3;
 if(n<1)return;
 snprintf(result,sizeof result,"%.*s... %s",n,gpu,suffix);
 snprintf(gpu,cap,"%.*s",(int)(cap-1),result);
}
/* Clip by terminal cell width, not UTF-8 byte length. Never split a codepoint
   or a CSI color sequence. Control characters from system metadata are dropped. */
static void clip_ansi(const char *src,char *dst,size_t cap,int limit){
 size_t i=0,j=0;int cells=0;
 mbstate_t state={0};
 while(src[i] && j+8<cap && cells<limit){
  if((unsigned char)src[i]==27){
   if(src[i+1]=='['){
    size_t start=i++;i++;
    while(src[i] && (unsigned char)src[i]>=0x20 && (unsigned char)src[i]<=0x3f)i++;
    if(src[i]=='m'){
     size_t n=++i-start;
     if(j+n+5<cap){memcpy(dst+j,src+start,n);j+=n;}
    }else if(src[i])i++;
   }else i++;
   continue;
  }
  wchar_t wc;size_t n=mbrtowc(&wc,src+i,MB_CUR_MAX,&state);
  if(n==(size_t)-1 || n==(size_t)-2 || n==0){memset(&state,0,sizeof state);i++;continue;}
  int width=wcwidth(wc);
  if(width<0){i+=n;continue;}
  if(cells+width>limit)break;
  if(j+n+5>=cap)break;
  memcpy(dst+j,src+i,n);j+=n;i+=n;cells+=width;
 }
 if(j+4<cap){memcpy(dst+j,"\033[0m",4);j+=4;}
 dst[j]=0;
}


static void read_first(const char *path,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 fclose(f);
}
static void optional_module(const char *name){
 if(!module_enabled(name))return;
 char v[512]="",p[512]="";
 if(!strcmp(name,"board")){motherboard(v,sizeof v);}
 else if(!strcmp(name,"bios")){read_first("/sys/class/dmi/id/bios_version",v,sizeof v);}
 else if(!strcmp(name,"chassis")){read_first("/sys/class/dmi/id/chassis_type",v,sizeof v);}
 else if(!strcmp(name,"shell")){snprintf(v,sizeof v,"%s",env_or("SHELL","Unknown"));}
 else if(!strcmp(name,"processes")){command_first("ps -e 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"loadavg")){read_first("/proc/loadavg",v,sizeof v);char *q=strrchr(v,' ');if(q)*q=0;}
 else if(!strcmp(name,"datetime")){command_first("date '+%Y-%m-%d %H:%M:%S'",v,sizeof v);}
 else if(!strcmp(name,"timezone")){command_first("date +%Z",v,sizeof v);}
 else if(!strcmp(name,"hostname")){gethostname(v,sizeof v);v[sizeof v-1]=0;}
 else if(!strcmp(name,"architecture")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"cpucores")){long n=sysconf(_SC_NPROCESSORS_ONLN);if(n>0)snprintf(v,sizeof v,"%ld",n);}
 else if(!strcmp(name,"cpufreq")){unsigned long long khz=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");if(khz)snprintf(v,sizeof v,"%.2f GHz",khz/1000000.0);}
 else if(!strcmp(name,"battery")){
  DIR *d=opendir("/sys/class/power_supply");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],typ[80]="",pct[80]="";
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);read_first(path,typ,sizeof typ);
   if(strcmp(typ,"Battery"))continue;
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/capacity",e->d_name);read_first(path,pct,sizeof pct);
   if(*pct){snprintf(v,sizeof v,"%s%%",pct);break;}
  }closedir(d);}
 }
 else if(!strcmp(name,"brightness")){
  DIR *d=opendir("/sys/class/backlight");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],cur[80]="",max[80]="";
   snprintf(path,sizeof path,"/sys/class/backlight/%s/brightness",e->d_name);read_first(path,cur,sizeof cur);
   snprintf(path,sizeof path,"/sys/class/backlight/%s/max_brightness",e->d_name);read_first(path,max,sizeof max);
   long a=atol(cur),b=atol(max);if(b>0){snprintf(v,sizeof v,"%ld%%",a*100/b);break;}
  }closedir(d);}
 }
 else if(!strcmp(name,"bluetooth")){command_first("bluetoothctl list 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"network")){command_first("ip route show default 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"diskusage")){disk_path("/",v,sizeof v);}
 else if(!strcmp(name,"diskfilesystem")){command_first("df -T / 2>/dev/null | tail -n 1 | awk '{print $2}'",v,sizeof v);}
 else if(!strcmp(name,"termux")){if(is_termux())snprintf(v,sizeof v,"Termux");}
 else if(!strcmp(name,"androidversion")){property("ro.build.version.release",v,sizeof v);}
 else if(!strcmp(name,"androidsdk")){property("ro.build.version.sdk",v,sizeof v);}
 else if(!strcmp(name,"androidmanufacturer")){property("ro.product.manufacturer",v,sizeof v);}
 else if(!strcmp(name,"androidmodel")){property("ro.product.model",v,sizeof v);}
 else if(!strcmp(name,"androidsoc")){property("ro.soc.model",v,sizeof v);}
 else if(!strcmp(name,"bootid")){read_first("/proc/sys/kernel/random/boot_id",v,sizeof v);}
 else if(!strcmp(name,"virtualization")){command_first("systemd-detect-virt 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"editor")){snprintf(v,sizeof v,"%s",env_or("EDITOR","Unknown"));}
 else if(!strcmp(name,"users")){command_first("who 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"language")){snprintf(v,sizeof v,"%s",env_or("LANG","Unknown"));}

 else if(!strcmp(name,"distro")){osname(v,sizeof v);}
 else if(!strcmp(name,"osversion")){read_first("/etc/os-release",v,sizeof v);}
 else if(!strcmp(name,"kernelversion")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.release);}
 else if(!strcmp(name,"kernelarch")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"machineid")){read_first("/etc/machine-id",v,sizeof v);}
 else if(!strcmp(name,"cpuvendor")){command_first("grep -m1 -E 'vendor_id|CPU implementer' /proc/cpuinfo | cut -d: -f2-",v,sizeof v);}
 else if(!strcmp(name,"cpumodel")){cpuinfo(v,sizeof v);}
 else if(!strcmp(name,"cpubogomips")){command_first("grep -m1 'bogomips' /proc/cpuinfo | cut -d: -f2-",v,sizeof v);}
 else if(!strcmp(name,"cpuload")){read_first("/proc/loadavg",v,sizeof v);char *q=strchr(v,' ');if(q){q=strchr(q+1,' ');if(q){q=strchr(q+1,' ');if(q)*q=0;}}}
 else if(!strcmp(name,"memtotal")||!strcmp(name,"memavailable")||!strcmp(name,"swaptotal")||!strcmp(name,"swapfree")){
  struct sysinfo si;if(!sysinfo(&si)){unsigned long long n=0;
   if(!strcmp(name,"memtotal"))n=(unsigned long long)si.totalram*si.mem_unit;
   if(!strcmp(name,"memavailable"))n=(unsigned long long)si.freeram*si.mem_unit;
   if(!strcmp(name,"swaptotal"))n=(unsigned long long)si.totalswap*si.mem_unit;
   if(!strcmp(name,"swapfree"))n=(unsigned long long)si.freeswap*si.mem_unit;
   snprintf(v,sizeof v,"%.2f GiB",(double)n/1073741824.0);}}
 else if(!strcmp(name,"diskfree")||!strcmp(name,"disktotal")||!strcmp(name,"diskpercent")){
  struct statvfs fs;if(!statvfs("/",&fs)){double total=(double)fs.f_blocks*fs.f_frsize,freeb=(double)fs.f_bavail*fs.f_frsize;
   if(!strcmp(name,"diskfree"))snprintf(v,sizeof v,"%.2f GiB",freeb/1073741824.0);
   if(!strcmp(name,"disktotal"))snprintf(v,sizeof v,"%.2f GiB",total/1073741824.0);
   if(!strcmp(name,"diskpercent")&&total>0)snprintf(v,sizeof v,"%.1f%%",(total-freeb)*100.0/total);}}
 else if(!strcmp(name,"rootfs")){command_first("df -T / 2>/dev/null | awk 'NR==2{print $2}'",v,sizeof v);}
 else if(!strcmp(name,"mounts")){command_first("wc -l </proc/mounts",v,sizeof v);}
 else if(!strcmp(name,"interfaces")){command_first("ls /sys/class/net 2>/dev/null | paste -sd, -",v,sizeof v);}
 else if(!strcmp(name,"ipv4")){command_first("ip -4 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"ipv6")){command_first("ip -6 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"gateway")){command_first("ip route show default 2>/dev/null | awk 'NR==1{print $3}'",v,sizeof v);}
 else if(!strcmp(name,"dns")){command_first("awk '/^nameserver/{print $2;exit}' /etc/resolv.conf 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"username")){snprintf(v,sizeof v,"%s",env_or("USER","Unknown"));}
 else if(!strcmp(name,"uid")){snprintf(v,sizeof v,"%lu",(unsigned long)getuid());}
 else if(!strcmp(name,"gid")){snprintf(v,sizeof v,"%lu",(unsigned long)getgid());}
 else if(!strcmp(name,"home")){snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"path")){snprintf(v,sizeof v,"%.200s",env_or("PATH","Unknown"));}
 else if(!strcmp(name,"shellversion")){command_first("${SHELL:-/bin/sh} --version 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"terminaltype")){snprintf(v,sizeof v,"%s",env_or("TERM","Unknown"));}
 else if(!strcmp(name,"displayserver")){snprintf(v,sizeof v,"%s",env_or("XDG_SESSION_TYPE","Unknown"));}
 else if(!strcmp(name,"sessiondesktop")){snprintf(v,sizeof v,"%s",env_or("XDG_CURRENT_DESKTOP","Unknown"));}
 else if(!strcmp(name,"xdgconfig")){snprintf(v,sizeof v,"%s",env_or("XDG_CONFIG_HOME","Unknown"));}
 else if(!strcmp(name,"xdgcache")){snprintf(v,sizeof v,"%s",env_or("XDG_CACHE_HOME","Unknown"));}
 else if(!strcmp(name,"xdgdata")){snprintf(v,sizeof v,"%s",env_or("XDG_DATA_HOME","Unknown"));}
 else if(!strcmp(name,"pid")){snprintf(v,sizeof v,"%ld",(long)getpid());}
 else if(!strcmp(name,"parentpid")){snprintf(v,sizeof v,"%ld",(long)getppid());}
 else if(!strcmp(name,"threads")){command_first("grep '^Threads:' /proc/self/status | awk '{print $2}'",v,sizeof v);}
 else if(!strcmp(name,"systemd")){if(access("/run/systemd/system",F_OK)==0)snprintf(v,sizeof v,"running");}
 else if(!strcmp(name,"init")){read_first("/proc/1/comm",v,sizeof v);}
 else if(!strcmp(name,"cgroup")){read_first("/proc/self/cgroup",v,sizeof v);}
 else if(!strcmp(name,"entropy")){read_first("/proc/sys/kernel/random/entropy_avail",v,sizeof v);}
 else if(!strcmp(name,"thermalzones")){command_first("find /sys/class/thermal -maxdepth 1 -name 'thermal_zone*' 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"fans")){command_first("find /sys/class/hwmon -name 'fan*_input' 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"batterycount")){command_first("find /sys/class/power_supply -maxdepth 1 -name 'BAT*' 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"powerstate")){command_first("cat /sys/class/power_supply/BAT0/status 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"androiddevice")){property("ro.product.device",v,sizeof v);}
 else if(!strcmp(name,"androidboard")){property("ro.product.board",v,sizeof v);}
 else if(!strcmp(name,"androidfingerprint")){property("ro.build.fingerprint",v,sizeof v);}
 else if(!strcmp(name,"androidsecuritypatch")){property("ro.build.version.security_patch",v,sizeof v);}
 else if(!strcmp(name,"termuxprefix")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("PREFIX","Unknown"));}
 else if(!strcmp(name,"termuxhome")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"timezoneoffset")){command_first("date +%z",v,sizeof v);}
 else if(!strcmp(name,"epoch")){snprintf(v,sizeof v,"%lld",(long long)time(NULL));}
 else if(!strcmp(name,"week")){command_first("date +%V",v,sizeof v);}
 else if(!strcmp(name,"dayofyear")){command_first("date +%j",v,sizeof v);}
 else if(!strcmp(name,"bootdate")){command_first("uptime -s 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"procversion")){read_first("/proc/version",v,sizeof v);}
 else if(!strcmp(name,"filesystems")){command_first("awk '{print $1}' /proc/filesystems | paste -sd, -",v,sizeof v);}
 else if(!strcmp(name,"environment")){snprintf(v,sizeof v,"%s",is_termux()?"Termux":"Linux");}
 if(*v && strcmp(v,"Unknown")){snprintf(p,sizeof p,"%s:",name);int prev=ninfo;add(p,v);if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);}
}

static void reorder_info(void){
 if(!*cfg_order)return;
 char reordered[MAX_ROWS][512];char ids[MAX_ROWS][64];
 int used[MAX_ROWS]={0},count=0;
 char copy[sizeof cfg_order];snprintf(copy,sizeof copy,"%s",cfg_order);
 for(char *name=strtok(copy,":");name;name=strtok(NULL,":")){
  for(int i=0;i<ninfo;i++)if(!used[i]&&!strcmp(name,info_id[i])){
   memcpy(reordered[count],info[i],sizeof info[i]);
   memcpy(ids[count],info_id[i],sizeof ids[count]);
   used[i]=1;count++;break;
  }
 }
 for(int i=0;i<ninfo;i++)if(!used[i]){
  memcpy(reordered[count],info[i],sizeof info[i]);
  memcpy(ids[count],info_id[i],sizeof ids[count]);count++;
 }
 for(int i=0;i<count;i++){memcpy(info[i],reordered[i],sizeof info[i]);memcpy(info_id[i],ids[i],sizeof info_id[i]);}
}
static double now_ms(void){
 struct timespec ts;
 if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (double)ts.tv_sec*1000.0+(double)ts.tv_nsec/1000000.0;
}
int main(int argc,char **argv){
 const double run_start=now_ms();
 int profile=0;
 setlocale(LC_CTYPE,"");
 static char output_buffer[262144];setvbuf(stdout,output_buffer,_IOFBF,sizeof output_buffer);
 int no_logo=0;const char *cli_logo=NULL;const char *custom=NULL;const char *config_path=NULL;int no_config=0,check_config=0;
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--no-logo"))no_logo=1;
  else if(!strcmp(argv[i],"--profile"))profile=1;
  else if(!strcmp(argv[i],"--version")){puts("NISFETCH 2.8.7");return 0;}
  else if(!strcmp(argv[i],"--config")&&i+1<argc)config_path=argv[++i];
  else if(!strcmp(argv[i],"--no-config"))no_config=1;
  else if(!strcmp(argv[i],"--check-config"))check_config=1;
  else if(!strcmp(argv[i],"--list-logos")){list_logos();return 0;}
  else if(!strcmp(argv[i],"--logo")&&i+1<argc)cli_logo=argv[++i];
  else if(!strcmp(argv[i],"--gen-config")){
   const char *sample="{\n  // NISFETCH 2.8.7\n  \"logo\": {\"type\": \"tux\", \"enabled\": true, \"autoScale\": true, \"width\": 0},\n  \"display\": {\"gap\": 2, \"palette\": true, \"keyColor\": \"#ffc930\", \"valueColor\": \"#e4e7ec\"},\n  \"modules\": [\"title\", \"separator\", \"os\", \"host\", \"kernel\", \"uptime\", \"packages\", \"display\", \"desktop\", \"wm\", \"wmtheme\", \"theme\", \"plasmatheme\", \"icons\", \"font\", \"cursor\", \"session\", \"terminal\", \"cpu\", \"gpu\", \"memory\", \"swap\", \"disk\", \"homedisk\", \"localip\", \"locale\"]\n}\n";
   fputs(sample,stdout);return 0;
  }
  else if(!strcmp(argv[i],"--help")){puts("Usage: nisfetch [--config PATH] [--check-config] [--no-config] [--gen-config] [--logo NAME] [--list-logos] [--no-logo] [--modules name:name | --all] [--list-modules] [--profile] [--version]");return 0;}
  else if(!strcmp(argv[i],"--list-modules")){for(size_t j=0;j<sizeof module_names/sizeof module_names[0];j++)puts(module_names[j]);return 0;}
  else if(!strcmp(argv[i],"--all"))custom=all_modules;
  else if(!strcmp(argv[i],"--modules")&&i+1<argc)custom=argv[++i];
  else {fprintf(stderr,"Unknown option: %s\\n",argv[i]);return 2;}
 }
 if(!no_config){
  if(config_path){if(!cfg_load(config_path,1))return 2;}
  else{
   char path[1024];const char *xdg=getenv("XDG_CONFIG_HOME"),*home=getenv("HOME");
   if(xdg&&*xdg)snprintf(path,sizeof path,"%s/nisfetch/config.jsonc",xdg);
   else if(home&&*home)snprintf(path,sizeof path,"%s/.config/nisfetch/config.jsonc",home);
   else path[0]=0;
   if(*path&&!cfg_load(path,0))return 2;
  }
 }
 if(cli_logo)snprintf(cfg_logo_type,sizeof cfg_logo_type,"%s",cli_logo);
 if(strcmp(cfg_logo_type,"tux")&&!find_logo(cfg_logo_type)){
  fprintf(stderr,"Unknown logo: %s (see --list-logos)\\n",cfg_logo_type);return 2;
 }
 if(cfg_gap<0)cfg_gap=0;
 if(cfg_gap>12)cfg_gap=12;
 if(cfg_logo_width<0)cfg_logo_width=0;
 if(cfg_logo_width>TUX_W)cfg_logo_width=TUX_W;
 if(!custom&&*cfg_order)custom=cfg_order;
 if(custom&&!valid_modules(custom))return 2;
 if(custom && custom!=cfg_order)cfg_order[0]=0;
 if(check_config){puts("Config OK");return 0;}
 selected_modules=custom;
 const double setup_end=now_ms();
 struct utsname u;struct sysinfo si;if(uname(&u)||sysinfo(&si)){perror("nisfetch");return 1;}
 char os[256],cpu[256],mem[128],disk[128]="",pkgs[128],tmp[512],hostname[256],board[512]="";
 char terminal[128]="",swap[128],gpu[256],display[128],theme[128],icons[128],font[256],wm[128],home_disk[128]="",wmtheme[128],cursor[128],plasma[128];
 os[0]=cpu[0]=mem[0]=pkgs[0]=0;
 if(module_enabled("os"))osname(os,sizeof os);
 if(module_enabled("cpu"))cpuinfo(cpu,sizeof cpu);
 if(module_enabled("memory"))meminfo(mem,sizeof mem);
 if(module_enabled("packages"))packages(pkgs,sizeof pkgs);
 if(gethostname(hostname,sizeof hostname))snprintf(hostname,sizeof hostname,"unknown");
 hostname[sizeof hostname-1]=0;
 struct passwd *pw=getpwuid(getuid());const char *user=env_or("USER",pw?pw->pw_name:"user");
 swap[0]=gpu[0]=display[0]=0;
 if(module_enabled("swap"))swapinfo(swap,sizeof swap);
 if(module_enabled("gpu"))gpu_short(gpu,sizeof gpu);
 if(module_enabled("display"))kde_display(display,sizeof display);
 wmtheme[0]=theme[0]=icons[0]=font[0]=cursor[0]=plasma[0]=wm[0]=0;
 if(module_enabled("wmtheme")||module_enabled("theme")||module_enabled("icons")||module_enabled("font")||module_enabled("cursor")||module_enabled("plasmatheme"))
  themeinfo(wmtheme,sizeof wmtheme,theme,sizeof theme,icons,sizeof icons,font,sizeof font,cursor,sizeof cursor,plasma,sizeof plasma);
 if(module_enabled("wm"))wm_info(wm,sizeof wm);
 if(module_enabled("homedisk"))disk_path(env_or("HOME","/"),home_disk,sizeof home_disk);
 snprintf(tmp,sizeof tmp,"\033[1;38;2;255;208;56m%s@%s\033[0m",user,hostname);add_module("title","",tmp);
 /* Underline exactly the visible width of user@hostname. */
 size_t title_width=strlen(user)+1+strlen(hostname);
 if(title_width>100)title_width=100;
 char underline[512];size_t off=0;
 for(size_t i=0;i<title_width && off+4<sizeof underline;i++){
  memcpy(underline+off,"─",3);off+=3;
 }
 underline[off]='\0';
 add_module("separator","",underline);
 snprintf(tmp,sizeof tmp,"%s %s",os,u.machine);add_module("os","OS:",tmp);
 if(module_enabled("host"))motherboard(board,sizeof board);
 add_module("host","Host:",board);
 snprintf(tmp,sizeof tmp,"%s %s",u.sysname,u.release);add_module("kernel","Kernel:",tmp);
 long uptime_hours=si.uptime/3600, uptime_minutes=(si.uptime/60)%60;
 snprintf(tmp,sizeof tmp,"%ld %s, %ld %s",uptime_hours,uptime_hours==1?"hour":"hours",uptime_minutes,uptime_minutes==1?"min":"mins");add_module("uptime","Uptime:",tmp);
 add_module("packages","Packages:",pkgs);
 add_module("display","Display:",display);
 add_module("desktop","Desktop:",is_termux()?"Android":env_or("XDG_CURRENT_DESKTOP",env_or("XDG_SESSION_DESKTOP","TTY")));
 add_module("wm","WM:",wm);
 add_module("wmtheme","WM Theme:",wmtheme);
 add_module("theme","Theme:",theme);
 add_module("plasmatheme","Plasma Theme:",plasma);
 add_module("icons","Icons:",icons);
 add_module("font","Font:",font);
 add_module("cursor","Cursor:",cursor);
 add_module("session","Session:",is_termux()?"Termux":env_or("XDG_SESSION_TYPE","TTY"));
 if(module_enabled("terminal"))terminal_name(terminal,sizeof terminal);
 add_module("terminal","Terminal:",terminal);
 if(module_enabled("cpu")){cpu_max_frequency(cpu,sizeof cpu);temp_suffix(cpu,sizeof cpu,"k10temp","coretemp");}
 if(module_enabled("gpu"))temp_suffix(gpu,sizeof gpu,"amdgpu","nouveau");
 struct winsize ws={0};
 int termcols=100,termrows=40;
 if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&ws)!=0)ioctl(STDIN_FILENO,TIOCGWINSZ,&ws);
 if(ws.ws_col>0)termcols=ws.ws_col;
 if(ws.ws_row>0)termrows=ws.ws_row;
 /* Keep at least 34 text cells; avoid upscaling the pixel art. The terminal
    character cell aspect ratio is handled by the 2-pixel half-block format. */
 const DistroLogo *dlogo=strcmp(cfg_logo_type,"tux")?find_logo(cfg_logo_type):NULL;
 const unsigned char *pixlogo=dlogo?distro_pixels(cfg_logo_type):NULL;
 int artwidth=cfg_logo_width?cfg_logo_width:TUX_W,artheight=0;
 int allowed_width=termcols-34-cfg_gap;
 int show_tux=0,show_distro=0,show_pixel=0;
 int pix_top=0,pix_bottom=DISTRO_H;
 if(pixlogo)pixel_logo_bounds(pixlogo,&pix_top,&pix_bottom);
 /* All high-resolution logos use the exact same layout geometry as Tux. */
 if(!dlogo || pixlogo){
  int allowed_height=termrows-3;
  if(artwidth>allowed_width)artwidth=allowed_width;
  if(allowed_height>0){
   int by_height=(int)((long)allowed_height*TUX_W*2/TUX_H);
   if(artwidth>by_height)artwidth=by_height;
  }
  artheight=artwidth>0?(int)lround((double)artwidth*TUX_H/(2.0*TUX_W)):0;
  int visible=!no_logo&&cfg_logo&&artwidth>=14&&artheight>=9;
  if(!cfg_auto&&artwidth<(cfg_logo_width?cfg_logo_width:TUX_W))visible=0;
  show_tux=visible&&!pixlogo;
  show_pixel=visible&&pixlogo;
  if(!visible){artwidth=0;artheight=0;}
 }else{
  /* Retain legacy compact fallback for logos without supplied pixel artwork. */
  artwidth=distro_width(dlogo);
  artheight=dlogo->height;
  show_distro=!no_logo&&cfg_logo&&artwidth<=allowed_width&&artheight<=termrows;
  if(!show_distro){artwidth=0;artheight=0;}
 }
 int show_logo=show_tux||show_pixel||show_distro;
 fit_gpu(gpu,sizeof gpu,termcols-artwidth-cfg_gap-LABEL_WIDTH);
 add_module("cpu","CPU:",cpu);
 add_module("gpu","GPU:",gpu);
 add_module("memory","Memory:",mem);
 add_module("swap","Swap:",swap);
 if(module_enabled("disk"))disk_path("/",disk,sizeof disk);
 add_module("disk","Disk (/):",disk);
 add_module("homedisk",is_termux()?"Disk (HOME):":"Disk (/home):",home_disk);
 add_module("localip","Local IP:","1337.1337.1337");
 add_module("locale","Locale:",env_or("LANG","Unknown"));
 if(selected_modules){
  for(size_t k=26;k<sizeof module_names/sizeof module_names[0];k++)
   optional_module(module_names[k]);
 }
 reorder_info();
 const double collect_end=now_ms();
 /* Pixel distro logos use the same FIXED column width as Tux, while their
    visual height follows the text panel. Never alter text/font/layout. */
 if(show_pixel && cfg_logo_width==0){
  int balanced_height=ninfo+(cfg_palette?3:0);
  if(balanced_height<22)balanced_height=22;
  if(balanced_height>artheight)balanced_height=artheight;
  if(balanced_height>termrows-3)balanced_height=termrows-3;
  if(balanced_height>=9)artheight=balanced_height;
 }
 /* Fastfetch-style: compact, consecutive info rows starting at the top. */
 size_t artrows=show_logo?(size_t)artheight:0;
 size_t rows=artrows;
 if((size_t)ninfo+(cfg_palette?3:0)>rows)rows=(size_t)ninfo+(cfg_palette?3:0);
 for(size_t i=0;i<rows;i++){
   if(show_logo){if(i<artrows){if(show_tux)tux_row_scaled(i,artwidth,artheight);else if(show_pixel)pixel_logo_row(pixlogo,i,artwidth,artheight,pix_top,pix_bottom);else distro_row(dlogo,(int)i,artwidth);}else printf("%*s",artwidth,"");}
   if(i<(size_t)ninfo){
     int remaining=termcols-artwidth-(show_logo?cfg_gap:0);
     if(remaining<1)remaining=1;
     char clipped[1024];clip_ansi(info[i],clipped,sizeof clipped,remaining);
     printf("%*s%s",show_logo?cfg_gap:0,"",clipped);
   }else if(cfg_palette && (i==(size_t)ninfo+1 || i==(size_t)ninfo+2) && termcols-artwidth>=26){
     fputs("  ",stdout);
     palette_row((int)(i-(size_t)ninfo-1));
   }
   putchar('\n');
 }
 /* --profile is opt-in and writes timings to stderr only. */
 if(profile){
  fflush(stdout);
  const double end=now_ms();
  fprintf(stderr,"NISFETCH profile: setup %.2f ms | collect %.2f ms | render %.2f ms | total %.2f ms\n",setup_end-run_start,collect_end-setup_end,end-collect_end,end-run_start);
 }
 return 0;
}
