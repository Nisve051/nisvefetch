#ifndef NIS_DRM_IOCTL_H
#define NIS_DRM_IOCTL_H

/* Minimal read-only Linux DRM/KMS UAPI. Layouts and ioctl numbers are from
   Linux drm_mode.h / drm.h. No libdrm runtime or development package needed. */
#ifdef __linux__
typedef struct {
 uint64_t fb_id_ptr,crtc_id_ptr,connector_id_ptr,encoder_id_ptr;
 uint32_t count_fbs,count_crtcs,count_connectors,count_encoders;
 uint32_t min_width,max_width,min_height,max_height;
} NisKmsResources;
typedef struct {
 uint64_t encoders_ptr,modes_ptr,props_ptr,prop_values_ptr;
 uint32_t count_modes,count_props,count_encoders,encoder_id,connector_id;
 uint32_t connector_type,connector_type_id,connection,mm_width,mm_height,subpixel;
 uint32_t pad;
} NisKmsConnector;
typedef struct {
 uint32_t encoder_id,encoder_type,crtc_id,possible_crtcs,possible_clones;
} NisKmsEncoder;
typedef struct {
 uint64_t set_connectors_ptr;
 uint32_t count_connectors,crtc_id,fb_id,x,y,gamma_size,mode_valid;
 NisDrmMode mode;
} NisKmsCrtc;

#define NIS_DRM_IOCTL_RES _IOWR('d',0xA0,NisKmsResources)
#define NIS_DRM_IOCTL_CRTC _IOWR('d',0xA1,NisKmsCrtc)
#define NIS_DRM_IOCTL_ENCODER _IOWR('d',0xA6,NisKmsEncoder)
#define NIS_DRM_IOCTL_CONNECTOR _IOWR('d',0xA7,NisKmsConnector)

static int nis_drm_ioctl_probe(NisDrmActive *out){
 memset(out,0,sizeof *out);
 for(unsigned card=0;card<16;card++){
  char path[48];snprintf(path,sizeof path,"/dev/dri/card%u",card);
  int fd=open(path,O_RDONLY|O_CLOEXEC);
  if(fd<0)continue;
  NisKmsResources res={0};
  if(ioctl(fd,NIS_DRM_IOCTL_RES,&res)!=0||res.count_connectors==0||
     res.count_connectors>64||res.count_fbs>1024||
     res.count_crtcs>256||res.count_encoders>256){close(fd);continue;}
  /* GETRESOURCES fills ALL arrays whose counts are nonzero. Passing a count
     with a NULL destination caused EFAULT on Debian's Cirrus KVM driver. */
  uint32_t nfb=res.count_fbs,ncrtc=res.count_crtcs;
  uint32_t ncon=res.count_connectors,nenc=res.count_encoders;
  size_t total=(size_t)nfb+ncrtc+ncon+nenc;
  /* Typical desktop/VM has only a handful of KMS resource IDs. Avoid a
     per-launch heap allocation while preserving the four valid arrays that
     the Cirrus/KVM driver requires (the previous EFAULT regression). */
  uint32_t small[128]={0};
  uint32_t *all=total<=128?small:calloc(total,sizeof *all);
  if(!all){close(fd);continue;}
  uint32_t *ids=all+nfb+ncrtc;
  if(nfb)res.fb_id_ptr=(uint64_t)(uintptr_t)all;
  if(ncrtc)res.crtc_id_ptr=(uint64_t)(uintptr_t)(all+nfb);
  res.connector_id_ptr=(uint64_t)(uintptr_t)ids;
  if(nenc)res.encoder_id_ptr=(uint64_t)(uintptr_t)(ids+ncon);
  uint32_t capacity=ncon;
  if(ioctl(fd,NIS_DRM_IOCTL_RES,&res)!=0||res.count_connectors>capacity){
   if(all!=small){free(all);}
   close(fd);
   continue;
  }
  for(uint32_t i=0;i<res.count_connectors;i++){
   NisDrmMode first_mode={0};
   NisKmsConnector con={0};con.connector_id=ids[i];
   con.count_modes=1;con.modes_ptr=(uint64_t)(uintptr_t)&first_mode;
   if(ioctl(fd,NIS_DRM_IOCTL_CONNECTOR,&con)!=0||con.connection!=1)continue;
   if(con.encoder_id){
    NisKmsEncoder enc={0};enc.encoder_id=con.encoder_id;
    if(ioctl(fd,NIS_DRM_IOCTL_ENCODER,&enc)==0&&enc.crtc_id){
     NisKmsCrtc crtc={0};crtc.crtc_id=enc.crtc_id;
     if(ioctl(fd,NIS_DRM_IOCTL_CRTC,&crtc)==0&&crtc.mode_valid&&
        crtc.mode.hdisplay>=320&&crtc.mode.vdisplay>=200){
      out->width=crtc.mode.hdisplay;out->height=crtc.mode.vdisplay;
      out->hz=nis_drm_mode_hz(&crtc.mode);
      snprintf(out->connector,sizeof out->connector,"%s-%u",
               nis_drm_connector_type(con.connector_type),con.connector_type_id);
      if(all!=small){free(all);}
      close(fd);
      return 1;
     }
    }
   }
   /* A connector's mode list may exist even if there is no readable CRTC.
      Read it without forcing a hotplug probe, then match framebuffer size. */
   if(con.count_modes==0||con.count_modes>256)continue;
   NisDrmMode *modes=calloc(con.count_modes,sizeof *modes);
   if(!modes)continue;
   uint32_t mode_count=con.count_modes;
   NisKmsConnector modes_con={0};modes_con.connector_id=ids[i];
   modes_con.count_modes=mode_count;
   modes_con.modes_ptr=(uint64_t)(uintptr_t)modes;
   if(ioctl(fd,NIS_DRM_IOCTL_CONNECTOR,&modes_con)==0&&
      modes_con.count_modes<=mode_count&&modes_con.connection==1){
    unsigned fbw=0,fbh=0;char fb[64]="";
    FILE *fp=fopen("/sys/class/graphics/fb0/virtual_size","r");
    if(fp){if(fgets(fb,sizeof fb,fp))sscanf(fb,"%u,%u",&fbw,&fbh);fclose(fp);}
    for(uint32_t j=0;j<modes_con.count_modes;j++){
     NisDrmMode *m=&modes[j];
     if(m->hdisplay<320||m->vdisplay<200||!nis_drm_mode_hz(m))continue;
     if(fbw&&fbh&&(m->hdisplay!=fbw||m->vdisplay!=fbh))continue;
     out->width=m->hdisplay;out->height=m->vdisplay;
     out->hz=nis_drm_mode_hz(m);out->preferred=1;
     snprintf(out->connector,sizeof out->connector,"%s-%u",
              nis_drm_connector_type(modes_con.connector_type),modes_con.connector_type_id);
     break;
    }
   }
   free(modes);
   if(out->width){
    if(all!=small){free(all);}
    close(fd);
    return 1;
   }
  }
  if(all!=small){free(all);}
  close(fd);
 }
 return 0;
}
#else
static int nis_drm_ioctl_probe(NisDrmActive *out){(void)out;return 0;}
#endif
#endif
