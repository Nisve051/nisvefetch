#ifndef NIS_MEMORY_HW_H
#define NIS_MEMORY_HW_H

/* Fast, best-effort RAM metadata. There is no general unprivileged Linux API
 * for DIMM speed/type: EDAC is used when present, SMBIOS only when readable,
 * and a deliberately narrow desktop-platform inference is the final fallback.
 * No dmidecode process is launched. Unknown data is omitted, never invented.
 */
typedef struct {
 char type[24];
 char source[32];
 char manufacturer[96];
 char part[96];
 unsigned speed_mts;
 unsigned modules;
 unsigned slots;
} NisRamHardware;

static const char *nis_ram_kind(unsigned code){
 switch(code){
  case 0x12:return "DDR";
  case 0x13:return "DDR2";
  case 0x18:return "DDR3";
  case 0x1a:return "DDR4";
  case 0x1e:return "LPDDR4";
  case 0x22:return "DDR5";
  case 0x23:return "LPDDR5";
  case 0x1d:return "LPDDR3";
  default:return NULL;
 }
}
static void nis_ram_kind_text(const char *value,char *out,size_t cap){
 /* Check LPDDR before DDR so 'LPDDR5' is not confused with 'DDR5'. */
 static const char *types[]={"LPDDR5","LPDDR4","LPDDR3","DDR5","DDR4","DDR3","DDR2","DDR"};
 for(size_t i=0;i<sizeof types/sizeof types[0];i++){
  if(strstr(value,types[i])){snprintf(out,cap,"%s",types[i]);return;}
 }
}
static unsigned nis_ram_u16(const unsigned char *p){return (unsigned)p[0]|((unsigned)p[1]<<8);}
static void nis_ram_dmi_string(const unsigned char *start,const unsigned char *end,
                               unsigned index,char *out,size_t cap){
 if(!index||start>=end)return;
 const unsigned char *p=start;
 for(unsigned i=1;i<=index&&p<end;i++){
  size_t left=(size_t)(end-p);
  const unsigned char *nul=memchr(p,0,left);
  if(!nul||nul==p)return;
  if(i==index){
   size_t n=(size_t)(nul-p);if(n>=cap)n=cap-1;
   for(size_t j=0;j<n;j++)out[j]=p[j]>=32&&p[j]<127?(char)p[j]:' ';
   out[n]=0;return;
  }
  p=nul+1;
 }
}
static void nis_ram_from_dmi(NisRamHardware *out){
 const char *path=getenv("NISFETCH_TEST_DMI_PATH");
 if(!path||!*path)path="/sys/firmware/dmi/tables/DMI";
 FILE *f=fopen(path,"rb");if(!f)return;
 struct stat st;size_t cap=262144;
 if(fstat(fileno(f),&st)==0&&st.st_size>0&&st.st_size<=1048576)
  cap=(size_t)st.st_size;
 unsigned char *data=malloc(cap);if(!data){fclose(f);return;}
 size_t size=fread(data,1,cap,f);fclose(f);
 for(size_t off=0;off+4<=size;){
  unsigned type=data[off],len=data[off+1];
  if(len<4||off+len>size)break;
  size_t start=off+len,end=start;
  while(end+1<size&&(data[end]!=0||data[end+1]!=0))end++;
  if(end+1>=size)break;
  size_t next=end+2;
  if(type==17&&len>=0x17){
   out->slots++;
   const unsigned char *d=data+off;
   unsigned raw_size=nis_ram_u16(d+0x0c);
   if(raw_size&&raw_size!=0xffff){
    out->modules++;
    const char *kind=nis_ram_kind(d[0x12]);
    if(kind&&!*out->type){
     snprintf(out->type,sizeof out->type,"%s",kind);
     snprintf(out->source,sizeof out->source,"SMBIOS");
    }else if(kind&&*out->type&&strcmp(out->type,kind)){
     out->type[0]=0; /* heterogeneous DIMMs: don't assert one type */
    }
    unsigned mhz=nis_ram_u16(d+0x15);
    if(len>=0x22){unsigned configured=nis_ram_u16(d+0x20);
     if(configured&&configured!=0xffff)mhz=configured;
    }
    if(mhz&&mhz!=0xffff&&!out->speed_mts)out->speed_mts=mhz;
    if(len>0x17&&!*out->manufacturer)
     nis_ram_dmi_string(data+start,data+end+1,d[0x17],out->manufacturer,sizeof out->manufacturer);
    if(len>0x1a&&!*out->part)
     nis_ram_dmi_string(data+start,data+end+1,d[0x1a],out->part,sizeof out->part);
   }
  }
  off=next;
 }
 free(data);
}
static void nis_ram_from_edac(NisRamHardware *out){
 const char *root=getenv("NISFETCH_TEST_EDAC_ROOT");
 if(!root||!*root)root="/sys/devices/system/edac/mc";
 DIR *controllers=opendir(root);if(!controllers)return;
 struct dirent *mc;
 while((mc=readdir(controllers))){
  if(strncmp(mc->d_name,"mc",2))continue;
  char dirpath[PATH_MAX];
  if(snprintf(dirpath,sizeof dirpath,"%s/%s",root,mc->d_name)>=(int)sizeof dirpath)continue;
  DIR *dimms=opendir(dirpath);if(!dimms)continue;
  struct dirent *d;
  while((d=readdir(dimms))){
   if(strncmp(d->d_name,"dimm",4)&&strncmp(d->d_name,"rank",4))continue;
   char path[PATH_MAX];
   if(snprintf(path,sizeof path,"%s/%s/dimm_mem_type",dirpath,d->d_name)>=(int)sizeof path)continue;
   FILE *f=fopen(path,"r");if(!f)continue;
   char raw[128]="",kind[24]="";
   if(fgets(raw,sizeof raw,f))nis_ram_kind_text(raw,kind,sizeof kind);
   fclose(f);
   if(*kind){
    if(!*out->type){
     snprintf(out->type,sizeof out->type,"%s",kind);
     snprintf(out->source,sizeof out->source,"EDAC");
    }else if(strcmp(out->type,kind))out->type[0]=0;
   }
  }
  closedir(dimms);
 }
 closedir(controllers);
}
static void nis_ram_infer_desktop(const char *cpu,NisRamHardware *out){
 if(*out->type||!cpu)return;
 const char *ryzen=strstr(cpu,"Ryzen ");
 if(!ryzen||!strstr(cpu,"AMD "))return;
 unsigned tier=0,model=0;
 if(sscanf(ryzen,"Ryzen %u %u",&tier,&model)!=2)return;
 if(tier<3||tier>9||model<1000||model>9999)return;
 char suffix[32]="";
 const char *digits=strchr(ryzen,' ');
 if(!digits)return;
 digits++;while(isdigit((unsigned char)*digits))digits++;
 while(*digits==' ')digits++;
 while(isdigit((unsigned char)*digits))digits++;
 size_t i=0;while(isalpha((unsigned char)*digits)&&i+1<sizeof suffix)suffix[i++]=*digits++;
 suffix[i]=0;
 /* Ryzen desktop X/XT/X3D processors are socket-constrained.  Avoid mobile
  * U/H/HS/HX and non-X CPU models: DDR4/LPDDR alternatives may coexist. */
 if(suffix[0]!='X')return;
 if(model<6000)snprintf(out->type,sizeof out->type,"DDR4");
 else if(model>=7000)snprintf(out->type,sizeof out->type,"DDR5");
 if(*out->type)snprintf(out->source,sizeof out->source,"CPU-platform estimate");
}
static const NisRamHardware *nis_ram_hardware(const char *cpu){
 static NisRamHardware hw;static int initialized=0;
 if(!initialized){
  initialized=1;
  nis_ram_from_dmi(&hw);
  if(!*hw.type)nis_ram_from_edac(&hw);
  const char *fixture=getenv("NISFETCH_TEST_CPU_MODEL");
  if(fixture&&*fixture)cpu=fixture;
  if(!*hw.type)nis_ram_infer_desktop(cpu,&hw);
 }
 return &hw;
}
#endif
