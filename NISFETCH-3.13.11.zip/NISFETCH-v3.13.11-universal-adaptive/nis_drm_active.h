#ifndef NIS_DRM_ACTIVE_H
#define NIS_DRM_ACTIVE_H

/* Optional, read-only KMS probe through libdrm's stable runtime ABI.
   Local ABI descriptions follow xf86drmMode.h (MIT-licensed libdrm).
   No libdrm development headers or link-time dependency are required.
   A failed open, missing shared library or inactive CRTC is not an error. */
typedef struct {
 uint32_t clock;
 uint16_t hdisplay,hsync_start,hsync_end,htotal,hskew;
 uint16_t vdisplay,vsync_start,vsync_end,vtotal,vscan;
 uint32_t vrefresh,flags,type;
 char name[32];
} NisDrmMode;
typedef struct {
 int count_fbs;uint32_t *fbs;
 int count_crtcs;uint32_t *crtcs;
 int count_connectors;uint32_t *connectors;
 int count_encoders;uint32_t *encoders;
 uint32_t min_width,max_width,min_height,max_height;
} NisDrmRes;
typedef struct {
 uint32_t connector_id,encoder_id,connector_type,connector_type_id;
 int connection;
 uint32_t mmWidth,mmHeight;
 int subpixel,count_modes;
 NisDrmMode *modes;
 int count_props;uint32_t *props;uint64_t *prop_values;
 int count_encoders;uint32_t *encoders;
} NisDrmConnector;
typedef struct {
 uint32_t encoder_id,encoder_type,crtc_id,possible_crtcs,possible_clones;
} NisDrmEncoder;
typedef struct {
 uint32_t crtc_id,buffer_id,x,y,width,height;
 int mode_valid;
 NisDrmMode mode;
 int gamma_size;
} NisDrmCrtc;
typedef struct {unsigned width,height;double hz;char connector[32];int preferred;} NisDrmActive;

static double nis_drm_mode_hz(const NisDrmMode *m){
 double hz=m->vrefresh;
 if(hz<10&&m->clock&&m->htotal&&m->vtotal)
  hz=(double)m->clock*1000.0/((double)m->htotal*m->vtotal);
 return hz>=10&&hz<=1000?hz:0;
}

static const char *nis_drm_connector_type(unsigned type){
 switch(type){
  case 1:return "VGA";case 2:return "DVI-I";case 3:return "DVI-D";
  case 4:return "DVI-A";case 7:return "LVDS";case 10:return "DP";
  case 11:return "HDMI-A";case 12:return "HDMI-B";case 14:return "eDP";
  case 15:return "Virtual";case 16:return "DSI";case 20:return "USB";
  default:return "Display";
 }
}
static void nis_drm_connected_sysfs(char *out,size_t cap){
 out[0]=0;
#ifdef __linux__
 DIR *dir=opendir("/sys/class/drm");if(!dir)return;
 struct dirent *ent;
 while((ent=readdir(dir))){
  if(strncmp(ent->d_name,"card",4)||!strchr(ent->d_name,'-'))continue;
  char path[PATH_MAX],line[32]="";
  if(snprintf(path,sizeof path,"/sys/class/drm/%s/status",ent->d_name)>=(int)sizeof path)continue;
  FILE *f=fopen(path,"r");if(!f)continue;
  int ok=fgets(line,sizeof line,f)!=NULL;fclose(f);
  if(ok&&!strncmp(line,"connected",9)){
   snprintf(out,cap,"%s",strchr(ent->d_name,'-')+1);break;
  }
 }
 closedir(dir);
#else
 (void)cap;
#endif
}
static int nis_drm_active_probe(NisDrmActive *out){
#ifdef __linux__
 memset(out,0,sizeof *out);
 void *lib=dlopen("libdrm.so.2",RTLD_LAZY|RTLD_LOCAL);
 if(!lib)return 0;
 NisDrmRes *(*get_res)(int)=dlsym(lib,"drmModeGetResources");
 void (*free_res)(NisDrmRes *)=dlsym(lib,"drmModeFreeResources");
 NisDrmConnector *(*get_con)(int,uint32_t)=dlsym(lib,"drmModeGetConnectorCurrent");
 NisDrmConnector *(*get_con_full)(int,uint32_t)=dlsym(lib,"drmModeGetConnector");
 void (*free_con)(NisDrmConnector *)=dlsym(lib,"drmModeFreeConnector");
 NisDrmEncoder *(*get_enc)(int,uint32_t)=dlsym(lib,"drmModeGetEncoder");
 void (*free_enc)(NisDrmEncoder *)=dlsym(lib,"drmModeFreeEncoder");
 NisDrmCrtc *(*get_crtc)(int,uint32_t)=dlsym(lib,"drmModeGetCrtc");
 void (*free_crtc)(NisDrmCrtc *)=dlsym(lib,"drmModeFreeCrtc");
 if(!get_res||!free_res||!get_con||!get_con_full||!free_con||!get_enc||!free_enc||!get_crtc||!free_crtc){
  dlclose(lib);return 0;
 }
 int found=0;
 NisDrmActive preferred={0};
 for(unsigned card=0;card<16&&!found;card++){
  char device[48];snprintf(device,sizeof device,"/dev/dri/card%u",card);
  int fd=open(device,O_RDONLY|O_CLOEXEC);
  if(fd<0)continue;
  NisDrmRes *res=get_res(fd);
  if(res&&res->count_connectors>0&&res->count_connectors<=64){
   for(int i=0;i<res->count_connectors&&!found;i++){
    NisDrmConnector *con=get_con(fd,res->connectors[i]);
    if(!con)con=get_con_full(fd,res->connectors[i]);
    if(!con)continue;
    if(con->connection==1&&con->encoder_id){
     NisDrmEncoder *enc=get_enc(fd,con->encoder_id);
     if(enc&&enc->crtc_id){
      NisDrmCrtc *crtc=get_crtc(fd,enc->crtc_id);
      if(crtc&&crtc->mode_valid&&crtc->width>=320&&crtc->width<=20000&&
         crtc->height>=200&&crtc->height<=20000){
       double hz=nis_drm_mode_hz(&crtc->mode);
       out->width=crtc->width;out->height=crtc->height;
       if(hz>=10&&hz<=1000)out->hz=hz;
       snprintf(out->connector,sizeof out->connector,"%s-%u",
                nis_drm_connector_type(con->connector_type),con->connector_type_id);
       found=1;
      }
      if(crtc)free_crtc(crtc);
     }
     if(enc)free_enc(enc);
    }
    if(!found&&con->connection==1){
     /* Some virtual drivers expose a connected mode list but no active
        encoder/CRTC to unprivileged KMS queries. Fastfetch's libdrm result
        can still describe the preferred mode in this case. */
     NisDrmConnector *full=get_con_full(fd,con->connector_id);
     if(full&&full->connection==1&&full->count_modes>0&&full->count_modes<=256&&full->modes){
      unsigned fbw=0,fbh=0;char fb[64]="";
      FILE *fp=fopen("/sys/class/graphics/fb0/virtual_size","r");
      if(fp){if(fgets(fb,sizeof fb,fp))sscanf(fb,"%u,%u",&fbw,&fbh);fclose(fp);}
      int candidate=-1;
      for(int m=0;m<full->count_modes;m++){
       const NisDrmMode *mode=&full->modes[m];
       if(mode->hdisplay<320||mode->vdisplay<200||!nis_drm_mode_hz(mode))continue;
       if(fbw&&fbh&&mode->hdisplay==fbw&&mode->vdisplay==fbh){candidate=m;break;}
       if(candidate<0&&(mode->type&(1U<<3)))candidate=m;
      }
      if(candidate>=0&&!preferred.width){
       const NisDrmMode *mode=&full->modes[candidate];
       preferred.width=mode->hdisplay;preferred.height=mode->vdisplay;
       preferred.hz=nis_drm_mode_hz(mode);preferred.preferred=1;
       snprintf(preferred.connector,sizeof preferred.connector,"%s-%u",
                nis_drm_connector_type(full->connector_type),full->connector_type_id);
      }
     }
     if(full)free_con(full);
    }
    free_con(con);
   }
  }
  if(res)free_res(res);
  close(fd);
 }
 if(!found&&preferred.width){*out=preferred;found=1;}
 dlclose(lib);
 return found;
#else
 (void)out;return 0;
#endif
}
#endif
