"""NISFETCH 3.2.0: RAM and mountinfo fixtures, no privileged hardware needed."""
import os
import pathlib
import struct
import subprocess
import tempfile
import unittest


BIN = os.environ.get("NISFETCH_BIN", str(pathlib.Path.home() / ".local/bin/nisfetch"))


class HardwareDeepTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="nisfetch-v320-")
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.dmi = self.root / "DMI"
        self.dmi.write_bytes(b"")
        self.edac = self.root / "edac"
        self.edac.mkdir()
        self.mountinfo = self.root / "mountinfo"
        self.mountinfo.write_text(
            "20 1 8:1 / / rw,relatime - ext4 /dev/nvme0n1p2 rw\n"
            "21 20 8:2 / /home rw,relatime - btrfs /dev/sdb1 rw\n"
        )

    def run_fetch(self, *args, cpu="not-a-known-cpu"):
        env = os.environ.copy()
        env.update({
            "NISFETCH_TEST_CPU_MODEL": cpu,
            "NISFETCH_TEST_EDAC_ROOT": str(self.edac),
            "NISFETCH_TEST_DMI_PATH": str(self.dmi),
            "NISFETCH_TEST_MOUNTINFO": str(self.mountinfo),
            "XDG_CACHE_HOME": str(self.root / "cache"),
            "HOME": "/home/nisve",
        })
        return subprocess.run(
            [BIN, "--no-config", "--no-logo", *args],
            env=env, capture_output=True, text=True, check=True,
        ).stdout

    def test_platform_inference_for_nisve_ryzen_5700x(self):
        output = self.run_fetch("--modules", "memory:ramtype", cpu="AMD Ryzen 7 5700X 8-Core Processor")
        self.assertIn("| DDR4", output)
        self.assertIn("ramtype:", output)
        self.assertIn("DDR4", output)

    def test_does_not_guess_on_unknown_platform(self):
        output = self.run_fetch("--modules", "memory:ramtype")
        self.assertNotIn("| DDR", output)
        self.assertNotIn("ramtype:", output)

    def test_edac_ddr5_takes_precedence_over_cpu_guess(self):
        path = self.edac / "mc0" / "dimm0"
        path.mkdir(parents=True)
        (path / "dimm_mem_type").write_text("Unbuffered-DDR5\n")
        output = self.run_fetch("--modules", "memory:ramtype", cpu="AMD Ryzen 7 5700X 8-Core Processor")
        self.assertIn("| DDR5", output)
        self.assertNotIn("| DDR4", output)

    def test_smbios_type_17_speed_and_slots(self):
        # Populated Type 17: DDR4=0x1a, 16 GiB, 3200 MT/s configured;
        # plus one unpopulated slot. Header offset/layout per DMTF SMBIOS.
        d = bytearray(0x28)
        d[:4] = b"\x11\x28\x01\x00"
        d[0x0c:0x0e] = struct.pack("<H", 16384)
        d[0x12] = 0x1A
        d[0x15:0x17] = struct.pack("<H", 3200)
        d[0x20:0x22] = struct.pack("<H", 3200)
        d[0x17] = 1  # manufacturer string number
        d[0x1a] = 2  # part number string number
        first = bytes(d) + b"Kingston\0FURY-3200\0\0"
        d2 = bytearray(0x28)
        d2[:4] = b"\x11\x28\x02\x00"
        self.dmi.write_bytes(first + bytes(d2) + b"\0\0")
        output = self.run_fetch("--detailed", "--modules", "memory:ramtype:ramfrequency:ramslots:rammodules:rammanufacturer:rampart")
        for value in ("DDR4", "3200 MT/s", "1/2 DIMMs", "Kingston", "FURY-3200"):
            self.assertIn(value, output)

    def test_filesystem_names_in_both_disk_lines(self):
        output = self.run_fetch("--modules", "disk:homedisk")
        self.assertIn("[ext4]", output)
        self.assertIn("[btrfs]", output)

    def test_mount_specific_device_modules(self):
        output = self.run_fetch("--modules", "diskdevice:homedevice:homefilesystem:diskmountopts")
        self.assertIn("/dev/nvme0n1p2", output)
        self.assertIn("/dev/sdb1", output)
        self.assertIn("btrfs", output)
        self.assertIn("rw,relatime", output)

    def test_module_count_167(self):
        p = subprocess.run([BIN, "--list-modules"], capture_output=True, text=True, check=True)
        modules = p.stdout.splitlines()
        self.assertEqual(len(modules), 167)
        self.assertEqual(len(set(modules)), 167)


if __name__ == "__main__":
    unittest.main()
