"""Cold path should avoid process launches for ordinary Arch KDE defaults."""
from pathlib import Path
import unittest


SRC = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class ColdProcesses3133(unittest.TestCase):
    def test_system_arch_bash_uses_installed_package_metadata(self):
        self.assertIn('opendir("/var/lib/pacman/local")', SRC)
        self.assertIn('strcmp(resolved,"/usr/bin/bash")', SRC)
        self.assertIn('nis_arch_bash_version(binary,out,cap))return;', SRC)
        self.assertIn('execl(binary,binary,"--version"', SRC)

    def test_kde_font_native_fallback(self):
        setting = SRC.split('static void kde_setting(', 1)[1].split('static int is_kde(', 1)[0]
        self.assertLess(setting.index('kde_read(file,group,key,out,cap);'),
                        setting.index('!strcmp(key,"font"))return;'))
        self.assertLess(setting.index('!strcmp(key,"font"))return;'),
                        setting.index('kde_command(file,group,key,out,cap);'))
        self.assertIn('nis_fontconfig_family(font,fcap)', SRC)

    def test_easter_egg_and_drm_remain(self):
        self.assertIn('"1337.1337.1337"', SRC)
        self.assertIn('nis_drm_ioctl_probe(&drm)', SRC)


if __name__ == "__main__":
    unittest.main()
