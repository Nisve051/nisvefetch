/* Deterministic KVM-style ioctl regression: second GETRESOURCES must provide
   all four arrays, and the active VGA CRTC must return 1024x768 @ 60 Hz. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/ioctl.h>
#include "../nis_drm_active.h"

static int nis_mock_open(const char *path,int flags){
 (void)flags;return strcmp(path,"/dev/dri/card0")? -1:3;
}
static int nis_mock_close(int fd){(void)fd;return 0;}
static int nis_mock_ioctl(int fd,unsigned long cmd,void *arg);
#define open nis_mock_open
#define close nis_mock_close
#define ioctl nis_mock_ioctl
#include "../nis_drm_ioctl.h"
#undef open
#undef close
#undef ioctl

static int nis_mock_ioctl(int fd,unsigned long cmd,void *arg){
 if(fd!=3)return -1;
 if(cmd==NIS_DRM_IOCTL_RES){
  NisKmsResources *r=arg;
  if(r->connector_id_ptr){
   if(!r->fb_id_ptr||!r->crtc_id_ptr||!r->encoder_id_ptr)return -1;
   *(uint32_t *)(uintptr_t)r->fb_id_ptr=11;
   *(uint32_t *)(uintptr_t)r->crtc_id_ptr=22;
   *(uint32_t *)(uintptr_t)r->connector_id_ptr=31;
   *(uint32_t *)(uintptr_t)r->encoder_id_ptr=41;
  }
  r->count_fbs=r->count_crtcs=r->count_connectors=r->count_encoders=1;
  return 0;
 }
 if(cmd==NIS_DRM_IOCTL_CONNECTOR){
  NisKmsConnector *c=arg;
  if(c->connector_id!=31)return -1;
  c->connection=1;c->connector_type=1;c->connector_type_id=1;
  c->encoder_id=41;c->count_modes=1;return 0;
 }
 if(cmd==NIS_DRM_IOCTL_ENCODER){
  NisKmsEncoder *e=arg;if(e->encoder_id!=41)return -1;
  e->crtc_id=22;return 0;
 }
 if(cmd==NIS_DRM_IOCTL_CRTC){
  NisKmsCrtc *c=arg;if(c->crtc_id!=22)return -1;
  c->mode_valid=1;c->mode.hdisplay=1024;c->mode.vdisplay=768;
  c->mode.vrefresh=60;return 0;
 }
 return -1;
}

int main(void){
 NisDrmActive r={0};
 if(!nis_drm_ioctl_probe(&r))return 1;
 if(strcmp(r.connector,"VGA-1")||r.width!=1024||r.height!=768||r.hz!=60.0||r.preferred)return 2;
 puts("DRM ioctl mock: VGA-1 1024x768 60 Hz OK");return 0;
}
