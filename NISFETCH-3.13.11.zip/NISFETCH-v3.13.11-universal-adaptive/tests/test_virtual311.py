"""Regression checks for the 3.11 virtual-machine modules."""

import os
from pathlib import Path
import subprocess
import unittest


BIN = os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch"))


@unittest.skipUnless(Path(BIN).is_file(), "Build NISFETCH and set NISFETCH_BIN")
class Virtual311(unittest.TestCase):
    def fetch(self, *args):
        return subprocess.run(
            [BIN, "--no-config", "--no-logo", "--no-color", *args],
            check=True, capture_output=True, timeout=15, text=True,
        ).stdout

    def test_version_and_four_new_modules(self):
        self.assertEqual(self.fetch("--version").strip(), "NISFETCH 3.13.9")
        names = self.fetch("--list-modules").splitlines()
        self.assertEqual(len(names), 167)
        self.assertEqual(len(names), len(set(names)))
        for name in ("virtualgpu", "virtualdisplay", "hypervisor", "vmproduct"):
            self.assertIn(name, names)

    def test_explicit_virtual_modules_and_json(self):
        self.fetch("--modules", "virtualgpu:virtualdisplay:hypervisor:vmproduct")
        data = self.fetch("--json", "--modules", "virtualgpu:virtualdisplay:hypervisor:vmproduct")
        import json
        values = json.loads(data)
        self.assertIsInstance(values, (dict, list))

    def test_local_ip_easter_egg_is_unchanged(self):
        self.assertIn("1337.1337.1337", self.fetch("--modules", "localip"))


class SourceOrder311(unittest.TestCase):
    def test_read_first_declared_before_vm_probe(self):
        source = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()
        declaration = "static void read_first(const char *path,char *out,size_t cap);"
        self.assertLess(source.index(declaration), source.index("static void nis_vm_product("))


if __name__ == "__main__":
    unittest.main()
