"""NISFETCH 3.8.0 fast Pacman mode: CLI, JSONC and compatibility tests."""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


EXECUTABLE = Path(os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch")))


class PacmanFastModeTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.env = os.environ.copy()
        self.env["XDG_CACHE_HOME"] = str(self.root / "cache")
        self.env["XDG_STATE_HOME"] = str(self.root / "state")
        self.env["XDG_CONFIG_HOME"] = str(self.root / "config")

    def run_fetch(self, *args):
        return subprocess.run([str(EXECUTABLE), *args], env=self.env,
                              capture_output=True, timeout=20)

    def test_version_did_not_change(self):
        proc = self.run_fetch("--version")
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout.strip(), b"NISFETCH 3.13.9")

    def test_packages_modes_are_recognized(self):
        for mode in ("fast", "full"):
            with self.subTest(mode=mode):
                proc = self.run_fetch("--no-config", "--no-logo", "--packages-mode",
                                      mode, "--modules", "packages")
                self.assertEqual(proc.returncode, 0, proc.stderr)

    def test_bad_mode_is_rejected(self):
        proc = self.run_fetch("--packages-mode", "unsafe")
        self.assertEqual(proc.returncode, 2)
        self.assertIn(b"Unknown packages mode", proc.stderr)

    def test_config_accepts_fast_and_full(self):
        cfg = self.root / "config.jsonc"
        for mode in ("fast", "full"):
            with self.subTest(mode=mode):
                cfg.write_text(json.dumps({"packagesMode": mode}))
                proc = self.run_fetch("--config", str(cfg), "--check-config")
                self.assertEqual(proc.returncode, 0, proc.stderr)

    def test_invalid_config_mode_is_rejected(self):
        cfg = self.root / "config.jsonc"
        cfg.write_text('{"packagesMode": "unknown"}')
        proc = self.run_fetch("--config", str(cfg), "--check-config")
        self.assertEqual(proc.returncode, 2)
        self.assertIn(b"Invalid JSONC config", proc.stderr)

    def test_cli_overrides_config_mode(self):
        cfg = self.root / "config.jsonc"
        cfg.write_text('{"packagesMode": "full"}')
        proc = self.run_fetch("--config", str(cfg), "--packages-mode", "fast",
                              "--no-logo", "--modules", "packages")
        self.assertEqual(proc.returncode, 0, proc.stderr)

    def test_help_and_generated_config_document_mode(self):
        self.assertIn(b"--packages-mode fast|full", self.run_fetch("--help").stdout)
        self.assertIn(b"packagesMode", self.run_fetch("--gen-config").stdout)


if __name__ == "__main__":
    unittest.main()
