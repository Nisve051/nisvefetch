"""Cold-path guards: font lookup and absent KDE config files."""
from pathlib import Path
import unittest


SRC = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class ColdKde3132(unittest.TestCase):
    def test_fontconfig_without_subprocess_in_common_case(self):
        self.assertIn('dlopen("libfontconfig.so.1",RTLD_LAZY|RTLD_LOCAL)', SRC)
        self.assertIn('dlsym(lib,"FcFontMatch")', SRC)
        self.assertIn('if(!nis_fontconfig_family(font,fcap))', SRC)
        self.assertIn('command_first("fc-match', SRC)

    def test_no_kde_spawn_when_config_is_absent(self):
        self.assertIn('if(!kde_file_exists(file))return;', SRC)
        self.assertIn('kde_command(file,group,key,out,cap);', SRC)

    def test_preserve_core_data(self):
        self.assertIn('"1337.1337.1337"', SRC)
        self.assertIn('nis_drm_ioctl_probe(&drm)', SRC)


if __name__ == "__main__":
    unittest.main()
