"""Linux distribution and Termux regression fixtures (no Android device needed)."""

import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import time
import unittest


HERE = Path(__file__).parent


class CrossPlatformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        cls.bin = cls.dir / "platform-probe"
        cmd = [os.environ.get("CC", "cc"), "-std=c11", "-O2"]
        cmd += shlex.split(os.environ.get("NISFETCH_TEST_CPPFLAGS", ""))
        cmd += [str(HERE / "platform_probe39.c"), "-o", str(cls.bin)]
        cmd += shlex.split(os.environ.get("NISFETCH_TEST_LDFLAGS", "-lm -lpng -lgif -lz -ldl"))
        subprocess.run(cmd, check=True, capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def run_probe(self, *args, env=None):
        return subprocess.run([str(self.bin), *args], capture_output=True,
                              text=True, timeout=8, env=env, check=True).stdout.strip()

    def test_os_release_pretty_name_and_fallbacks(self):
        with tempfile.TemporaryDirectory() as name:
            file = Path(name) / "os-release"
            for raw, expected in [
                ('ID=alpine\nNAME="Alpine Linux"\nPRETTY_NAME="Alpine Linux 3.22"\n', "Alpine Linux 3.22"),
                ('ID=ubuntu\nNAME="Ubuntu"\n', "Ubuntu"),
                ('ID=void\n', "void"),
            ]:
                with self.subTest(raw=raw):
                    file.write_text(raw)
                    self.assertEqual(self.run_probe("os-release", str(file)), expected)

    def test_debian_dpkg_status_counts_only_installed(self):
        with tempfile.TemporaryDirectory() as name:
            file = Path(name) / "status"
            file.write_text("Package: a\nStatus: install ok installed\n\n"
                            "Package: b\nStatus: deinstall ok config-files\n\n"
                            "Package: c\nStatus: install ok installed\n\n")
            self.assertEqual(self.run_probe("dpkg", str(file)), "2")

    def test_alpine_apk_database_count(self):
        with tempfile.TemporaryDirectory() as name:
            file = Path(name) / "installed"
            file.write_text("C:Q1\nP:alpine-base\nV:3.22\n\nP:busybox\nV:1.36\n")
            self.assertEqual(self.run_probe("apk", str(file)), "2")

    def test_rpm_uses_direct_exec_without_shell(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            file = root / "rpm"
            file.write_text("#!/bin/sh\nprintf 'package-a\\npackage-b\\n'\n")
            file.chmod(0o755)
            env = os.environ.copy()
            env["PATH"] = f"{root}:{env.get('PATH', '')}"
            self.assertEqual(self.run_probe("rpm", env=env), "2")

    def test_termux_api_battery_json_and_timeout(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            file = root / "termux-battery-status"
            env = os.environ.copy()
            env["TERMUX_VERSION"] = "0.120"
            env["PATH"] = f"{root}:{env.get('PATH', '')}"
            file.write_text("#!/bin/sh\nprintf '{\"percentage\": 76, \"status\": \"CHARGING\"}\\n'\n")
            file.chmod(0o755)
            self.assertEqual(self.run_probe("battery", env=env), "76%")
            file.write_text("#!/bin/sh\nprintf '{\"percentage\": 999}'\n")
            self.assertEqual(self.run_probe("battery", env=env), "Unavailable")
            file.write_text("#!/bin/sh\nsleep 5\n")
            started = time.monotonic()
            self.assertEqual(self.run_probe("battery", env=env), "Unavailable")
            self.assertLess(time.monotonic()-started, 3.0)


if __name__ == "__main__":
    unittest.main()
