"""3.10.0: SSH, shell and non-GUI defaults remain useful and explicit modules work."""

import os
from pathlib import Path
import subprocess
import tempfile
import unittest


BIN = os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch"))


class Headless310(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = os.environ.copy()
        self.env["XDG_CACHE_HOME"] = self.tmp.name
        self.env["SSH_TTY"] = "/dev/pts/42"
        self.env["SSH_CONNECTION"] = "192.0.2.1 51000 192.0.2.2 22"
        self.env["SHELL"] = "/bin/bash"
        self.env["XDG_SESSION_TYPE"] = "tty"
        for key in ("DISPLAY", "WAYLAND_DISPLAY", "XDG_CURRENT_DESKTOP",
                    "XDG_SESSION_DESKTOP", "TERMUX_VERSION", "PREFIX"):
            self.env.pop(key, None)

    def fetch(self, *args, env=None):
        return subprocess.run([BIN, "--no-config", "--no-logo", "--no-color", *args],
                              env=env or self.env, capture_output=True, check=True,
                              timeout=15).stdout.decode()

    def test_ssh_default_does_not_advertise_nonexistent_desktop(self):
        output = self.fetch()
        self.assertIn("Session:        SSH", output)
        self.assertIn("Shell:          bash", output)
        self.assertIn("Terminal:       /dev/pts/42", output)
        for useless in ("Display", "Desktop", "WM", "GPU", "Font", "Plasma Theme"):
            # Virtual Display/GPU is meaningful even on headless VPSes.
            import re
            self.assertNotRegex(output, rf"(?m)^\s*{re.escape(useless)}:")
        self.assertIn("CPU:", output)
        self.assertIn("Memory:", output)

    def test_shell_is_the_identified_shell_and_version_is_cached(self):
        output = self.fetch("--modules", "shell")
        self.assertIn("Shell:", output)
        self.assertIn("bash", output)
        second = self.fetch("--modules", "shell")
        self.assertEqual(output, second)
        self.assertTrue(list(Path(self.tmp.name).rglob("shell-version-v310-bash*")))

    def test_explicit_desktop_and_display_still_work(self):
        output = self.fetch("--modules", "display:desktop:shell:terminal")
        self.assertIn("Display:", output)
        self.assertIn("Desktop:", output)
        self.assertIn("Shell:", output)
        self.assertIn("Terminal:", output)

    def test_graphical_desktop_retains_display_and_wm(self):
        env = self.env.copy()
        env["XDG_CURRENT_DESKTOP"] = "GNOME"
        env["XDG_SESSION_TYPE"] = "wayland"
        env["WAYLAND_DISPLAY"] = "wayland-0"
        output = self.fetch(env=env)
        self.assertIn("Display:", output)
        self.assertIn("Desktop:", output)
        self.assertIn("WM:", output)


if __name__ == "__main__":
    unittest.main()
