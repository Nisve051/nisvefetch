"""NISFETCH 3.8.0 micro optimizations keep existing user-facing behavior."""

import json
import os
import subprocess
import unittest


BIN = os.environ.get("NISFETCH_BIN", os.path.expanduser("~/.local/bin/nisfetch"))


class MicroHotfixTests(unittest.TestCase):
    def run_fetch(self, *args, env=None):
        return subprocess.run([BIN, "--no-config", "--no-logo", *args], env=env,
                              capture_output=True, text=True, timeout=20)

    def test_memory_snapshot_is_consistent(self):
        proc = self.run_fetch("--json", "--modules", "memtotal:memavailable:memused:mempercent")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertIn("memtotal", data)
        self.assertIn("memavailable", data)

    def test_username_fallback_without_user_env(self):
        env = os.environ.copy()
        env.pop("USER", None)
        proc = self.run_fetch("--modules", "title:os", env=env)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("@", proc.stdout)

    def test_package_modes_still_work(self):
        for mode in ("fast", "full"):
            with self.subTest(mode=mode):
                proc = self.run_fetch("--packages-mode", mode, "--modules", "packages")
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertIn("Packages", proc.stdout)


if __name__ == "__main__":
    unittest.main()
