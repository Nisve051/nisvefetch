"""Linux getdents64 fast path must preserve portable directory-count semantics."""

import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest


HERE = Path(__file__).parent


class DirectoryCountingTests(unittest.TestCase):
    def test_fast_scan_matches_portable_on_local_directory(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            folders = root / "packages"
            folders.mkdir()
            for idx in range(750):
                (folders / f"package-{idx:04d}-1.0-1").mkdir()
            (folders / "regular-file").write_text("x")
            (folders / ".hidden-directory").mkdir()
            (folders / "symlink").symlink_to(folders / "package-0000-1.0-1")
            binary = root / "dirscan-probe"
            cc = os.environ.get("CC", "cc")
            flags = shlex.split(os.environ.get("NISFETCH_TEST_CPPFLAGS", ""))
            libraries = shlex.split(os.environ.get("NISFETCH_TEST_LDFLAGS", "-lm -lpng -lgif -lz -ldl"))
            subprocess.run([cc, "-std=c11", "-O2", *flags,
                            str(HERE / "dirscan_probe.c"), "-o", str(binary), *libraries],
                           check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            result = subprocess.run([str(binary), str(folders)],
                                    capture_output=True, text=True, check=True)
            self.assertEqual(result.stdout.strip(), "750 750")


if __name__ == "__main__":
    unittest.main()
