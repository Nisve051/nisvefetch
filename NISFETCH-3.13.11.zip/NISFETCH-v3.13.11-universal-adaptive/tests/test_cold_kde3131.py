"""Regression guards for native KDE active-mode cold-cache fast path."""
from pathlib import Path
import unittest


SOURCE = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class ColdKde3131(unittest.TestCase):
    def test_active_drm_before_kscreen_fallback(self):
        body = SOURCE.split("static void kde_display(char *out,size_t cap){", 1)[1]
        body = body.split("static void wm_info(", 1)[0]
        self.assertLess(body.index("nis_drm_ioctl_probe(&drm)"),
                        body.index("nis_kscreen_current(&active)"))
        self.assertIn("!drm.preferred", body)
        self.assertIn('!getenv("NISFETCH_TEST_KSCREEN_FILE")', body)
        self.assertIn('"%ux%u @ %.2f Hz"', body)

    def test_virtual_display_and_local_ip_preserved(self):
        self.assertIn("static void nis_virtual_display(", SOURCE)
        self.assertIn('"1337.1337.1337"', SOURCE)


if __name__ == "__main__":
    unittest.main()
