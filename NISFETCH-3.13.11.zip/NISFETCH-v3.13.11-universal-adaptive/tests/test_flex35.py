"""NISFETCH 3.5.0: stable presets, precedence, and machine-readable output."""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


EXECUTABLE = Path(os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch")))


class FlexibleOutputTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.env = os.environ.copy()
        self.env["XDG_CACHE_HOME"] = str(self.root / "cache")
        self.env["XDG_CONFIG_HOME"] = str(self.root / "config")
        self.env["XDG_STATE_HOME"] = str(self.root / "state")

    def run_fetch(self, *args, env=None, check=True):
        return subprocess.run([str(EXECUTABLE), *args], env=env or self.env,
                              capture_output=True, timeout=25, check=check)

    def config(self, text):
        file = self.root / "test.jsonc"
        file.write_text(text, encoding="utf-8")
        return str(file)

    def test_presets_are_discoverable(self):
        output = self.run_fetch("--list-presets").stdout.decode().splitlines()
        self.assertEqual(output, ["auto", "compact", "balanced", "hardware",
                                  "network", "phone", "full"])

    def test_registered_modules_are_preserved(self):
        modules = self.run_fetch("--list-modules").stdout.decode().splitlines()
        self.assertEqual(len(modules), 167)
        self.assertEqual(len(set(modules)), 167)

    def test_compact_contains_essential_modules(self):
        output = self.run_fetch("--no-config", "--no-logo", "--preset", "compact").stdout.decode()
        self.assertIn("OS:", output)
        self.assertIn("Kernel:", output)
        self.assertIn("CPU:", output)
        self.assertIn("Memory:", output)
        self.assertNotIn("Plasma Theme:", output)
        self.assertLess(output.index("OS:"), output.index("Kernel:"))

    def test_preset_hardware_and_phone_validate(self):
        for name in ("hardware", "network", "phone", "full"):
            with self.subTest(preset=name):
                self.run_fetch("--no-config", "--no-logo", "--preset", name)

    def test_config_preset_and_manual_modules_priority(self):
        cfg = self.config('{"preset": "compact", "modules": ["memory", "os"]}')
        p = self.run_fetch("--config", cfg, "--no-logo")
        output = p.stdout.decode()
        self.assertIn("Memory:", output)
        self.assertIn("OS:", output)
        self.assertLess(output.index("Memory:"), output.index("OS:"))
        self.assertNotIn("Kernel:", output)

    def test_cli_preset_overrides_config_modules(self):
        cfg = self.config('{"modules": ["memory"]}')
        output = self.run_fetch("--config", cfg, "--no-logo", "--preset", "compact").stdout.decode()
        self.assertIn("Kernel:", output)
        self.assertLess(output.index("OS:"), output.index("Memory:"))

    def test_cli_modules_overrides_preset_config(self):
        cfg = self.config('{"preset": "compact"}')
        out = self.run_fetch("--config", cfg, "--no-logo", "--modules", "kernel").stdout.decode()
        self.assertIn("Kernel:", out)
        self.assertNotIn("Memory:", out)

    def test_cli_selection_last_flag_wins(self):
        out = self.run_fetch("--no-config", "--no-logo", "--preset", "compact",
                             "--modules", "memory").stdout.decode()
        self.assertIn("Memory:", out)
        self.assertNotIn("Kernel:", out)
        out = self.run_fetch("--no-config", "--no-logo", "--modules", "memory",
                             "--preset", "compact").stdout.decode()
        self.assertIn("Kernel:", out)

    def test_auto_bypasses_fixed_config_without_ignoring_hidden(self):
        cfg = self.config('{"modules": ["memory"], "hiddenModules": ["os"]}')
        output = self.run_fetch("--config", cfg, "--no-logo", "--preset", "auto").stdout.decode()
        self.assertIn("Kernel:", output)
        self.assertNotIn("OS:", output)

    def test_reject_invalid_config_preset(self):
        cfg = self.config('{"preset": "not-a-preset"}')
        out = self.run_fetch("--config", cfg, "--check-config", check=False)
        self.assertEqual(out.returncode, 2)
        self.assertIn(b"Invalid JSONC", out.stderr)

    def test_reject_invalid_cli_preset_and_format(self):
        for args in (("--preset", "bad"), ("--format", "bad")):
            with self.subTest(args=args):
                out = self.run_fetch("--no-config", *args, check=False)
                self.assertEqual(out.returncode, 2)
                self.assertIn(b"Unknown", out.stderr)

    def test_json_has_raw_values_without_terminal_markup(self):
        result = self.run_fetch("--no-config", "--json", "--modules", "memory:os:cpu")
        self.assertNotIn(b"\x1b", result.stdout)
        obj = json.loads(result.stdout)
        self.assertEqual(list(obj), ["memory", "os", "cpu"])
        self.assertIn("GiB", obj["memory"])
        self.assertNotIn("Memory:", obj["memory"])
        self.assertEqual(len(obj), 3)

    def test_json_handles_quotes_backslashes_and_unicode(self):
        env = self.env.copy()
        env["USER"] = 'Nisve "quote" \\ данные'
        obj = json.loads(self.run_fetch("--no-config", "--format", "json",
                                        "--modules", "title", env=env).stdout)
        self.assertIn('Nisve "quote" \\ данные', obj["title"])

    def test_json_stays_plain_in_a_color_terminal(self):
        import pty

        master, slave = pty.openpty()
        try:
            env = self.env.copy()
            env["TERM"] = "xterm-256color"
            env.pop("NO_COLOR", None)
            p = subprocess.Popen([str(EXECUTABLE), "--no-config", "--json", "--modules", "os"],
                                 env=env, stdout=slave, stderr=subprocess.DEVNULL)
            os.close(slave)
            slave = -1
            chunks = []
            while True:
                try:
                    data = os.read(master, 4096)
                except OSError:
                    break
                if not data:
                    break
                chunks.append(data)
            self.assertEqual(p.wait(timeout=10), 0)
            output = b"".join(chunks)
            self.assertNotIn(b"\x1b", output)
            self.assertIn("os", json.loads(output))
        finally:
            os.close(master)
            if slave >= 0:
                os.close(slave)

    def test_json_from_config_and_cli_text_override(self):
        cfg = self.config('{"preset": "compact", "display": {"format": "json"}}')
        output = self.run_fetch("--config", cfg, "--no-logo").stdout
        self.assertIn("os", json.loads(output))
        text = self.run_fetch("--config", cfg, "--format", "text", "--no-logo").stdout
        self.assertIn(b"OS:", text)
        self.assertFalse(text.lstrip().startswith(b"{"))

    def test_json_bypasses_unavailable_image(self):
        cfg = self.config('{"logo": {"image": "/missing/image.png"}}')
        out = self.run_fetch("--config", cfg, "--json", "--modules", "os")
        self.assertIn("os", json.loads(out.stdout))

    def test_profile_keeps_json_stdout_clean(self):
        out = self.run_fetch("--no-config", "--json", "--modules", "os", "--profile")
        self.assertIn("os", json.loads(out.stdout))
        self.assertIn(b"NISFETCH profile:", out.stderr)

    def test_custom_module_order_in_plain_text(self):
        out = self.run_fetch("--no-config", "--no-logo", "--modules", "memory:os").stdout.decode()
        self.assertLess(out.index("Memory:"), out.index("OS:"))

    def test_invalid_format_config_rejected(self):
        cfg = self.config('{"display": {"format": "xml"}}')
        self.assertEqual(self.run_fetch("--config", cfg, "--check-config", check=False).returncode, 2)

    def test_oversized_setting_is_not_silently_truncated(self):
        cfg = self.config('{"display": {"format": "' + "j" * 1100 + '"}}')
        out = self.run_fetch("--config", cfg, "--check-config", check=False)
        self.assertEqual(out.returncode, 2)
        self.assertIn(b"Invalid JSONC", out.stderr)

    def test_generated_config_is_valid_and_adaptive(self):
        generated = self.run_fetch("--gen-config").stdout.decode()
        cfg = self.config(generated)
        self.assertIn(b"Config OK", self.run_fetch("--config", cfg, "--check-config").stdout)
        output = self.run_fetch("--config", cfg, "--no-logo").stdout
        self.assertIn(b"Kernel:", output)

    def test_parallel_json_outputs_do_not_corrupt(self):
        from concurrent.futures import ThreadPoolExecutor

        def task(_):
            return json.loads(self.run_fetch("--no-config", "--json", "--preset", "compact").stdout)

        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(task, range(32)))
        self.assertTrue(all("os" in output and "cpu" in output for output in results))


if __name__ == "__main__":
    unittest.main()
