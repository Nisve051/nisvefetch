/* Compile the real source into a standalone harness to test its private
   package classifier against a temporary libalpm fixture. */
#define main nisfetch_app_main
#include "../nisfetch.c"
#undef main
int main(int argc,char **argv){
 if(argc!=3&&argc!=4)return 2;
 PacmanConfig config;
 if(!pacman_config_from(argv[1],&config))return 3;
 if(snprintf(config.dbpath,sizeof config.dbpath,"%s",argv[2])>=(int)sizeof config.dbpath)return 4;
 if(!pacman_db_files_ready(&config,time(NULL)))return 5;
 if(argc==4){
  if(!strcmp(argv[3],"stream-fast")){
   unsigned long count=0;
   if(!pacman_foreign_stream(&config,&count))return 10;
   printf("%lu\n",count);
   return 0;
  }
  if(!strcmp(argv[3],"native-fast")){
   unsigned long count=0;
   if(!pacman_foreign_libarchive(&config,&count))return 9;
   printf("%lu\n",count);
   return 0;
  }
  if(!strcmp(argv[3],"total-index")){
   char local[PATH_MAX];
   if(snprintf(local,sizeof local,"%s/local",config.dbpath)>=(int)sizeof local)return 8;
   printf("%lu\n",pacman_total_packages(&config,local));
   return 0;
  }
  if(!strcmp(argv[3],"total-valid")){
   uint64_t fingerprint=0;unsigned long count=0;
   if(pacman_db_fingerprint(&config,&fingerprint)&&pacman_total_read(fingerprint,&count))
    printf("valid:%lu\n",count);
   else puts("invalid");
   return 0;
  }
  if(!strcmp(argv[3],"state-valid")){
   uint64_t fingerprint=0;unsigned long count=0;
   if(pacman_db_fingerprint(&config,&fingerprint)&&pacman_index_read(fingerprint,&count))
    printf("valid:%lu\n",count);
   else puts("invalid");
   return 0;
  }
  if(!strcmp(argv[3],"use-state")){
   printf("%lu\n",foreign_packages(&config));
   return 0;
  }
  return 7;
 }
 unsigned long foreign=0;
 if(!pacman_foreign_libalpm(&config,&foreign))return 6;
 printf("%lu\n",foreign);
 return 0;
}
