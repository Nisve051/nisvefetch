/* Standalone build/smoke test without libpng, giflib or libdrm-dev. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/ioctl.h>
#include "../nis_drm_active.h"
#include "../nis_drm_ioctl.h"
#if defined(__has_include)
#if __has_include(<drm/drm_mode.h>)
#include <drm/drm_mode.h>
_Static_assert(sizeof(NisKmsConnector)==sizeof(struct drm_mode_get_connector),"DRM connector UAPI layout");
_Static_assert(sizeof(NisKmsCrtc)==sizeof(struct drm_mode_crtc),"DRM CRTC UAPI layout");
_Static_assert(sizeof(NisKmsResources)==sizeof(struct drm_mode_card_res),"DRM resource UAPI layout");
#endif
#endif

int main(void){
 NisDrmActive active={0};
 int found=nis_drm_ioctl_probe(&active)||nis_drm_active_probe(&active);
 if(found){
  if(active.width<320||active.height<200||!active.connector[0])return 1;
  printf("%s %ux%u %.2f Hz\n",active.connector,active.width,active.height,active.hz);
 }else puts("DRM active mode unavailable (valid fallback)");
 char con[64];nis_drm_connected_sysfs(con,sizeof con);
 return 0;
}
