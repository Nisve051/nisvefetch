"""Regressions for the 3.6.0 single-invocation kernel snapshots."""

import json
import os
from pathlib import Path
import subprocess
import unittest


FETCH = Path(os.environ.get("NISFETCH_BIN", Path.home() / ".local/bin/nisfetch"))


class Optimizer36Tests(unittest.TestCase):
    def run_fetch(self, *args):
        return subprocess.run(
            [str(FETCH), "--no-config", "--json", *args],
            check=True, capture_output=True, text=True,
        ).stdout

    def test_kernel_load_snapshot_is_consistent_within_output(self):
        obj = json.loads(self.run_fetch(
            "--modules", "load1:load5:load15:loadavg:cpuload:loadtasks:procsrunning:procstotal",
        ))
        for field in ("load1", "load5", "load15", "loadavg", "cpuload"):
            self.assertIn(field, obj)
        load = obj["loadavg"].split()
        self.assertEqual(load[:3], [obj[k] for k in ("load1", "load5", "load15")])
        self.assertEqual(obj["cpuload"].split(), load[:3])
        self.assertEqual(obj["loadtasks"],
                         f"{obj['procsrunning']}/{obj['procstotal']}")

    def test_in_place_sort_preserves_requested_order_and_values(self):
        keys = ("mempercent", "os", "load15", "kernel", "memused", "load1")
        obj = json.loads(self.run_fetch("--modules", ":".join(keys)))
        self.assertEqual(tuple(obj), keys)
        self.assertTrue(obj["os"])
        self.assertTrue(obj["kernel"])


if __name__ == "__main__":
    unittest.main()
