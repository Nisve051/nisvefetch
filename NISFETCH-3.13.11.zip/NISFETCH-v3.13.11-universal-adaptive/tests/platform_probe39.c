#define main nisfetch_application_main
#include "../nisfetch.c"
#undef main

int main(int argc,char **argv){
 if(argc<2)return 2;
 char value[256]="";
 if(!strcmp(argv[1],"os-release")&&argc==3){
  if(!osrelease_name_from(argv[2],value,sizeof value))return 3;
  puts(value);return 0;
 }
 if(!strcmp(argv[1],"dpkg")&&argc==3){
  printf("%lu\n",dpkg_installed_count(argv[2]));return 0;
 }
 if(!strcmp(argv[1],"apk")&&argc==3){
  printf("%lu\n",apk_installed_count(argv[2]));return 0;
 }
 if(!strcmp(argv[1],"battery")){
  int found=termux_battery_percentage(value,sizeof value);
  printf("%s\n",found?value:"Unavailable");return 0;
 }
 if(!strcmp(argv[1],"rpm")){
  printf("%lu\n",count_process_lines("rpm","-qa",NULL));return 0;
 }
 return 2;
}
