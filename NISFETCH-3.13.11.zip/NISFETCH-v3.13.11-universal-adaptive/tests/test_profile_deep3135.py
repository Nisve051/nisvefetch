"""Regression guards for opt-in low-overhead deep collection profiling."""
from pathlib import Path
import unittest


SOURCE = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class DeepProfile3135(unittest.TestCase):
    def test_flag_and_help(self):
        self.assertIn('!strcmp(argv[i],"--profile-deep")', SOURCE)
        self.assertIn('[--profile|--profile-deep]', SOURCE)
        self.assertIn('NISFETCH deep profile (ms):', SOURCE)

    def test_collects_hardware_and_kde_stages(self):
        for stage in ("CPU model", "CPU frequency", "CPU temperature",
                      "GPU detection", "GPU temperature", "Package counting",
                      "Memory and RAM hardware", "Display detection",
                      "KDE theme/font settings", "Optional system info",
                      "Optional virtualization/GPU", "Optional extra modules"):
            self.assertIn('NIS_DEEP_END("' + stage + '")', SOURCE)

    def test_profile_is_opt_in_and_core_output_preserved(self):
        self.assertIn('if(profile_deep)deep_started=now_ms()', SOURCE)
        self.assertIn('"1337.1337.1337"', SOURCE)
        self.assertIn('nis_drm_ioctl_probe(&drm)', SOURCE)


if __name__ == "__main__":
    unittest.main()
