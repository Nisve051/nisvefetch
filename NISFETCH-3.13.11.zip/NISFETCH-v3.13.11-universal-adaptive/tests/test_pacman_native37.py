"""Native compressed Pacman sync-db reader: exact names and invalidation."""

import ctypes.util
import ctypes
import io
import os
from pathlib import Path
import shlex
import subprocess
import tarfile
import tempfile
import unittest


TEST_DIR = Path(__file__).resolve().parent


def write_sync_db(path, names):
    with tarfile.open(path, "w:gz") as archive:
        for name in names:
            data = f"%NAME%\n{name.rsplit('-', 2)[0]}\n\n".encode()
            entry = tarfile.TarInfo(f"{name}/desc")
            entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))
            # Extra members must not inflate the installed-package count.
            extras = tarfile.TarInfo(f"{name}/files")
            extras.size = 1
            archive.addfile(extras, io.BytesIO(b"\n"))


def write_zstd_sync_db(path, names):
    library = ctypes.util.find_library("zstd")
    if not library:
        raise unittest.SkipTest("libzstd is optional")
    raw_archive = path.with_suffix(".tar")
    with tarfile.open(raw_archive, "w") as archive:
        for name in names:
            data = f"%NAME%\n{name.rsplit('-', 2)[0]}\n\n".encode()
            entry = tarfile.TarInfo(f"{name}/desc")
            entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))
    raw = raw_archive.read_bytes()
    zstd = ctypes.CDLL(library)
    zstd.ZSTD_compressBound.argtypes = [ctypes.c_size_t]
    zstd.ZSTD_compressBound.restype = ctypes.c_size_t
    zstd.ZSTD_compress.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                               ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    zstd.ZSTD_compress.restype = ctypes.c_size_t
    zstd.ZSTD_isError.argtypes = [ctypes.c_size_t]
    zstd.ZSTD_isError.restype = ctypes.c_uint
    buffer = ctypes.create_string_buffer(zstd.ZSTD_compressBound(len(raw)))
    encoded_size = zstd.ZSTD_compress(buffer, len(buffer), raw, len(raw), 3)
    if zstd.ZSTD_isError(encoded_size):
        raise RuntimeError("Could not compress synthetic sync DB")
    path.write_bytes(buffer.raw[:encoded_size])
    raw_archive.unlink()


@unittest.skipUnless(ctypes.util.find_library("archive"), "libarchive is optional")
class NativeArchive37Tests(unittest.TestCase):
    def test_accurate_foreign_count_and_repo_invalidation(self):
        compiler = os.environ.get("CC", "cc")
        cflags = shlex.split(os.environ.get("NISFETCH_TEST_CPPFLAGS", ""))
        ldflags = shlex.split(os.environ.get(
            "NISFETCH_TEST_LDFLAGS", "-lm -lpng -lgif -lz -ldl"))
        with tempfile.TemporaryDirectory(prefix="nisfetch-native-37-") as tmp:
            root = Path(tmp)
            probe = root / "probe"
            subprocess.run([compiler, "-std=c11", "-O2", *cflags,
                            str(TEST_DIR / "pacman_probe.c"), "-o", str(probe),
                            *ldflags], check=True, capture_output=True)
            db = root / "db"
            (db / "sync").mkdir(parents=True)
            (db / "local").mkdir()
            installed = ("bash-5.3-1", "nano-8.2-1", "aur-fancy-2.0-1", "foo-bar-1.2-1")
            for package in installed:
                (db / "local" / package).mkdir()
            write_sync_db(db / "sync/core.db", ["bash-5.3-1"])
            write_sync_db(db / "sync/extra.db", ["nano-8.2-1"])
            config = root / "pacman.conf"
            config.write_text("[options]\nArchitecture = auto\n[core]\n[extra]\n")
            env = os.environ.copy()
            env["XDG_STATE_HOME"] = str(root / "state")
            env["XDG_CACHE_HOME"] = str(root / "cache")

            def run(mode):
                return subprocess.run([str(probe), str(config), str(db), mode],
                                      env=env, capture_output=True, text=True,
                                      check=True).stdout.strip()

            self.assertEqual(run("native-fast"), "2")
            self.assertEqual(run("stream-fast"), "2")
            self.assertEqual(run("use-state"), "2")
            index = root / "state/nisfetch/pacman-foreign.index"
            self.assertTrue(index.is_file())
            self.assertEqual(run("state-valid"), "valid:2")

            # Sync DB update must invalidate the persistent index and update
            # the exact result even if the installed directory has not moved.
            write_sync_db(db / "sync/extra.db", ["nano-8.2-1", "aur-fancy-2.0-1"])
            self.assertEqual(run("state-valid"), "invalid")
            self.assertEqual(run("native-fast"), "1")
            self.assertEqual(run("stream-fast"), "1")
            self.assertEqual(run("use-state"), "1")
            self.assertEqual(run("state-valid"), "valid:1")

            # Arch's common zstd-compressed sync DBs use the same streaming
            # reader; packages with hyphenated names must remain exact.
            write_zstd_sync_db(db / "sync/core.db", ["bash-5.3-1", "foo-bar-1.2-1"])
            self.assertEqual(run("stream-fast"), "0")
            self.assertEqual(run("state-valid"), "invalid")
            self.assertEqual(run("use-state"), "0")

            # A valid PAX extension is deliberately outside our tiny parser.
            # The libarchive path must still return the correct count.
            with tarfile.open(db / "sync/extra.db", "w:gz", format=tarfile.PAX_FORMAT) as archive:
                data = b"%NAME%\nnano\n\n"
                member = tarfile.TarInfo("nano-8.2-1/desc")
                member.size = len(data)
                member.pax_headers = {"comment": "test safe fallback"}
                archive.addfile(member, io.BytesIO(data))
            self.assertNotEqual(subprocess.run(
                [str(probe), str(config), str(db), "stream-fast"],
                env=env, capture_output=True,
            ).returncode, 0)
            self.assertEqual(run("native-fast"), "1")


if __name__ == "__main__":
    unittest.main()
