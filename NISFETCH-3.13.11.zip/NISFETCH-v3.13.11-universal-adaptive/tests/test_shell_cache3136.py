"""Persistent Bash cache uses metadata validation, not an assumed version."""
from pathlib import Path
import unittest


SOURCE = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class ShellIndex3136(unittest.TestCase):
    def test_validation_and_atomic_update(self):
        body = SOURCE.split('static int nis_arch_bash_index(', 1)[1]
        body = body.split('/* Arch pacman', 1)[0]
        for token in ('bin.st_ino', 'bin.st_size', 'bin.st_mtim',
                      'db.st_ctim', 'mkstemp(temp)', 'rename(temp,path)'):
            self.assertIn(token, body)

    def test_system_bash_only_and_fallback_retained(self):
        self.assertIn('strcmp(resolved,"/usr/bin/bash")', SOURCE)
        self.assertIn('nis_arch_bash_index(resolved,out,cap,0)', SOURCE)
        self.assertIn('nis_arch_bash_index(resolved,out,cap,1)', SOURCE)
        self.assertIn('execl(binary,binary,"--version"', SOURCE)


if __name__ == "__main__":
    unittest.main()
