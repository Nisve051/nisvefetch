"""Konsole GIF worker is opt-in by selected image, scoped to the launching TTY."""
from pathlib import Path
import unittest


SRC = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class GifInline3139(unittest.TestCase):
    def test_animation_controls(self):
        for opt in ('--animate-inline', '--stop-animation', '--no-animate',
                    '--animate-preview', '--animate-cycles'):
            self.assertIn(opt, SRC)
        self.assertIn('start_gif_worker(cfg_image_path,&user_image', SRC)

    def test_tux_default_and_static_gif(self):
        self.assertIn('gif_inline=show_image&&!animate_preview&&animate_cycles!=-2', SRC)
        self.assertIn('user_image.gif&&user_image.gif->ImageCount>1', SRC)
        self.assertIn('show_tux=visible&&!pixlogo&&!has_custom_image', SRC)

    def test_runtime_directory_and_process_identity(self):
        for code in ('XDG_RUNTIME_DIR', 'st.st_uid!=getuid()', 'O_NOFOLLOW',
                     'getpgid(pid)==pid', 'kill(-pid,SIGTERM)',
                     'if(kill(shell,0)<0&&errno==ESRCH)'):
            self.assertIn(code, SRC)


if __name__ == "__main__":
    unittest.main()
