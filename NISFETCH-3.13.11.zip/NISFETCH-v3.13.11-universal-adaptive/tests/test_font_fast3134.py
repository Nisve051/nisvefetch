"""Preserve Qt-first font accuracy and GTK-origin labeling."""
from pathlib import Path
import unittest


SRC = (Path(__file__).resolve().parents[1] / "nisfetch.c").read_text()


class FontFast3134(unittest.TestCase):
    def test_gtk_explicit_setting_before_fontconfig(self):
        section = SRC.split('if(want_font){\n  kde_setting("kdeglobals"', 1)[1]
        section = section.split('if(want_cursor)', 1)[0]
        self.assertLess(section.index('nis_gtk_font_setting(font,fcap)'),
                        section.index('nis_fontconfig_family(font,fcap)'))
        self.assertIn('" (GTK settings)"', section)
        self.assertIn('" (fontconfig)"', section)

    def test_gtk_file_and_environment(self):
        self.assertIn('getenv("GTK_FONT_NAME")', SRC)
        self.assertIn('gtk-3.0/settings.ini', SRC)
        self.assertIn('"gtk-font-name"', SRC)


if __name__ == "__main__":
    unittest.main()
