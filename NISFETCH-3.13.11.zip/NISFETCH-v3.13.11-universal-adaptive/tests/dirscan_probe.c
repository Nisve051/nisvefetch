#define main nisfetch_original_main
#include "../nisfetch.c"
#undef main

int main(int argc,char **argv){
 if(argc!=2&&argc!=3)return 2;
 if(argc==3){
  volatile unsigned long consume=0;
  double start=now_ms();
  for(int i=0;i<500;i++)consume+=count_subdirs_portable(argv[1]);
  double slow=now_ms()-start;
  start=now_ms();
  for(int i=0;i<500;i++)consume+=count_subdirs(argv[1]);
  printf("portable %.3f ms, fast %.3f ms, checksum %lu\n",slow,now_ms()-start,consume);
  return 0;
 }
 unsigned long slow=count_subdirs_portable(argv[1]);
 unsigned long fast=count_subdirs(argv[1]);
 printf("%lu %lu\n",slow,fast);
 return slow==fast?0:1;
}
