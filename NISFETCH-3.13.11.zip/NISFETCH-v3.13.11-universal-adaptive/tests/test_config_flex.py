"""NISFETCH 3.4.0 flexible config: order, labels, colors, CLI and safety."""

import json
import os
import pathlib
import pty
import re
import subprocess
import tempfile
import unittest


BIN = os.environ.get("NISFETCH_BIN", str(pathlib.Path.home() / ".local/bin/nisfetch"))


class ConfigFlexTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="nisfetch-config-")
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.config = self.root / "config.jsonc"

    def run_fetch(self, *args, data=None, tty=False):
        if data is not None:
            self.config.write_text(json.dumps(data, ensure_ascii=False))
        env = os.environ.copy()
        env.update({
            "HOME": str(self.root),
            "XDG_CONFIG_HOME": str(self.root / ".config"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
            "LANG": "C.UTF-8",
        })
        env.pop("NO_COLOR", None)
        argv = [BIN, "--no-logo", *args]
        if tty:
            master, slave = pty.openpty()
            try:
                completed = subprocess.run(argv, env=env, stdout=slave, stderr=subprocess.PIPE)
                os.close(slave)
                slave = -1
                chunks = []
                while True:
                    try:
                        chunk = os.read(master, 8192)
                    except OSError:
                        break
                    if not chunk:
                        break
                    chunks.append(chunk)
                return completed.returncode, b"".join(chunks).decode(errors="replace"), completed.stderr.decode(errors="replace")
            finally:
                if slave >= 0:
                    os.close(slave)
                os.close(master)
        p = subprocess.run(argv, env=env, capture_output=True, text=True)
        return p.returncode, p.stdout, p.stderr

    def test_default_config_path_and_create_once(self):
        code, stdout, _ = self.run_fetch("--config-path")
        self.assertEqual(code, 0)
        self.assertEqual(stdout.strip(), str(self.root / ".config/nisfetch/config.jsonc"))
        code, stdout, _ = self.run_fetch("--init-config")
        self.assertEqual(code, 0)
        self.assertIn("Created:", stdout)
        path = self.root / ".config/nisfetch/config.jsonc"
        self.assertTrue(path.exists())
        self.assertNotRegex(path.read_text(), r'(?m)^\s*"modules"\s*:')
        code, stdout, _ = self.run_fetch("--check-config")
        self.assertEqual((code, stdout.strip()), (0, "Config OK"))
        original = path.read_bytes()
        code, _, error = self.run_fetch("--init-config")
        self.assertEqual(code, 2)
        self.assertIn("Config not created", error)
        self.assertEqual(path.read_bytes(), original)

    def test_generated_config_is_valid(self):
        code, stdout, _ = self.run_fetch("--gen-config")
        self.assertEqual(code, 0)
        self.assertIn('"theme": "vivid"', stdout)
        self.config.write_text(stdout)
        code, stdout, _ = self.run_fetch("--config", str(self.config), "--check-config")
        self.assertEqual((code, stdout.strip()), (0, "Config OK"))

    def test_custom_labels_unicode_and_order(self):
        data = {
            "display": {"labelWidth": 22},
            "modules": ["memory", "cpu", "os"],
            "moduleLabels": {"memory": "Оперативка", "cpu": "Процессор"},
        }
        code, out, _ = self.run_fetch("--config", str(self.config), data=data)
        self.assertEqual(code, 0)
        lines = [line for line in out.splitlines() if line.strip()]
        self.assertTrue(lines[0].startswith("Оперативка:"), out)
        self.assertTrue(lines[1].startswith("Процессор:"), out)
        self.assertTrue(lines[2].startswith("OS:"), out)

    def test_hidden_default_module_and_cli_override(self):
        data = {"hiddenModules": ["cpu", "gpu"]}
        code, out, _ = self.run_fetch("--config", str(self.config), data=data)
        self.assertEqual(code, 0)
        self.assertNotRegex(out, r"(?m)^CPU:\s")
        self.assertNotRegex(out, r"(?m)^GPU:\s")
        code, out, _ = self.run_fetch("--config", str(self.config), "--modules", "cpu:memory")
        self.assertEqual(code, 0)
        self.assertRegex(out, r"(?m)^CPU:\s")

    def test_module_color_values_and_bold_tty(self):
        data = {
            "display": {"theme": "vivid", "keyBold": True, "valueBold": True},
            "moduleColors": {"cpu": "#123456"},
            "moduleValueColors": {"cpu": "#abcdef"},
        }
        code, out, _ = self.run_fetch("--config", str(self.config), "--modules", "cpu", data=data, tty=True)
        self.assertEqual(code, 0)
        self.assertIn("\x1b[1;38;2;18;52;86m", out)
        self.assertIn("\x1b[1;38;2;171;205;239m", out)

    def test_cli_theme_overrides_config_custom_rgb(self):
        data = {"display": {"theme": "soft", "keyColor": "#112233", "valueColor": "#223344"}}
        code, out, _ = self.run_fetch("--config", str(self.config), "--theme", "mono", "--modules", "os", data=data, tty=True)
        self.assertEqual(code, 0)
        self.assertIn("\x1b[1;38;2;232;238;246m", out)
        self.assertIn("\x1b[1;38;2;255;255;255m", out)
        self.assertNotIn("\x1b[1;38;2;17;34;51m", out)

    def test_rejects_invalid_hex_and_control_char_labels(self):
        for data in (
            {"display": {"valueColor": "#ffffzz"}},
            {"display": {"labelWidth": "forty"}},
            {"display": {"palette": "perhaps"}},
            {"moduleLabels": {"cpu": "evil\x1b[2J"}},
            {"moduleColors": {"cpu": "red"}},
        ):
            code, _, err = self.run_fetch("--config", str(self.config), "--check-config", data=data)
            self.assertNotEqual(code, 0, data)
            self.assertIn("Invalid JSONC", err)

    def test_no_color_has_no_escape_sequences(self):
        data = {"display": {"valueColor": "#ff00ff", "valueBold": True}}
        code, out, _ = self.run_fetch("--config", str(self.config), "--no-color", data=data, tty=True)
        self.assertEqual(code, 0)
        self.assertNotIn("\x1b[", out)

    def test_adaptive_default_modules_when_no_module_array(self):
        data = {"display": {"theme": "vivid"}}
        code, out, _ = self.run_fetch("--config", str(self.config), data=data)
        self.assertEqual(code, 0)
        self.assertRegex(out, r"(?m)^CPU Cores:")
        self.assertRegex(out, r"(?m)^Processes:")


if __name__ == "__main__":
    unittest.main()
