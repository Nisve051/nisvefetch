#ifndef NIS_MOUNT_HW_H
#define NIS_MOUNT_HW_H

/* Mountinfo is namespace-aware, unprivileged, and doesn't require invoking
 * findmnt/lsblk. Resolve the longest mount prefix for / and /home separately.
 */
typedef struct {
 char filesystem[64];
 char source[256];
 char mountpoint[PATH_MAX];
 char options[192];
} NisMountHardware;

static void nis_mount_unescape(char *s){
 char *out=s;
 for(char *p=s;*p;p++){
  if(*p=='\\'&&p[1]>='0'&&p[1]<='7'&&
     p[2]>='0'&&p[2]<='7'&&p[3]>='0'&&p[3]<='7'){
   *out++=(char)((p[1]-'0')*64+(p[2]-'0')*8+(p[3]-'0'));
   p+=3;
  }else *out++=*p;
 }
 *out=0;
}
static int nis_mount_prefix(const char *path,const char *mountpoint){
 size_t n=strlen(mountpoint);
 return n&&strncmp(path,mountpoint,n)==0&&
  (mountpoint[n-1]=='/'||path[n]=='/'||path[n]==0);
}
static int nis_mount_hardware(const char *path,NisMountHardware *out){
 memset(out,0,sizeof *out);
 const char *fixture=getenv("NISFETCH_TEST_MOUNTINFO");
 FILE *f=fopen(fixture&&*fixture?fixture:"/proc/self/mountinfo","r");
 if(!f)return 0;
 char line[16384];size_t best=0;
 while(fgets(line,sizeof line,f)){
  char *sep=strstr(line," - ");if(!sep)continue;
  *sep=0;char *right=sep+3;
  char *save=NULL,*mountpoint=NULL,*opts=NULL,*item;
  int index=0;
  for(item=strtok_r(line," ",&save);item;item=strtok_r(NULL," ",&save)){
   if(index==4)mountpoint=item;
   if(index==5)opts=item;
   index++;
  }
  if(!mountpoint||!opts)continue;
  nis_mount_unescape(mountpoint);
  size_t n=strlen(mountpoint);
  if(!nis_mount_prefix(path,mountpoint)||n<best)continue;
  char *right_save=NULL;
  char *fs=strtok_r(right," \n",&right_save);
  char *source=strtok_r(NULL," \n",&right_save);
  if(!fs||!source)continue;
  best=n;
  snprintf(out->filesystem,sizeof out->filesystem,"%s",fs);
  snprintf(out->source,sizeof out->source,"%s",source);
  nis_mount_unescape(out->source);
  snprintf(out->mountpoint,sizeof out->mountpoint,"%s",mountpoint);
  snprintf(out->options,sizeof out->options,"%s",opts);
 }
 fclose(f);
 return best>0;
}
static void nis_mount_inode_usage(const char *path,char *out,size_t cap){
 struct statvfs s;
 if(statvfs(path,&s)!=0||!s.f_files)return;
 unsigned long long used=(unsigned long long)(s.f_files-s.f_ffree);
 snprintf(out,cap,"%llu/%llu (%.0f%%)",used,(unsigned long long)s.f_files,
          100.0*(double)used/(double)s.f_files);
}
#endif
