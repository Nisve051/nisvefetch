#ifndef NIS_MONITOR_H
#define NIS_MONITOR_H

/* Lightweight EDID reader. No libdrm, subprocess, desktop session or root
 * access is required to identify a connected monitor when DRM sysfs exposes
 * readable EDID. EDID timings describe a preferred mode, NOT the current mode.
 */
typedef struct {
 char vendor[48];
 char vendor_id[4];
 char model[100];
 char connector[64];
 unsigned width_mm, height_mm;
 unsigned preferred_width, preferred_height;
 double preferred_hz;
 unsigned connected;
 int valid_edid;
} NisMonitor;

static const char *nis_edid_vendor(const char *id){
 struct {const char *id,*name;} map[]={
  {"ACR","Acer"},{"ACI","ASUS"},{"AOC","AOC"},{"APP","Apple"},
  {"ASU","ASUS"},{"AUO","AU Optronics"},{"BNQ","BenQ"},
  {"BOE","BOE"},{"CMN","Innolux"},{"CMO","Chi Mei"},
  {"DEL","Dell"},{"EPI","Envision"},{"FUS","Fujitsu"},
  {"GSM","LG"},{"HSD","HannStar"},{"HWP","HP"},
  {"HPN","HP"},{"HPQ","HP"},{"IBM","IBM"},
  {"IVO","InfoVision"},{"LEN","Lenovo"},{"LGD","LG Display"},
  {"MEI","Panasonic"},{"MSI","MSI"},{"NEC","NEC"},
  {"PHL","Philips"},{"SAM","Samsung"},{"SDC","Samsung"},
  {"SEC","Samsung Display"},{"SHP","Sharp"},{"SNY","Sony"},
  {"TCL","TCL"},{"VSC","ViewSonic"},{"VIZ","Vizio"}
 };
 for(size_t i=0;i<sizeof map/sizeof map[0];i++)
  if(!strcmp(id,map[i].id))return map[i].name;
 return id;
}

static int nis_edid_parse(const unsigned char *e,size_t size,NisMonitor *out){
 static const unsigned char magic[8]={0x00,0xff,0xff,0xff,0xff,0xff,0xff,0x00};
 if(size<128||memcmp(e,magic,sizeof magic)!=0)return 0;
 unsigned sum=0;for(int i=0;i<128;i++)sum+=e[i];
 if(sum&255)return 0; /* avoid displaying corrupt/untrusted EDID */
 unsigned word=((unsigned)e[8]<<8)|e[9];
 for(int i=0;i<3;i++){
  unsigned shift=10-(unsigned)i*5;
  unsigned ch=(word>>shift)&31;
  if(ch<1||ch>26)return 0;
  out->vendor_id[i]=(char)('A'+ch-1);
 }
 out->vendor_id[3]=0;
 snprintf(out->vendor,sizeof out->vendor,"%s",nis_edid_vendor(out->vendor_id));
 out->width_mm=(unsigned)e[21]*10;
 out->height_mm=(unsigned)e[22]*10;
 for(int i=0;i<4;i++){
  const unsigned char *d=e+54+i*18;
  if(d[0]==0&&d[1]==0&&d[2]==0&&d[3]==0xfc){
   size_t j=0;
   for(size_t p=5;p<18&&j+1<sizeof out->model;p++){
    unsigned char c=d[p];
    if(c=='\n'||c=='\r'||c==0)break;
    if(c<32||c>126)continue;
    out->model[j++]=(char)c;
   }
   while(j&&out->model[j-1]==' ')j--;
   out->model[j]=0;
  }
 }
 /* Base-block first detailed timing is normally the preferred mode. */
 const unsigned char *d=e+54;
 unsigned clock=((unsigned)d[0]|((unsigned)d[1]<<8))*10000;
 unsigned hact=(unsigned)d[2]|(((unsigned)d[4]&0xf0)<<4);
 unsigned hblank=(unsigned)d[3]|(((unsigned)d[4]&0x0f)<<8);
 unsigned vact=(unsigned)d[5]|(((unsigned)d[7]&0xf0)<<4);
 unsigned vblank=(unsigned)d[6]|(((unsigned)d[7]&0x0f)<<8);
 if(clock>1000000&&hact>=320&&vact>=200&&hact+hblank&&vact+vblank){
  out->preferred_width=hact;
  out->preferred_height=vact;
  out->preferred_hz=(double)clock/((double)(hact+hblank)*(vact+vblank));
  if(out->preferred_hz<10.0||out->preferred_hz>1000.0)out->preferred_hz=0;
 }
 out->valid_edid=1;
 return 1;
}

static void nis_monitor_probe(NisMonitor *out){
 memset(out,0,sizeof *out);
 const char *root=getenv("NISFETCH_TEST_DRM_ROOT");
 if(!root||!*root)root="/sys/class/drm";
 DIR *dir=opendir(root);if(!dir)return;
 struct dirent *ent;
 while((ent=readdir(dir))){
  if(strncmp(ent->d_name,"card",4))continue;
  if(!strchr(ent->d_name,'-'))continue;
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"%s/%s/status",root,ent->d_name)>=(int)sizeof path)continue;
  FILE *status=fopen(path,"r");if(!status)continue;
  char value[24]={0};int ok=fgets(value,sizeof value,status)!=NULL;
  fclose(status);
  if(!ok||strncmp(value,"connected",9)||!strchr("\n\r\0",value[9]))continue;
  out->connected++;
  if(out->valid_edid)continue;
  if(snprintf(path,sizeof path,"%s/%s/edid",root,ent->d_name)>=(int)sizeof path)continue;
  FILE *file=fopen(path,"rb");if(!file)continue;
  unsigned char edid[128];size_t got=fread(edid,1,sizeof edid,file);
  fclose(file);
  NisMonitor candidate={0};
  if(nis_edid_parse(edid,got,&candidate)){
   snprintf(candidate.connector,sizeof candidate.connector,"%s",strchr(ent->d_name,'-')+1);
   candidate.connected=out->connected;
   unsigned count=out->connected;
   *out=candidate;
   out->connected=count;
  }
 }
 closedir(dir);
}
#endif
