/* NISFETCH 3.8: low-overhead streaming scanner for standard gzip/zstd tar
   Pacman sync databases. Included by nisfetch.c after its exact-name set.
   The entire archive and checksum are consumed. Unsupported variants fall
   through to the proven libarchive / libalpm implementations. */
#ifndef NIS_PACMAN_STREAM_H
#define NIS_PACMAN_STREAM_H

typedef struct {
 unsigned char header[512];
 size_t header_used;
 uint64_t data_left;
 unsigned long entries, matched;
 int eof,failed;
 NisRepoNames *installed;
} NisTarScanner;

static int nis_tar_octal(const unsigned char *field,size_t width,uint64_t *value){
 size_t i=0;uint64_t v=0;int seen=0;
 if(width&&field[0]&0x80)return 0; /* GNU base-256: use libarchive. */
 while(i<width&&(field[i]==' '||field[i]==0))i++;
 for(;i<width&&field[i]>='0'&&field[i]<='7';i++){
  if(v>(UINT64_MAX-7)/8)return 0;
  v=v*8+(uint64_t)(field[i]-'0');seen=1;
 }
 while(i<width&&(field[i]==' '||field[i]==0))i++;
 if(i!=width)return 0;
 *value=seen?v:0;return 1;
}
static void nis_tar_header(NisTarScanner *scan){
 const unsigned char *h=scan->header;
 int zero=1;
 for(size_t i=0;i<512;i++)if(h[i]){zero=0;break;}
 if(zero){scan->eof=1;return;}
 uint64_t checksum=0,size=0;unsigned int sum=0;
 if(!nis_tar_octal(h+148,8,&checksum)||!nis_tar_octal(h+124,12,&size)){
  scan->failed=1;return;
 }
 for(size_t i=0;i<512;i++)sum+=(i>=148&&i<156)?32:h[i];
 if(checksum!=sum||size>UINT64_C(1)<<30||size>UINT64_MAX-511){
  scan->failed=1;return;
 }
 const unsigned char type=h[156];
 if(type!='0'&&type!=0&&type!='5'){
  scan->failed=1;return; /* PAX, GNU long names, other types: fallback. */
 }
 char name[512];
 size_t stem=strnlen((const char*)h,100);
 size_t prefix=strnlen((const char*)h+345,155);
 if(prefix){
  if(prefix+1+stem>=sizeof name){scan->failed=1;return;}
  memcpy(name,h+345,prefix);name[prefix]='/';
  memcpy(name+prefix+1,h,stem);name[prefix+1+stem]=0;
 }else{
  if(stem>=sizeof name){scan->failed=1;return;}
  memcpy(name,h,stem);name[stem]=0;
 }
 if(type=='0'||type==0){
  char package[512];int result=nis_pacman_entry_name(name,package,sizeof package);
  if(result<0){scan->failed=1;return;}
  if(result>0){
   scan->entries++;
   scan->matched+=(unsigned long)nis_repo_names_mark(scan->installed,package);
  }
 }
 scan->data_left=(size+511)&~UINT64_C(511);
}
static void nis_tar_consume(NisTarScanner *scan,const unsigned char *p,size_t length){
 while(length&&!scan->failed&&!scan->eof){
  if(scan->data_left){
   size_t skip=scan->data_left<length?(size_t)scan->data_left:length;
   scan->data_left-=skip;p+=skip;length-=skip;
   continue;
  }
  size_t copy=512-scan->header_used;
  if(copy>length)copy=length;
  memcpy(scan->header+scan->header_used,p,copy);
  scan->header_used+=copy;p+=copy;length-=copy;
  if(scan->header_used==512){
   scan->header_used=0;
   nis_tar_header(scan);
  }
 }
}
static int nis_stream_gzip(const char *path,NisTarScanner *scan){
 gzFile file=gzopen(path,"rb");if(!file)return 0;
 (void)gzbuffer(file,32768);
 unsigned char data[65536];int got=0,ok=1;
 while((got=gzread(file,data,sizeof data))>0){
  nis_tar_consume(scan,data,(size_t)got);
  if(scan->failed){ok=0;break;}
 }
 if(got<0)ok=0;
 if(gzclose(file)!=Z_OK)ok=0;
 return ok;
}

/* These signatures are the public libzstd streaming ABI. Loading dynamically
   keeps binary compatibility with systems and Termux installations that
   do not provide libzstd. */
typedef struct {const void *src;size_t size,pos;} NisZstdInput;
typedef struct {void *dst;size_t size,pos;} NisZstdOutput;
static int nis_stream_zstd(const char *path,NisTarScanner *scan){
 void *lib=dlopen("libzstd.so.1",RTLD_NOW|RTLD_LOCAL);
 if(!lib)lib=dlopen("libzstd.so",RTLD_NOW|RTLD_LOCAL);
 if(!lib)return 0;
 void *(*create)(void)=dlsym(lib,"ZSTD_createDStream");
 size_t (*init)(void*)=dlsym(lib,"ZSTD_initDStream");
 size_t (*decode)(void*,NisZstdOutput*,NisZstdInput*)=dlsym(lib,"ZSTD_decompressStream");
 unsigned (*is_error)(size_t)=dlsym(lib,"ZSTD_isError");
 size_t (*destroy)(void*)=dlsym(lib,"ZSTD_freeDStream");
 if(!create||!init||!decode||!is_error||!destroy){dlclose(lib);return 0;}
 int fd=open(path,O_RDONLY);if(fd<0){dlclose(lib);return 0;}
 void *stream=create();unsigned char *mem=malloc(131072);
 int ok=stream&&mem;
 size_t remaining=1;
 if(ok){remaining=init(stream);if(is_error(remaining))ok=0;}
 NisZstdInput input={0};
 while(ok){
  if(input.pos==input.size){
   ssize_t got=read(fd,mem,65536);
   if(got<0&&errno==EINTR)continue;
   if(got<=0){if(got<0||remaining!=0)ok=0;break;}
   input=(NisZstdInput){mem,(size_t)got,0};
  }
  NisZstdOutput output={mem+65536,65536,0};
  size_t before=input.pos;
  remaining=decode(stream,&output,&input);
  if(is_error(remaining)||(!output.pos&&before==input.pos)){ok=0;break;}
  nis_tar_consume(scan,output.dst,output.pos);
  if(scan->failed){ok=0;break;}
 }
 if(stream&&is_error(destroy(stream)))ok=0;
 free(mem);close(fd);dlclose(lib);
 return ok;
}
static int nis_stream_sync_db(const char *path,NisRepoNames *installed,
                              unsigned long *matched){
 unsigned char magic[4];
 int fd=open(path,O_RDONLY);if(fd<0)return 0;
 ssize_t got=read(fd,magic,sizeof magic);close(fd);
 if(got!=(ssize_t)sizeof magic)return 0;
 NisTarScanner scan={0};scan.installed=installed;
 int ok=0;
 if(magic[0]==0x1f&&magic[1]==0x8b)ok=nis_stream_gzip(path,&scan);
 else if(magic[0]==0x28&&magic[1]==0xb5&&magic[2]==0x2f&&magic[3]==0xfd)
  ok=nis_stream_zstd(path,&scan);
 if(!ok||scan.failed||!scan.eof||!scan.entries)return 0;
 *matched+=scan.matched;
 return 1;
}
static int pacman_foreign_stream(const PacmanConfig *cfg,unsigned long *result){
 NisRepoNames installed={0};int ok=1;
 char local[PATH_MAX];
 if(snprintf(local,sizeof local,"%s/local",cfg->dbpath)>=(int)sizeof local)return 0;
 DIR *dir=opendir(local);if(!dir)return 0;
 struct dirent *entry;
 while((entry=readdir(dir))!=NULL){
  if(entry->d_name[0]=='.')continue;
#ifdef DT_DIR
  if(entry->d_type!=DT_DIR){
   if(entry->d_type!=DT_UNKNOWN)continue;
#endif
   struct stat st;
   if(fstatat(dirfd(dir),entry->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
#ifdef DT_DIR
  }
#endif
  char name[512];
  if(!nis_pacman_local_name(entry->d_name,name,sizeof name)||
     !nis_repo_names_add(&installed,name)){ok=0;break;}
 }
 closedir(dir);
 unsigned long matched=0;
 for(size_t r=0;ok&&r<cfg->nrepos;r++){
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[r])>=(int)sizeof path ||
     !nis_stream_sync_db(path,&installed,&matched))ok=0;
 }
 if(ok)*result=(unsigned long)installed.used-matched;
 nis_repo_names_free(&installed);
 return ok;
}
#endif
