#!/bin/sh
# NISFETCH 3.13.11: portable, recoverable install for Linux and Termux.
set -eu
cd "$(dirname "$0")"

if [ -n "${CC:-}" ]; then
  compiler=$CC
elif command -v cc >/dev/null 2>&1; then
  compiler=cc
elif command -v clang >/dev/null 2>&1; then
  compiler=clang
elif command -v gcc >/dev/null 2>&1; then
  compiler=gcc
else
  printf '%s\n' 'NISFETCH: install gcc or clang first.' >&2
  exit 1
fi

case "${PREFIX:-}" in
  */com.termux/files/usr) destination="${PREFIX}/bin" ;;
  *)
    if [ -n "${TERMUX_VERSION:-}" ] && [ -n "${PREFIX:-}" ]; then
      destination="${PREFIX}/bin"
    else
      destination="${HOME:?Set HOME}/.local/bin"
    fi
    ;;
esac

if [ -n "${TMPDIR:-}" ] && [ -d "$TMPDIR" ]; then
  temp_parent=$TMPDIR
elif [ -n "${PREFIX:-}" ] && [ -d "${PREFIX}/tmp" ]; then
  temp_parent="${PREFIX}/tmp"
else
  temp_parent=/tmp
fi

build_dir=$(mktemp -d "$temp_parent/nisfetch-install.XXXXXXXX")
install_temp=""
cleanup() {
  if [ -n "$install_temp" ]; then rm -f -- "$install_temp"; fi
  rm -f -- "$build_dir/nisfetch"
  rmdir "$build_dir" 2>/dev/null || true
}
trap 'cleanup' 0
trap 'exit 1' 1 2 3 15

printf 'Building NISFETCH 3.13.11 with %s...\n' "$compiler"
if ! "$compiler" -std=c11 -O2 -pipe -Wall -Wextra \
  nisfetch.c -o "$build_dir/nisfetch" -lm -lpng -lgif -lz -ldl; then
  printf '%s\n' 'Build failed. Install a C compiler, libpng, giflib and zlib development files:' >&2
  printf '%s\n' '  Arch:   sudo pacman -S --needed base-devel libpng giflib zlib' >&2
  printf '%s\n' '  Debian: sudo apt install build-essential libpng-dev libgif-dev zlib1g-dev' >&2
  printf '%s\n' '  Fedora: sudo dnf install gcc libpng-devel giflib-devel zlib-devel' >&2
  printf '%s\n' '  Alpine: sudo apk add build-base libpng-dev giflib-dev zlib-dev' >&2
  printf '%s\n' '  Termux: pkg install clang libpng giflib zlib' >&2
  exit 1
fi

mkdir -p "$destination"
if [ -f "$destination/nisfetch" ]; then
  backup=$(mktemp "$destination/nisfetch.backup.XXXXXXXX")
  if ! cp -p "$destination/nisfetch" "$backup"; then
    rm -f -- "$backup"
    exit 1
  fi
  printf 'Backed up the previous build to %s\n' "$backup"
fi

# Stage in the destination directory, so the final rename is atomic.
install_temp=$(mktemp "$destination/.nisfetch.new.XXXXXXXX")
install -m 755 "$build_dir/nisfetch" "$install_temp"
mv -f -- "$install_temp" "$destination/nisfetch"
install_temp=""
printf 'Installed: %s/nisfetch\n' "$destination"
"$destination/nisfetch" --version

# Resolve the expensive foreign-package classification once during installation.
# Subsequent runs use the validated persistent index until pacman's DB changes.
if [ -r /etc/pacman.conf ] && [ -d /var/lib/pacman/local ]; then
  printf '%s\n' 'Preparing the verified Pacman package index...'
  "$destination/nisfetch" --no-config --no-logo --modules packages >/dev/null 2>&1 || true
fi

case ":${PATH:-}:" in
  *":$destination:"*) ;;
  *) printf 'Add this directory to PATH: export PATH="%s:$PATH"\n' "$destination" ;;
esac
