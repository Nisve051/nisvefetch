# NISFETCH 3.9.0 — Universal Stability

NISFETCH is a lightweight system-information fetcher for Linux distributions
and Android running in Termux. **3.9.0** is a portability and reliability
release based on the optimized 3.8.0 cold-start engine. It keeps the existing
module catalog, theme and image customization, package-index support, and
both fast and full package counting modes.

## What's new in 3.9.0

- **Linux distro identification:** read `/etc/os-release`, falling back to
  `/usr/lib/os-release` on systems without the former; prefer `PRETTY_NAME`,
  then `NAME`, then `ID`. This also handles stripped-down containers.
- **Android / Termux battery:** when sysfs battery access is missing, try the
  optional `termux-battery-status` command. Run it directly without invoking
  a shell or external JSON filters; enforce an approximately 1.8-second
  deadline and return a missing value instead of hanging if Termux:API is
  unavailable or denies access. `termux-api` and the associated Android app
  are optional and needed for this fallback only.
- **Safer Android property collection:** drain `getprop` output even if the
  bounded property table fills, preventing a blocked process on unusually
  large property lists. Native Android builds use Bionic properties directly.
- **GPU detection on phones:** avoid desktop GPU probing for Termux without
  an X11/Wayland display; the explicitly requested module reports that native
  GPU information is unavailable rather than running irrelevant GLX tools.
  Desktop modules remain automatically hidden in the default Termux preset.
- **Cross-platform regression tests:** exercise Debian/Termux dpkg metadata,
  Alpine apk metadata, an RPM command fixture, os-release variations,
  Termux:API battery parsing/timeouts, and large Android property snapshots.
- **No feature removals:** 163 named modules, custom PNG images, built-in
  distro logos, themes, layout, config, full/fast Pacman modes, and verified
  persistent Pacman indexes remain available.

The 3.8.0 package fast path and CPU/GPU optimizations remain in place.
**The 2.5 ms cold-start goal is an optimization target, not a guaranteed
cross-distribution result.** The actual time depends on installed packages,
storage, platform APIs, display services and chosen modules. In particular,
`--packages-mode fast` counts total installed Pacman packages whereas `full`
also classifies foreign packages; these are different workloads.

### Install on Arch Linux or another Linux distribution

```bash
cd ~/Загрузки
unzip NISFETCH-v3.9.0-universal-stability.zip
cd NISFETCH-v3.9.0-universal-stability
sh install.sh
hash -r
nisfetch --version
```

If the compiler reports missing headers or libraries, install a C toolchain,
`libpng`, `giflib`, and `zlib` development packages through your distro's
package manager. The installer prints package-manager-specific suggestions.

### Termux on Android

```bash
pkg update
pkg install clang make libpng giflib zlib unzip
cd ~/storage/downloads
unzip NISFETCH-v3.9.0-universal-stability.zip
cd NISFETCH-v3.9.0-universal-stability
sh install.sh
nisfetch --version
```

If `~/storage/downloads` is not enabled, run `termux-setup-storage` and grant
the Android storage permission, or unzip the archive directly in `$HOME`.
For optional Android battery data, install the `termux-api` CLI package and
the separate Termux:API Android app. Missing or inaccessible properties are
not fabricated.

### Verify and benchmark

```bash
nisfetch --list-modules | wc -l
nisfetch --no-logo --modules os:kernel:cpu:gpu:memory:packages --profile
nisfetch --no-logo --packages-mode fast --modules packages --profile
```

The following material documents the previous 3.8.0 hotfix retained in
this release.

---

# Previous release: NISFETCH 3.8.0 — Cold-start Optimization Hotfix

## Latest 3.8.0 hotfix: targeting the 2.2 ms cold launch

**Version remains 3.8.0.** Based on the previous fast/full package-mode
hotfix, with the earlier stable micro-optimizations preserved:

- **Linux `getdents64` directory scan.** For thousands of local Pacman package
  directories, the fast path reads kernel directory entries in larger batches
  and skips per-entry `readdir` overhead. If the syscall is unavailable or
  fails, NISFETCH uses the original portable `readdir` implementation.
  Unknown directory types are verified with `fstatat` rather than guessed.
- **Lean CPU frequency reads.** Use `open`/`read` and integer parsing for
  sysfs clock files instead of allocating stdio buffers per CPU policy.
  NISFETCH still checks all reported policies to preserve the maximum clock.
- **Preserved micro optimizations.** Skip NSS lookup when `$USER` is set;
  `Memory` and its detail modules share a single `/proc/meminfo` snapshot.
- **No removed features.** Both `--packages-mode fast` and `full`, the
  persistent foreign-Pacman index, 163 modules, PNG rendering, terminal themes,
  Linux distributions and Termux are retained.

The earlier measurements on the user's Arch machine were about **2.5 ms**
without disposable caches and **1.39 ms** after warmup for the six-module
test. **2.2 ms cold is a target, not a verified result.** A synthetic directory
scan on the development runner was ~13% faster, but overall performance must
be measured on the target Arch installation. Never substitute the cached
1.39 ms result for an index-free cold measurement.

### Install this hotfix

```bash
cd ~/Загрузки
unzip NISFETCH-v3.8.0-cold-start-hotfix.zip
cd NISFETCH-v3.8.0-cold-start-hotfix
sh install.sh
hash -r
nisfetch --version
```

### Cold benchmark, without touching your real indices

```bash
export NIS_BENCH_STATE="$(mktemp -d)"
export NIS_BENCH_CACHE="$(mktemp -d)"

hyperfine -N --warmup 0 --runs 100 \
  --prepare 'rm -f "$NIS_BENCH_CACHE/nisfetch/packages_fast" "$NIS_BENCH_CACHE/nisfetch/gpu"' \
  "env XDG_STATE_HOME=$NIS_BENCH_STATE XDG_CACHE_HOME=$NIS_BENCH_CACHE $HOME/.local/bin/nisfetch --no-config --no-logo --packages-mode fast --modules os:kernel:cpu:gpu:memory:packages" \
  "env XDG_STATE_HOME=$NIS_BENCH_STATE XDG_CACHE_HOME=$NIS_BENCH_CACHE fastfetch --logo none --structure os:kernel:cpu:gpu:memory:packages"
```

This is an application-cache-cold test, not a full system page-cache cold
boot. `fast` counts all Pacman packages, including foreign/AUR packages;
`full` separately classifies them using validated indices. Neither mode
silently changes the meaning of the count.

The eighth feature minor after the 3.0.0 stable release. Version numbering
reserves up to 100 minor releases per major (`3.0.0` through `3.99.x`).

## 3.8.0 hotfix — honest cold-start acceleration

Two package-collection modes are now available **without changing the
version number**:

| Mode | Command | Pacman output | What it does |
| --- | --- | --- | --- |
| `full` (default) | `nisfetch --packages-mode full` | `1332 (pacman), 20 (AUR/foreign)` | Separately classifies foreign packages against sync repositories. Uses verified persistent indexes when present. |
| `fast` (optional) | `nisfetch --packages-mode fast` | `1352 (pacman total)` | Counts all installed local Pacman entries. Does not classify foreign packages. Comparable to Fastfetch's package-count workload. |

The counts in the table are illustrative for the Arch machine used during
development; your installation will differ. Both modes include Flatpak where
installed. `fast` avoids scanning compressed sync databases, querying libalpm,
and writing persistent Pacman indexes. Its short-lived cache key is separate
from the `full` cache, so switching modes cannot display the wrong count.

The **full** mode retains its existing output and strict index verification.
On an index miss, the tried-and-tested 3.7.0 `libarchive` collector is again
preferred, with the 3.8.0 bounded-memory streaming collector as a fallback.
There are no module, theme, logo, PNG, or Termux feature removals.

**Important:** The earlier 3.8.0 result on Arch was 78.8 ms / 5.5 MiB
*without any Pacman index*. Accurate `native` versus `foreign` classification
requires substantially more work than a total count. A 1.8–2 ms true
**unindexed** `full` launch is not guaranteed. The new `fast` mode makes a
fairer comparison with Fastfetch; measure it on your machine rather than
assuming a fixed performance claim.

Choose a persistent preference in `~/.config/nisfetch/config.jsonc`:

```jsonc
{
  "packagesMode": "fast"
}
```

Change to `"full"` to restore separate Pacman/AUR counts. An explicit
`--packages-mode fast|full` flag overrides the config. Neither mode needs
`sudo` to collect the package count.

## New in 3.8.0

- **Streaming gzip/zstd Pacman reader:** as a fallback on an unindexed Arch
  launch, NISFETCH can decode standard compressed sync-DB archives directly
  into a small buffer and read tar headers as a stream. This avoids allocating
  a full archive or constructing a list of every repository package.
- **Installed-names-first comparison:** it stores only *locally installed*
  names in an exact-match hash table. Repository archive names are looked up
  as the archive is read and matched names are marked once. This sharply
  reduces the memory needed for foreign/AUR counting. The two indexes and
  their validation rules are unchanged.
- **Safe decoding:** tar checksums and compression completion are verified.
  Unsupported archive types (including PAX and GNU long-name headers),
  unavailable zstd libraries, malformed entries, and decompression errors
  fall back to `libarchive`, then libalpm or `pacman` as needed. In the hotfix,
  `libarchive` is tried before streaming due to the observed Arch speed
  regression. There is no additional mandatory dependency on non-Arch Linux
  or Termux.
- **Hot path unchanged:** when the existing verified index is valid, NISFETCH
  does not load a decompression library or read the repository archives.
  All 163 modules, seven presets, UI styling, PNG, JSON and mobile support
  remain in place.

The actual speedup on Arch depends on the sync database format and size.
NISFETCH 3.7.0 previously measured **70.1 ms and 14.6 MiB** without indexes
on the project's Arch test machine. Run a fresh benchmark to measure 3.8.0
there; do not assume unmeasured performance gains.

### Install on Arch Linux

```bash
cd ~/Загрузки
unzip NISFETCH-v3.8.0-fast-packages-hotfix.zip
cd NISFETCH-v3.8.0-fast-packages-hotfix
sh install.sh
nisfetch --version
```

### Verify exact counts

```bash
nisfetch --no-config --no-logo --modules packages --profile
nisfetch --no-config --no-logo --modules packages --packages-mode fast --profile
pacman -Qmq | wc -l
ls -lh ~/.local/state/nisfetch/*.index
```

### Benchmark with no indexes, without touching your real indexes

```bash
export NIS_BENCH_STATE="$(mktemp -d)"
export NIS_BENCH_CACHE="$(mktemp -d)"

hyperfine -N --warmup 0 --runs 30 \
  --prepare 'rm -f "$NIS_BENCH_STATE/nisfetch/pacman-foreign.index" "$NIS_BENCH_STATE/nisfetch/pacman-total.index" "$NIS_BENCH_CACHE/nisfetch/packages" "$NIS_BENCH_CACHE/nisfetch/packages_fast" "$NIS_BENCH_CACHE/nisfetch/foreign_count"' \
  "env XDG_STATE_HOME=$NIS_BENCH_STATE XDG_CACHE_HOME=$NIS_BENCH_CACHE $HOME/.local/bin/nisfetch --no-config --no-logo --packages-mode fast --modules os:kernel:cpu:gpu:memory:packages" \
  "env XDG_STATE_HOME=$NIS_BENCH_STATE XDG_CACHE_HOME=$NIS_BENCH_CACHE fastfetch --logo none --structure os:kernel:cpu:gpu:memory:packages"
```

To benchmark **full accurate mode** on each unindexed launch, replace
`--packages-mode fast` with `--packages-mode full` in that command. This
benchmark intentionally runs extra work and is **not** an equivalent
workload to Fastfetch's total Pacman count.

After benchmarking, `unset NIS_BENCH_STATE NIS_BENCH_CACHE` if desired. Normal
`nisfetch` always uses your existing validated state files unless explicit
`XDG_STATE_HOME`/`XDG_CACHE_HOME` environment overrides are passed to it.

Earlier release notes follow.

## New in 3.7.0

- **Native sync-DB scanner for unindexed Arch installs.** When the durable
  foreign-package index is missing or invalid, NISFETCH first attempts to
  read the compressed `/var/lib/pacman/sync/*.db` archives directly using
  `libarchive` (loaded dynamically only on a cache miss). It extracts the
  actual package names, builds a compact exact-name hash table, and compares
  them to `/var/lib/pacman/local`. This avoids loading the complete libalpm
  repository structures and should reduce *unindexed* startup time and peak
  memory on many Arch installations. The precise improvement depends on your
  repository sizes, compression and machine; benchmark it rather than
  assuming a fixed speedup.
- **Authoritative fallback:** unusual or unreadable archive formats, missing
  libarchive and malformed local DB entries transparently fall back to the
  existing libalpm path, then to `pacman -Qmq` when necessary. There is no
  new mandatory build or runtime dependency; Linux distributions and Termux
  without Pacman continue to use their existing collectors.
- **More robust invalidation:** when a verified DB fingerprint no longer
  matches its persistent foreign index, the old timestamp-only disposable
  cache cannot silently restore an obsolete count. This fixes a possible
  same-second repository-update race.
- **Everything preserved:** the verified `pacman-foreign.index` and
  `pacman-total.index` formats, 163 modules, seven presets, JSON, the theme
  customizer and brightness, PNG images, distro logos and Android/Termux.

The regular hot path still uses the persistent indexes; it does **not** scan
repository archives on every terminal start. When you benchmark the fully
unindexed path, use temporary `XDG_STATE_HOME` and `XDG_CACHE_HOME` locations
so your real indexes remain intact.

### Test the native package path on Arch

```bash
nisfetch --version
nisfetch --no-config --no-logo --modules packages --profile
pacman -Qmq | wc -l
ls -lh ~/.local/state/nisfetch/*.index
```

The normal installation instructions are below, followed by the full
historical release notes.

## New in 3.6.0

- **Preserved Pacman foreign-package index:** the verified
  `~/.local/state/nisfetch/pacman-foreign.index` is kept with its existing
  on-disk format and strict DB fingerprint. A new, independent
  `pacman-total.index` caches the *total number* of locally installed Pacman
  packages. Its fingerprint covers the Pacman configuration, local database
  directory and all enabled sync databases. A package installation/removal or
  repo update invalidates the relevant index. Both indexes survive deletion
  of the disposable `~/.cache/nisfetch` directory.
- **Smaller memory footprint:** the standard-output buffer drops from 256 KiB
  to 32 KiB, and module sorting uses a small in-place scratch row instead of
  three large temporary arrays. Visual output, module order and JSON mode
  remain unchanged.
- **One kernel snapshot per invocation:** requested load-average modules
  (`load1`, `load5`, `load15`, `loadavg`, `cpuload`, `loadtasks`, process counts)
  share one `/proc/loadavg` read. The RAM detail modules share a single
  `/proc/meminfo` scan. Values are consistent within a single run; a new
  invocation reads fresh values.
- **No feature removals:** 163 registered modules, seven presets, JSONC
  configuration, themes and brightness, PNG images, Termux/Android support,
  and Linux logos are preserved. No mandatory runtime dependency added.

The persistent index optimizes repeated cold-*cache* launches. A genuinely
new installation or a changed Pacman database still requires accurate fresh
collection; it may be slower. Compare warmed and cold-cache launches
separately and check values against `pacman -Qmq | wc -l`.

### Install on Arch Linux

```bash
cd ~/Загрузки
unzip NISFETCH-v3.8.0-streaming-pacman.zip
cd NISFETCH-v3.8.0-streaming-pacman
sh install.sh
nisfetch --version
```

### Verify the update

```bash
nisfetch --no-config --no-logo --modules packages:cpu:memory:load1 --profile
nisfetch --no-config --no-logo --modules load1:load5:load15:loadavg:memused:mempercent --json
nisfetch --list-modules | wc -l
ls -l ~/.local/state/nisfetch/pacman-foreign.index ~/.local/state/nisfetch/pacman-total.index
```

The previous release notes follow.

## New in 3.5.0

- **Seven built-in layouts:** `auto` (adaptive, unchanged default), `compact`
  (essentials), `balanced` (everyday desktop), `hardware` (CPU/GPU/RAM/disk
  diagnostics), `network` (interfaces and IP), `phone` (Android/Termux), and
  `full` (all registered modules). Use `nisfetch --list-presets` to list them.
- **Fast, precise customization:** `--preset NAME` or the top-level JSONC
  `"preset": "NAME"` chooses an ordered set of modules. A JSONC `modules`
  array overrides the configured preset; explicit CLI `--modules`, `--all` or
  `--preset` overrides both. `--preset auto` temporarily restores adaptive
  defaults, even with a fixed module list in the config. Existing
  `hiddenModules` still apply to the adaptive default.
- **Machine-readable output:** `--json` / `--format json` emits a valid JSON
  object with canonical module IDs and sanitized plain-text values. It
  automatically disables the logo, terminal colors and decorative palette,
  so results can be passed to `jq`, scripts and other programs. The JSONC
  option is `display.format: "json"`; `--format text` overrides it for a
  single invocation. `--profile` writes diagnostics to **stderr** only.
- **Stronger validation:** invalid preset names and formats fail clearly,
  chosen module lists are validated, and the new output paths are covered by
  regression tests. No extra background process or runtime dependency is
  added to the regular text-rendering path.
- **Compatibility first:** existing themes, brightness, bright user heading,
  PNG images, scrollback, persistent Pacman index, Android/Termux detection,
  163 supported modules and default information layout remain intact.

Examples:

```bash
nisfetch --preset compact
nisfetch --preset balanced --theme ice --theme-brightness 125
nisfetch --preset hardware --detailed
nisfetch --preset network --no-logo
nisfetch --preset phone --no-logo
nisfetch --format json --preset compact
nisfetch --json --no-config --modules os:cpu:memory | jq .
nisfetch --preset auto  # Ignore a saved fixed module selection this time.
```

Example `~/.config/nisfetch/config.jsonc`:

```jsonc
{
  "preset": "balanced",
  "display": { "theme": "ice", "themeBrightness": 115, "format": "text" },
  "moduleLabels": { "cpu": "Processor", "memory": "RAM" },
  "hiddenModules": []
}
```

Use `"format": "json"` for tools that always consume JSON, or run
`--format text` temporarily to view the usual colorful terminal output.

## New in 3.4.0

- **Theme brightness (3.4.0 maintenance update):** adjust text brightness
  without changing the selected hue using `--theme-brightness 20..180` or
  `display.themeBrightness` in JSONC. Default `100` preserves the previous
  appearance exactly; below 100 dims toward black, above 100 lightens toward
  white. The header, labels, values and per-module RGB overrides all follow
  the setting. Built-in artwork, PNGs and the decorative terminal ANSI palette
  retain their original colors. That maintenance update kept **3.4.0**.
- **Theme-synchronized title:** `user@hostname` at the top now uses exactly
  the active theme's accent color, as do the module labels. Changing
  `--theme` also changes the header automatically. Previously, its separate
  color could remain yellow while the rest of the text changed.
- **Predictable custom colors:** `display.keyColor` also colors the title by
  default; `display.titleColor` explicitly overrides it when desired.
  An explicit CLI `--theme` overrides saved global colors, including the
  title. `moduleValueColors.title` remains the highest-priority per-module
  override for advanced custom themes.
- **More palettes:** `vivid`, `soft`, `mono`, `ice`, `forest`, `rose`, and
  `classic`; `bright` is an alias for `vivid` for compatibility. Discover them
  with `nisfetch --list-themes`. All styles retain clear, high-contrast values.
- **Additional stability checks:** PTY-based tests confirm the actual ANSI
  codes used on the heading and OS label for every palette, configuration
  priority, `--no-color`, and invalid theme handling. Error output for invalid
  options/logos ends with a proper newline. Existing install backups, native
  PNG rendering, adaptive Linux/Termux defaults, and 163 modules remain.

Preview the new palettes:

```bash
nisfetch --theme ice
nisfetch --theme ice --theme-brightness 65
nisfetch --theme ice --theme-brightness 135
nisfetch --theme forest
nisfetch --theme rose
nisfetch --theme classic
nisfetch --list-themes
```

You can still override the title independently in JSONC:

```jsonc
{
  "display": {
    "theme": "ice",
    "themeBrightness": 110,
    "titleColor": "#FFFFFF"
  }
}
```

Omit `titleColor` to keep `user@hostname` synchronized with the theme.

## Introduced in 3.3.0

- **Higher-contrast text out of the box:** vivid amber labels and crisp,
  brighter white system values. Both labels and values are bold by default
  in terminals that support RGB/ANSI color. Redirected output stays plain.
- **Three original themes:** `vivid` (default), `soft` (muted, comfortable)
  and `mono` (neutral). Switch without editing your config using
  `nisfetch --theme soft` or `nisfetch --theme mono`.
- **Fine-grained RGB customization:** set `display.keyColor`,
  `display.valueColor`, `display.titleColor` and `display.separatorColor`
  using `#RRGGBB`; individual modules can override label and value colors
  through `moduleColors` and `moduleValueColors`.
- **Customize system-information labels:** `moduleLabels` can rename the
  displayed label of any module, without changing its actual module ID.
  UTF-8 labels are aligned by terminal character width.
- **Control information order and visibility:** an optional `modules` array
  defines an exact custom selection and order; `hiddenModules` hides selected
  modules from the standard/adaptive output. Explicit `--modules` and `--all`
  can still request hidden items for diagnostics.
- **Adjust the layout:** `display.labelWidth` controls where values start;
  `display.paletteIndent` controls the color-palette offset;
  `display.gap`, `display.palette`, `display.keyBold` and
  `display.valueBold` are still configurable.
- **Safer first-run setup:** `nisfetch --init-config` creates a private
  `~/.config/nisfetch/config.jsonc` (or `$XDG_CONFIG_HOME` equivalent) once,
  refusing to overwrite an existing file. `--config-path` prints the resolved
  location and `--check-config` validates changes.
- **Stable defaults and compatibility:** a newly generated config does *not*
  pin desktop-specific modules, so Linux, KDE and Termux keep their adaptive
  defaults. Older JSONC configs still load; PNG/Tux rendering, native hardware
  probes and the persistent Pacman index remain available. Invalid RGB values
  and control sequences in custom labels are rejected.

Try it immediately:

```bash
nisfetch --theme vivid
nisfetch --theme soft --label-width 18 --palette-indent 14
nisfetch --theme mono --no-palette
nisfetch --init-config
nano "$(nisfetch --config-path)"
nisfetch --check-config
```

An example of custom colors and labels in `config.jsonc`:

```jsonc
{
  "display": {
    "theme": "vivid",
    "valueColor": "#ffffff",
    "keyColor": "#ffda78",
    "valueBold": true,
    "labelWidth": 17,
    "paletteIndent": 14
  },
  "moduleLabels": { "cpu": "Processor", "gpu": "Graphics", "memory": "RAM" },
  "moduleColors": { "gpu": "#a8dbff" },
  "moduleValueColors": { "memory": "#ffffff" },
  "hiddenModules": ["wmtheme"]
}
```

To take complete control of module order, add e.g.:

```jsonc
"modules": ["title", "separator", "os", "kernel", "cpu", "gpu", "memory", "disk", "locale"]
```

inside the same top-level object, separated from the preceding key by a
comma. If `modules` is omitted, the adaptive default module order is retained.
Keep the original `module` IDs even when you rename their displayed labels.

## Introduced in 3.2.0

- **Memory technology in the standard `Memory` line**, when identifiable:
  `3.81 GiB / 31.26 GiB (12%) | DDR4`. Native Linux EDAC (`dimm_mem_type`)
  is used when available; readable SMBIOS Type 17 DIMM tables can also expose
  DDR generation, configured transfer rate, occupied/total slots, vendor and
  part number. No root-only `dmidecode` command is spawned.
- **Rootless AMD Ryzen desktop fallback:** certain CPU/platform combinations
  have a single supported DDR generation. For instance, the desktop Ryzen 7
  5700X permits a *platform-derived* DDR4 classification even when the kernel
  hides SMBIOS/EDAC; this is **not** a physical SPD measurement. Ambiguous
  platforms show no invented memory type.
- **Filesystem format in default disk lines:** e.g., `Disk (/): ... [ext4]`,
  `Disk (/home): ... [btrfs]`. The correct mount for each path is resolved via
  native `/proc/self/mountinfo`, including separate disks for `/` and `/home`.
- **Twelve optional modules:** `ramtype`, `ramfrequency`, `ramslots`,
  `rammodules`, `rammanufacturer`, `rampart`, `diskdevice`, `homedevice`,
  `homefilesystem`, `diskmountopts`, `diskinodes`, `homeinodes`.
- **Richer `--detailed`:** RAM availability, known MT/s and DIMM occupancy;
  disk device source for `/` and `/home`; swap utilization and exact boot
  time. Previous CPU/GPU/monitor enhancements are preserved.
- **163 registered modules**, with the same fast adaptive default preset.
  Missing hardware data remains omitted. No new mandatory dependencies;
  all added probes are native C reads.

Example on a supported Arch PC (values illustrate the format):

```text
Memory:       3.81 GiB / 31.26 GiB (12%) | DDR4
Disk (/):     53.60 GiB / 97.38 GiB (55%) [ext4]
Disk (/home): 441.55 GiB / 839.39 GiB (53%) [btrfs]
```

**Important:** `/` and `/home` may both show `ext4`, or different formats;
NISFETCH reports the actual mounts. `ramfrequency`/DIMM manufacturer can be
unavailable without elevated access or a memory controller driver, so those
values are never fabricated. Linux and Termux retain their previous presets.

## Introduced in 3.1.0

- **Display manufacturer and model:** reads monitor EDID directly from the
  Linux DRM sysfs interface (`/sys/class/drm/`), validates its header and
  checksum, and identifies common manufacturer PnP codes. No EDID data is
  invented if it is inaccessible.
- **Refresh rate (Hz):** on KDE, reads the *active* KScreen mode; on X11,
  can use the current XRandR mode. If an active rate cannot be obtained,
  uses the EDID *preferred* rate when present and explicitly labels it
  `(preferred)`. The preferred rate must not be mistaken for current Hz.
- **Five display modules:** `monitor`, `refreshrate`, `displayconnector`,
  `displaysize` and `monitorcount` (151 modules in the 3.1.0 release).
- **More information without sacrificing the compact preset:** enable
  `--detailed` to enrich selected system, CPU, GPU, RAM, package, disk,
  power and load modules with relevant supplementary data. It uses local
  Linux interfaces rather than launching a shell for every extra field.
- **Backward-compatible:** the existing PNG/Tux layout, Termux adaptation,
  persistent Pacman index and core 3.0.0 features are retained. Display
  cache has its own 3.1 key so old display data is not shown after upgrade.

Example on a connected KDE display (actual values vary):

```text
Display:      2560x1440 @ 144.00 Hz | LG UltraGear
Monitor:      LG UltraGear
Refresh Rate: 144.00 Hz
Connector:    DisplayPort
Display Size: 60 x 34 cm
Monitors:     1
```

**Note:** individual fields are shown only when the operating system exposes
the necessary information. Android/Termux typically does not expose DRM
monitor EDID, so desktop-specific display fields remain optional and do not
create fake results. `--detailed` enhances useful compound fields; atomic
fields such as `uid` or `epoch` stay atomic by design.

## Stable 3.0.0 foundation

**3.0.0 persistent package-index hotfix (version unchanged).** Arch systems
can keep the precise native/foreign split without opening all repository
databases at every launch. The foreign count is first calculated through
runtime-loaded libalpm and saved as a small persistent index in XDG_STATE_HOME.
A full pacman fallback remains for unusual or unreadable configurations.

The fast path reads installed package names from the local directory database
and searches enabled sync databases through libalpm. It tracks changes to
pacman.conf, the local database and every enabled sync database. When any of
these change, the index is invalidated and rebuilt accurately.
It does not modify the original PNG or terminal-rendering behavior.

**Made by Nisve.** NISFETCH was inspired by the idea of [Fastfetch](https://github.com/fastfetch-cli/fastfetch); its source code was **not** used in this project.

NISFETCH is a native C system-information fetch for Linux desktops and
Android/Termux. It shows a colorful system summary next to a built-in Tux,
supported distribution logo, or a custom PNG image. The ordinary shell prompt
remains below the output, with no resident background process required.

## Features inherited from 3.0.0

- **Safer cache:** updates are written to a private temporary file and
  atomically renamed. Multiple terminals opening simultaneously can no longer
  read a half-written cache value.
- **Faster Linux package counting:** native scans for pacman, dpkg and apk,
  native Gentoo Portage folder counting, and single-process RPM/XBPS/pkg
  queries without a `grep | wc` pipeline.
- **Termux-aware:** hides KDE/desktop/GPU fields that do not belong in a phone
  preset, finds Android brand, model, SoC, version and security patch if the
  OS allows access, and reads installed packages directly from Termux's dpkg
  status file. Android property lookup uses Bionic's native API where possible
  or **one** getprop snapshot rather than separate commands for each property.
- **Broader desktops:** knows KDE Plasma/KWin, GNOME/Mutter, Cinnamon/Muffin,
  MATE/Marco, Xfce/Xfwm4, Hyprland, Sway, niri, i3, COSMIC, labwc, river and
  Wayfire. KDE-only settings are omitted on other desktops when using the
  default module list; they remain selectable explicitly.
- **Accurate display fallback:** Wayland without a compatible output detector
  says "Wayland" rather than reporting an XWayland virtual display as a real
  monitor resolution. KDE/X11 no longer gets mislabeled as Wayland.
- **Clean scripts:** redirected output is plain text by default, without color
  escape sequences, a huge logo or an ANSI palette. Use `--no-color` on a TTY
  to request monochrome output manually.
- **Better CLI precedence:** `--image` and `--logo` override stored image
  settings; `--no-logo` skips image decoding entirely; `--check-config`
  validates configuration without requiring an image file to be present.
- **Install safety:** build in a temporary directory, keep a uniquely named
  copy of the previous executable, and atomically install the new binary.
  Existing 2.9.x configurations are supported.
- **PNG and logos unchanged in spirit:** native PNG bytes in Kitty and Konsole,
  terminal-safe ANSI fallback elsewhere, smooth transparent distro logos and
  the original large Tux layout. GIF remains experimental and is not the
  focus of this release.

## Modules

`nisfetch --list-modules` shows **163 registered modules**. The standard KDE
desktop layout requests **29**, including CPU cores, processes and load.
Phone and non-KDE defaults are adaptive, so the number actually displayed can
be lower depending on which fields are available.

Among the available optional modules are `monitor`, `refreshrate`,
`displayconnector`, `displaysize`, `monitorcount`, `gpudriver`, `gpuvendor`, `cpul3`,
`ramtype`, `ramfrequency`, `ramslots`, `rammodules`, `rammanufacturer`,
`rampart`, `diskdevice`, `homedevice`, `homefilesystem`, `diskmountopts`,
`diskinodes`, `homeinodes`,
`memorypressure`, `batterycycles`, `biosdate`, `androidbrand`,
`androidhardware`, `androidsecuritypatch`, `gpuusage`, `gpuvram`, `memcached`,
`cpugovernor`, `ipv4`, `interfaces`, `battery` and `brightness`.

```bash
nisfetch --no-logo --modules os:cpu:cpucores:cpul3:gpu:gpudriver:memory:memorypressure:battery:batteryhealth:packages
nisfetch --no-logo --modules display:monitor:refreshrate:displayconnector:displaysize:monitorcount
nisfetch --no-logo --modules memory:ramtype:ramfrequency:rammodules:ramslots:rammanufacturer:rampart:disk:diskdevice:homedisk:homedevice:homefilesystem
nisfetch --detailed
```

## Install on Arch Linux

Download `NISFETCH-v3.8.0-streaming-pacman.zip` into `~/Загрузки` and run:

```bash
sudo pacman -S --needed gcc libpng giflib zlib unzip
cd ~/Загрузки
unzip NISFETCH-v3.8.0-streaming-pacman.zip
cd NISFETCH-v3.8.0-streaming-pacman
sh install.sh
nisfetch --version
```

The installer detects `cc`, `clang` or `gcc`, and also accepts the `CC`
environment variable. It installs to `~/.local/bin/nisfetch` on normal Linux,
or `$PREFIX/bin/nisfetch` in Termux.

Every replacement preserves the previous binary as a uniquely named file
like `nisfetch.backup.A1B2C3D4` in the same destination folder. The installer
prints the exact backup path.
On Arch, installation also prepares the package index once, so normal first
terminal launches do not have to decompress all Pacman sync databases.

## Install on Termux / Android

In Termux, first make sure you have the ZIP in a readable directory. For a
file in Android's Downloads directory, grant storage access if needed:

```bash
termux-setup-storage
pkg update
pkg install clang libpng giflib zlib unzip
cd ~/storage/downloads
unzip NISFETCH-v3.8.0-streaming-pacman.zip
cd NISFETCH-v3.8.0-streaming-pacman
sh install.sh
nisfetch --version
```

If the archive is somewhere else, change the `cd` path to that directory.
Termux:API and its Android companion app are **optional**; some restricted
battery fields may not be available without them. The program does not require
root permissions or assume a desktop environment on a phone.

## Other distributions

The source is designed for Linux using C11, libc, libpng, giflib, zlib and libdl. The
package name of the corresponding development headers varies by distribution.
Install a C compiler and those development libraries, then run:

```bash
sh install.sh
nisfetch --version
```

Native package counting supports Arch-family systems (pacman), Debian/Ubuntu
(dpkg), Alpine (apk), Gentoo (Portage), plus command-based RPM, XBPS and pkg
families when their package managers are available. Other distributions can
still display OS, kernel, CPU, memory, uptime and other general Linux fields;
unsupported specific fields are omitted or marked unavailable. Support for
every configuration cannot be guaranteed without testing on that device.

## PNG instead of Tux

```bash
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png'
```

The default backend chooses Kitty's scrollback-linked Unicode placeholders,
Konsole's physical graphics placement, or a truecolor ANSI fallback. You can
override the choice:

```bash
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png' --image-backend konsole
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png' --image-backend ansi
```

PNG bytes are transferred unmodified when native graphics are available;
the terminal itself decides the final on-screen pixel scaling. Konsole's
actual scrollback and resize behavior depends on the version of Konsole.
On Termux and non-graphics terminals, the image falls back to ANSI half-block
characters and is necessarily limited by terminal-cell resolution.

Animated GIF remains a legacy **experimental** feature. This major release
does not claim animated GIF support across Konsole or other terminals.

## Configuration and testing

```bash
nisfetch --no-config
nisfetch --list-presets
nisfetch --preset compact
nisfetch --preset hardware --detailed
nisfetch --json --modules os:kernel:cpu:memory | jq .
nisfetch --gen-config
nisfetch --list-themes
nisfetch --config-path
nisfetch --init-config
nisfetch --check-config
nisfetch --theme vivid --label-width 18 --palette-indent 14
nisfetch --list-logos
nisfetch --list-modules | wc -l
nisfetch --no-logo --no-color --modules os:kernel:cpu:memory:packages
nisfetch --no-logo --modules display:monitor:refreshrate:displayconnector:displaysize:monitorcount
nisfetch --no-logo --modules memory:ramtype:ramfrequency:rammodules:ramslots:disk:homedisk:diskdevice:homedevice:homefilesystem
nisfetch --detailed
nisfetch --profile
hyperfine -N --warmup 30 --runs 200 "$HOME/.local/bin/nisfetch" fastfetch
```

The ZIP includes Python/Pillow-based regression tests, including configuration
customization and safety, synthetic EDID, EDAC, SMBIOS Type 17, mountinfo
fixtures, and a mocked KDE active-mode check:

```bash
python -m unittest discover -s tests -v
```

Set `NISFETCH_BIN` to the compiled executable for test runs when it is not yet
installed; the Python tests also require Pillow (`python-pillow` on Arch).

Caching keeps repeat launches fast, while the first uncached run can still be
slower due to package-manager, GPU and monitor probes. Performance claims
should be measured on the same system with the same configured modules.
The persistent index logic passes a mocked libalpm regression test, but real
Arch speeds still need checking on the target device.

### Arch AUR index and honest benchmarking

For Arch, the verified foreign count is persisted at
`~/.local/state/nisfetch/pacman-foreign.index` (or below `XDG_STATE_HOME`).
That file survives deletion of `~/.cache/nisfetch`. It is checked against
local and sync package DB metadata, including nanosecond timestamps and sizes,
so package transactions invalidate it. First index creation or a DB change
still incurs the full libalpm classification cost. It is a prepared index,
**not** a faster truly empty-cache repository scan.

Clearing only `~/.cache/nisfetch` benchmarks a cache-cleared launch with the
prepared index. For a genuinely unindexed run, also remove the exact index
file or move it temporarily out of the way, then restore it.

```bash
# Cache-cleared, but with the persistent package index retained:
hyperfine -N --warmup 0 --runs 30 \
  --prepare 'rm -rf "$HOME/.cache/nisfetch"' \
  "$HOME/.local/bin/nisfetch --no-config --no-logo --modules os:kernel:cpu:gpu:memory:packages"

# Recompute foreign package classification after package DB changes:
nisfetch --no-config --no-logo --modules packages --profile
```

Use the same module set when comparing to Fastfetch, and be explicit about
whether the persistent index is present.

## Privacy and license

The default `Local IP` value remains the screenshot-friendly
`1337.1337.1337`; request `ipv4` or `interfaces` explicitly to inspect actual
network details. Sensitive modules such as `machineid` and `bootid` are
optional, not part of the default preset.

The code is released under the **MIT License**; see [LICENSE](LICENSE).
Distribution names and logos may be trademarks of their respective owners.

**Made by Nisve.**
