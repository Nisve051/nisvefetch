"""NISFETCH 3.1.0 monitor fixtures: no real KDE session is required."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


BIN = os.environ.get("NISFETCH_BIN", "./nisfetch")


def fake_edid(vendor="GSM", model="UltraGear", valid=True):
    data = bytearray(128)
    data[0:8] = b"\x00\xff\xff\xff\xff\xff\xff\x00"
    word = sum((ord(c) - 64) << shift for c, shift in zip(vendor, (10, 5, 0)))
    data[8], data[9] = word >> 8, word & 255
    data[21], data[22] = 52, 30
    clock = 13500  # 135 MHz: 1280x1024 approximately 75 Hz preferred
    data[54], data[55] = clock & 255, clock >> 8
    hactive, hblank = 1280, 408
    vactive, vblank = 1024, 42
    data[56] = hactive & 255
    data[57] = hblank & 255
    data[58] = ((hactive >> 8) << 4) | (hblank >> 8)
    data[59] = vactive & 255
    data[60] = vblank & 255
    data[61] = ((vactive >> 8) << 4) | (vblank >> 8)
    data[72:77] = b"\x00\x00\x00\xfc\x00"
    data[77:90] = model.encode("ascii")[:13].ljust(13, b" ")
    data[127] = -sum(data[:127]) & 255
    if not valid:
        data[127] ^= 1
    return bytes(data)


class DisplayDetailsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.drm = root / "drm"
        self.drm.mkdir()
        connector = self.drm / "card0-HDMI-A-1"
        connector.mkdir()
        (connector / "status").write_text("connected\n", encoding="ascii")
        (connector / "edid").write_bytes(fake_edid())
        self.kscreen = root / "kscreen.txt"
        self.kscreen.write_text(
            "Output: 1 HDMI-A-1 enabled connected\n"
            "  Modes: 1:1920x1080@60.00! 2:1280x1024@75.02* 3:1024x768@60.00\n",
            encoding="ascii",
        )
        self.env = os.environ.copy()
        self.env.update({
            "NISFETCH_TEST_DRM_ROOT": str(self.drm),
            "NISFETCH_TEST_KSCREEN_FILE": str(self.kscreen),
            "XDG_CURRENT_DESKTOP": "KDE",
            "XDG_SESSION_TYPE": "wayland",
            "XDG_CACHE_HOME": str(root / "cache"),
        })

    def run_fetch(self, *args):
        result = subprocess.run(
            [BIN, "--no-config", "--no-logo", *args],
            text=True, capture_output=True, env=self.env, check=True,
        )
        return result.stdout

    def test_display_shows_brand_current_hz_and_resolution(self):
        output = self.run_fetch("--modules", "display")
        self.assertIn("1280x1024 @ 75.02 Hz", output)
        self.assertIn("LG UltraGear", output)
        self.assertNotIn("(preferred)", output)

    def test_monitor_modules(self):
        output = self.run_fetch(
            "--modules", "monitor:refreshrate:displayconnector:displaysize:monitorcount"
        )
        for expected in ("LG UltraGear", "75.02 Hz", "HDMI-A-1", "52.0 x 30.0 cm"):
            self.assertIn(expected, output)
        self.assertIn("monitorcount:", output)

    def test_unmarked_mode_is_not_claimed_as_current(self):
        self.kscreen.write_text("Modes: 1:1920x1080@60.00!\n", encoding="ascii")
        output = self.run_fetch("--modules", "display:refreshrate")
        self.assertIn("(preferred)", output)
        self.assertIn("1280x1024", output)

    def test_corrupt_edid_is_not_reported(self):
        (self.drm / "card0-HDMI-A-1" / "edid").write_bytes(fake_edid(valid=False))
        output = self.run_fetch("--modules", "monitor:refreshrate:monitorcount")
        self.assertNotIn("LG UltraGear", output)
        self.assertIn("monitorcount:", output)
        self.assertIn("75.02 Hz", output)

    def test_module_count_and_details_flag(self):
        result = subprocess.run([BIN, "--list-modules"], text=True, capture_output=True, check=True)
        modules = result.stdout.splitlines()
        self.assertEqual(len(modules), 163)
        self.assertEqual(len(set(modules)), 163)
        output = self.run_fetch("--detailed", "--modules", "display:cpu:memory")
        self.assertIn("75.02 Hz", output)


if __name__ == "__main__":
    unittest.main()
