"""Theme accents must include the user@host title, including CLI overrides."""

import json
import os
import pathlib
import pty
import subprocess
import tempfile
import unittest


BIN = os.environ.get("NISFETCH_BIN", str(pathlib.Path.home() / ".local/bin/nisfetch"))


class ThemeTitleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="nisfetch-theme-")
        self.addCleanup(self.temp.cleanup)
        self.root = pathlib.Path(self.temp.name)
        self.config = self.root / "config.jsonc"

    def run_tty(self, *args, data=None, no_color=False):
        if data is not None:
            self.config.write_text(json.dumps(data))
        env = os.environ.copy()
        env.update(HOME=str(self.root), XDG_CACHE_HOME=str(self.root / "cache"))
        env.pop("NO_COLOR", None)
        master, slave = pty.openpty()
        try:
            argv = [BIN, "--no-logo", "--no-palette", "--modules", "title:separator:os"]
            if data is None:
                argv.append("--no-config")
            else:
                argv.extend(("--config", str(self.config)))
            argv.extend(args)
            if no_color:
                argv.append("--no-color")
            completed = subprocess.run(argv, stdout=slave, stderr=subprocess.PIPE,
                                       env=env, timeout=10)
            os.close(slave)
            slave = -1
            chunks = []
            while True:
                try:
                    chunk = os.read(master, 8192)
                except OSError:
                    break
                if not chunk:
                    break
                chunks.append(chunk)
            return completed.returncode, b"".join(chunks).decode(errors="replace"), completed.stderr
        finally:
            if slave >= 0:
                os.close(slave)
            os.close(master)

    def test_each_theme_changes_title_and_key_in_sync(self):
        themes = {
            "vivid": "255;218;120", "bright": "255;218;120",
            "soft": "219;190;143", "mono": "232;238;246",
            "ice": "120;211;255", "forest": "143;238;168",
            "rose": "255;167;203", "classic": "255;211;110",
        }
        for theme, rgb in themes.items():
            with self.subTest(theme=theme):
                code, out, err = self.run_tty("--theme", theme)
                self.assertEqual(code, 0, err)
                self.assertRegex(out.splitlines()[0],
                                 r"\x1b\[1;38;2;" + rgb + r"m[^\r\n]+@")
                self.assertIn("\x1b[1;38;2;" + rgb + "mOS:", out)

    def test_stock_theme_has_matching_title_without_config(self):
        code, out, err = self.run_tty()
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;255;218;120m", out.splitlines()[0])

    def test_brightness_dimming_and_lightening(self):
        cases = ((50, "60;106;128"), (100, "120;211;255"),
                 (150, "188;233;255"))
        for percent, rgb in cases:
            with self.subTest(percent=percent):
                code, out, err = self.run_tty("--theme", "ice", "--theme-brightness", str(percent))
                self.assertEqual(code, 0, err)
                self.assertIn("\x1b[1;38;2;" + rgb + "m", out.splitlines()[0])
                self.assertIn("\x1b[1;38;2;" + rgb + "mOS:", out)

    def test_config_brightness_and_cli_precedence(self):
        data = {"display": {"theme": "ice", "themeBrightness": 50}}
        code, out, err = self.run_tty(data=data)
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;60;106;128m", out.splitlines()[0])
        code, out, err = self.run_tty("--theme-brightness", "100", data=data)
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;120;211;255m", out.splitlines()[0])

    def test_brightness_adjusts_module_overrides(self):
        data = {"moduleValueColors": {"title": "#224466"},
                "moduleColors": {"os": "#224466"}}
        code, out, err = self.run_tty("--theme-brightness", "50", data=data)
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;17;34;51m", out.splitlines()[0])
        self.assertIn("\x1b[1;38;2;17;34;51mOS:", out)

    def test_invalid_brightness_rejected(self):
        for value in ("0", "19", "181", "many", "999999999999999999999999"):
            with self.subTest(value=value):
                code, _, err = self.run_tty("--theme-brightness", value)
                self.assertEqual(code, 2)
                self.assertIn(b"--theme-brightness", err)
        for value in ("0", "200", "very"):
            with self.subTest(config_value=value):
                code, _, err = self.run_tty(data={"display": {"themeBrightness": value}})
                self.assertEqual(code, 2)
                self.assertIn(b"Invalid JSONC", err)

    def test_config_theme_and_title_override(self):
        code, out, err = self.run_tty(data={"display": {"theme": "ice"}})
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;120;211;255m", out.splitlines()[0])

        code, out, err = self.run_tty(data={"display": {
            "theme": "forest", "keyColor": "#112233"}})
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;17;34;51m", out.splitlines()[0])

        code, out, err = self.run_tty(data={"display": {
            "theme": "ice", "titleColor": "#224466"}})
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;34;68;102m", out.splitlines()[0])

    def test_cli_theme_overrides_saved_title_color(self):
        code, out, err = self.run_tty("--theme", "rose", data={"display": {
            "theme": "ice", "titleColor": "#abcdef", "keyColor": "#000011"}})
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;255;167;203m", out.splitlines()[0])
        self.assertNotIn("\x1b[1;38;2;171;205;239m", out.splitlines()[0])

    def test_per_module_title_color_still_wins(self):
        code, out, err = self.run_tty("--theme", "rose", data={
            "moduleValueColors": {"title": "#123456"}})
        self.assertEqual(code, 0, err)
        self.assertIn("\x1b[1;38;2;18;52;86m", out.splitlines()[0])

    def test_no_color_and_unknown_theme(self):
        code, out, err = self.run_tty("--theme", "forest", no_color=True)
        self.assertEqual(code, 0, err)
        self.assertNotIn("\x1b", out)
        code, _, err = self.run_tty("--theme", "bad-theme")
        self.assertEqual(code, 2)
        self.assertIn(b"Unknown theme", err)


if __name__ == "__main__":
    unittest.main()
