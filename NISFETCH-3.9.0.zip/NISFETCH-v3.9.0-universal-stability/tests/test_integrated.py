"""Smoke/graphics-protocol tests for the *integrated* C NISFETCH binary."""

import os
import base64
import pty
from pathlib import Path
import random
import re
import subprocess
import tempfile
import unittest
import zlib

from PIL import Image, ImageDraw

EXECUTABLE = Path(os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch")))


class IntegratedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.png = Path(cls.temp.name) / "transparent.png"
        picture = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
        ImageDraw.Draw(picture).ellipse((8, 8, 92, 92), fill=(42, 163, 238, 255))
        picture.save(cls.png)
        cls.gif = Path(cls.temp.name) / "animated.gif"
        frames = []
        for xpos in (5, 28, 51):
            image = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
            draw = ImageDraw.Draw(image)
            draw.ellipse((xpos, 20, xpos + 40, 65), fill=(255, 195, 0, 255))
            frames.append(image)
        frames[0].save(cls.gif, save_all=True, append_images=frames[1:],
                       duration=[60, 100, 140], loop=0, disposal=2)
        cls.noisy_gif = Path(cls.temp.name) / "large-animated.gif"
        noisy_frames = []
        for seed in (104, 105, 106):
            rng = random.Random(seed)
            rgb = bytes(rng.getrandbits(8) for _ in range(128 * 128 * 3))
            noisy_frames.append(Image.frombytes("RGB", (128, 128), rgb)
                                .quantize(colors=256))
        noisy_frames[0].save(cls.noisy_gif, save_all=True,
                             append_images=noisy_frames[1:],
                             duration=[70, 110, 150], loop=0)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_fetch(self, *args, **kw):
        return subprocess.run([str(EXECUTABLE), "--no-config", *args],
                              capture_output=True, timeout=15, check=True, **kw)

    def test_163_modules_listed(self):
        names = self.run_fetch("--list-modules").stdout.decode().splitlines()
        self.assertEqual(len(names), 163)
        self.assertEqual(len(set(names)), 163)
        self.assertIn("gpuvram", names)
        self.assertIn("batteryhealth", names)
        self.assertIn("gpudriver", names)
        self.assertIn("memorypressure", names)
        self.assertIn("batterycycles", names)

    def test_kitty_png_uses_exact_original_bytes(self):
        out = self.run_fetch("--image", str(self.png), "--image-backend", "kitty",
                             "--modules", "os").stdout
        self.assertIn(b"a=t,f=100", out)
        self.assertIn(b"a=p,U=1", out)
        self.assertIn("\U0010EEEE".encode(), out)
        graphics = re.findall(rb"\x1b_G([^;\x1b]*);(.*?)\x1b\\", out, re.DOTALL)
        parts = [payload for keys, payload in graphics
                 if keys.startswith(b"a=t,f=100") or keys.startswith(b"m=")]
        self.assertEqual(base64.b64decode(b"".join(parts)), self.png.read_bytes())

    def test_konsole_png_has_no_unicode_placeholders(self):
        env = os.environ.copy()
        env.pop("KITTY_WINDOW_ID", None)
        env.update(KONSOLE_VERSION="260803", TERM="xterm-256color")
        for backend in ("konsole", "kitty"):
            with self.subTest(backend=backend):
                out = self.run_fetch("--image", str(self.png), "--image-backend", backend,
                                     "--modules", "os", env=env).stdout
                self.assertIn(b"a=t,f=100", out)
                self.assertIn(b"a=p,i=", out)
                self.assertIn(b"C=1", out)
                self.assertNotIn(b"U=1", out)
                self.assertNotIn("\U0010EEEE".encode(), out)
                self.assertIn(b"OS:", out)
                self.assertTrue(out.endswith(b"\n\n\n"))

    def test_auto_konsole_pty_backend(self):
        """Auto mode must pick physical placement in a genuine TTY."""
        env = os.environ.copy()
        env.pop("KITTY_WINDOW_ID", None)
        env.update(KONSOLE_VERSION="260803", TERM="xterm-256color")
        master, slave = pty.openpty()
        try:
            p = subprocess.Popen([str(EXECUTABLE), "--no-config", "--image",
                                  str(self.png), "--modules", "os"],
                                 stdin=slave, stdout=slave, stderr=subprocess.PIPE,
                                 env=env)
            os.close(slave)
            slave = -1
            chunks = []
            while True:
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break  # PTY signals EIO at EOF on Linux
                if not data:
                    break
                chunks.append(data)
            self.assertEqual(p.wait(timeout=15), 0)
            p.stderr.close()
            out = b"".join(chunks)
            self.assertIn(b"a=p,i=", out)
            self.assertNotIn(b"U=1", out)
        finally:
            if slave >= 0:
                os.close(slave)
            os.close(master)

    def test_png_ansi_without_graphics_escape(self):
        out = self.run_fetch("--image", str(self.png), "--image-backend", "ansi",
                             "--modules", "os").stdout
        self.assertNotIn(b"\x1b_G", out)
        self.assertIn(b"OS:", out)

    def test_kitty_gif_animated_and_scrollback_bound(self):
        out = self.run_fetch("--image", str(self.gif), "--image-backend", "kitty",
                             "--modules", "os:cpucores").stdout
        self.assertIn(b"a=t,f=32", out)
        self.assertEqual(out.count(b"a=f,f=32"), 2)
        self.assertEqual(out.count(b"X=1,z="), 2)
        self.assertIn(b",o=z,", out)
        self.assertIn(b"a=p,U=1", out)
        self.assertIn(b"s=2,q=2", out)
        self.assertIn(b"s=3,v=1", out)
        self.assertLess(out.index(b"s=2,q=2"), out.index(b"a=p,U=1"))
        self.assertLess(out.index(b"a=p,U=1"), out.index(b"s=3,v=1"))
        self.assertIn("\U0010EEEE".encode(), out)
        self.assertIn(b"OS:", out)
        self.assertTrue(out.endswith(b"\n\n\n"))
        self.assertNotIn(b"\x1b[?1049h", out)
        graphics = re.findall(rb"\x1b_G([^;\x1b]*);(.*?)\x1b\\", out, re.DOTALL)
        raw_frames, chunks, compression, dimensions = [], bytearray(), False, None
        for keys, payload in graphics:
            if b"a=t," in keys or b"a=f," in keys:
                compression = b"o=z" in keys
                width = int(re.search(rb"(?:^|,)s=(\d+)", keys).group(1))
                height = int(re.search(rb"(?:^|,)v=(\d+)", keys).group(1))
                dimensions = (width, height)
            if payload:
                chunks.extend(payload)
                if b"m=0" in keys:
                    pixels = base64.b64decode(chunks)
                    if compression:
                        pixels = zlib.decompress(pixels)
                    self.assertEqual(len(pixels), dimensions[0] * dimensions[1] * 4)
                    raw_frames.append(pixels)
                    chunks.clear()
        self.assertEqual(len(raw_frames), 3)
        self.assertNotEqual(raw_frames[0], raw_frames[1])
        self.assertNotEqual(raw_frames[1], raw_frames[2])

    def test_static_ansi_has_no_terminal_background_worker(self):
        out = self.run_fetch("--image", str(self.gif), "--image-backend", "ansi",
                             "--modules", "os").stdout
        self.assertNotIn(b"\x1b_G", out)
        self.assertNotIn("\U0010EEEE".encode(), out)
        self.assertIn(b"OS:", out)

    def test_no_animate_disables_loop(self):
        out = self.run_fetch("--image", str(self.gif), "--image-backend", "kitty",
                             "--no-animate", "--modules", "os").stdout
        self.assertNotIn(b"s=3,v=1", out)
        self.assertNotIn(b"a=f,f=32", out)

    def test_large_gif_frames_use_valid_kitty_continuations(self):
        """Check frames too large to fit in a single Kitty APC transfer."""
        out = self.run_fetch("--image", str(self.noisy_gif),
                             "--image-backend", "kitty",
                             "--modules", "os").stdout
        graphics = re.findall(rb"\x1b_G([^;\x1b]*);(.*?)\x1b\\", out, re.DOTALL)
        frames, chunks = [], []
        frame_transfer = False
        continuation_count = 0
        for keys, payload in graphics:
            if keys.startswith((b"a=t,", b"a=f,f=32,")):
                self.assertEqual(chunks, [])
                frame_transfer = keys.startswith(b"a=f,")
                self.assertIn(b"o=z", keys)
            elif keys.startswith((b"a=f,m=", b"m=")):
                continuation_count += 1
                self.assertEqual(keys.startswith(b"a=f,m="), frame_transfer)
            else:
                continue
            self.assertFalse(keys.startswith(b","))
            chunks.append(payload)
            if b"m=0" in keys:
                pixels = zlib.decompress(base64.b64decode(b"".join(chunks)))
                self.assertEqual(len(pixels), 128 * 128 * 4)
                frames.append(pixels)
                chunks.clear()
        self.assertEqual(len(frames), 3)
        self.assertGreaterEqual(continuation_count, 3)
        self.assertNotEqual(frames[0], frames[1])
        self.assertNotEqual(frames[1], frames[2])

    def test_direct_new_modules(self):
        out = self.run_fetch("--no-logo", "--modules",
                             "memcached:gpuusage:gpuvram:gpumemoryused:cpugovernor:"
                             "cpufreqmin:cpufreqmax:batteryhealth:androidbrand:androidhardware").stdout
        self.assertIn(b"memcached:", out)


if __name__ == "__main__":
    unittest.main()
