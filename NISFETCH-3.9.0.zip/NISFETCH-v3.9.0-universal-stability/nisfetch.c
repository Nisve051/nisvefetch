#define _XOPEN_SOURCE 700
#define _POSIX_C_SOURCE 200809L
#ifndef __ANDROID__
#define _DEFAULT_SOURCE 1
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/statvfs.h>
#include <pwd.h>
#include <ctype.h>
#include <stdint.h>
#include <stddef.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <math.h>
#include <time.h>
#include <locale.h>
#include <wchar.h>
#include <limits.h>
#include <sys/statvfs.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
#include <png.h>
#include <gif_lib.h>
#include <zlib.h>
#include <termios.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <poll.h>
#if defined(__linux__)
#include <sys/syscall.h>
#endif
#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

#define R "\033[0m"
#define MAX_ROWS 192
#define C "\033[1;38;2;244;194;105m"
#define ACCENT "\033[1;38;2;251;212;135m"
#define SOFT "\033[1;38;2;223;233;239m"
#define MUTED "\033[38;2;151;169;180m"
static int output_color=1;
static int detailed_output=0;
#include "nis_monitor.h"
#include "nis_memory_hw.h"
#include "nis_mount_hw.h"
#include "nis_tux.h"
#include "nis_distro_pixels.h"
/* Truecolor half-block renderer. Transparent pixels reset the terminal
   background; source pixel sampling is handled by the artwork renderers. */
static void pixel_pair(const unsigned char *top,const unsigned char *bottom,int ta,int ba){
 if(!output_color){
  fputs(!ta&&!ba?" ":ta&&ba?"█":ta?"▀":"▄",stdout);
  return;
 }
 if(!ta&&!ba){fputs("\033[49m ",stdout);return;}
 if(ta&&ba){
  printf("\033[38;2;%u;%u;%um\033[48;2;%u;%u;%um▀",top[0],top[1],top[2],bottom[0],bottom[1],bottom[2]);
 }else if(ta){
  printf("\033[49m\033[38;2;%u;%u;%um▀",top[0],top[1],top[2]);
 }else{
  printf("\033[49m\033[38;2;%u;%u;%um▄",bottom[0],bottom[1],bottom[2]);
 }
}
/* An RGBA source is retained for the native Tux artwork. The terminal has
   only two half-block pixels per cell, so interpolation is deliberately
   premultiplied and scoped to the terminal-resolution result. */
/* Preserve Tux's antialiased edge pixels instead of deleting everything with
   alpha below 245.  Premultiplied bilinear sampling avoids the light halos
   that ordinary interpolation introduces around transparent RGBA pixels. */
static void tux_sample(double x,double y,unsigned char out[4]){
 int x0=(int)floor(x),y0=(int)floor(y);
 double fx=x-x0,fy=y-y0;
 if(x0<0){x0=0;fx=0;}if(y0<0){y0=0;fy=0;}
 if(x0>=TUX_W-1){x0=TUX_W-1;fx=0;}
 if(y0>=TUX_H-1){y0=TUX_H-1;fy=0;}
 int x1=x0+1<TUX_W?x0+1:x0,y1=y0+1<TUX_H?y0+1:y0;
 double w[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
 const unsigned char *p[4]={tux_rgba+((size_t)y0*TUX_W+x0)*4,tux_rgba+((size_t)y0*TUX_W+x1)*4,
  tux_rgba+((size_t)y1*TUX_W+x0)*4,tux_rgba+((size_t)y1*TUX_W+x1)*4};
 double a=0,r=0,g=0,b=0;
 for(int i=0;i<4;i++){double aw=w[i]*p[i][3];a+=aw;r+=aw*p[i][0];g+=aw*p[i][1];b+=aw*p[i][2];}
 out[3]=(unsigned char)lround(a);
 out[0]=a>0?(unsigned char)lround(r/a):0;
 out[1]=a>0?(unsigned char)lround(g/a):0;
 out[2]=a>0?(unsigned char)lround(b/a):0;
}
static void tux_pixel_mix(const unsigned char source[4],unsigned char out[4]){
 /* The dark outline stays visible with softened edges on dark themes. */
 static const int bg[3]={18,20,25};
 for(int c=0;c<3;c++)out[c]=(unsigned char)((source[c]*source[3]+bg[c]*(255-source[3])+127)/255);
 out[3]=source[3];
}
static void tux_row_scaled(size_t row,int width,int height){
 for(int x=0;x<width;x++){
  double sx=((double)x+0.5)*TUX_W/width-0.5;
  double sy0=((double)(2*row)+0.5)*TUX_H/(2*height)-0.5;
  double sy1=((double)(2*row)+1.5)*TUX_H/(2*height)-0.5;
  unsigned char a[4],b[4],top[4],bottom[4];
  tux_sample(sx,sy0,a);tux_sample(sx,sy1,b);
  tux_pixel_mix(a,top);tux_pixel_mix(b,bottom);
  pixel_pair(top,bottom,a[3]>=12,b[3]>=12);
 }
 if(output_color)fputs(R,stdout);
}


/* Optional user artwork: PNG RGBA and GIF89a. Bounds protect terminal memory. */
typedef struct {unsigned char *rgba;int w,h;GifFileType *gif;} UserImage;
static int png_graphics_mode(void);
static void image_free(UserImage *im){
 if(im->gif){int err=0;DGifCloseFile(im->gif,&err);im->gif=NULL;}
 free(im->rgba);im->rgba=NULL;im->w=im->h=0;
}
static int image_size_ok(unsigned int w,unsigned int h){return w>0&&h>0&&w<=2048&&h<=2048&&(size_t)w*h<=4194304;}
/* For native terminal PNG rendering we only need dimensions. Validate the
   IHDR and its CRC; the terminal will decode the unmodified PNG payload. */
static int image_png_probe(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size<33||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 unsigned char h[33];int ok=fread(h,1,sizeof h,fp)==sizeof h;
 fclose(fp);
 if(!ok||png_sig_cmp(h,0,8)||memcmp(h+8,"\0\0\0\rIHDR",8))return 0;
 unsigned w=((unsigned)h[16]<<24)|((unsigned)h[17]<<16)|((unsigned)h[18]<<8)|h[19];
 unsigned height=((unsigned)h[20]<<24)|((unsigned)h[21]<<16)|((unsigned)h[22]<<8)|h[23];
 if(!image_size_ok(w,height))return 0;
 uLong crc=crc32(0L,Z_NULL,0);
 crc=crc32(crc,h+12,17);
 unsigned expected=((unsigned)h[29]<<24)|((unsigned)h[30]<<16)|((unsigned)h[31]<<8)|h[32];
 if((unsigned)crc!=expected)return 0;
 im->w=(int)w;im->h=(int)height;
 return 1;
}
static int image_png_full(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 unsigned char sig[8];if(fread(sig,1,8,fp)!=8||png_sig_cmp(sig,0,8)){fclose(fp);return 0;}
 png_structp png=png_create_read_struct(PNG_LIBPNG_VER_STRING,NULL,NULL,NULL);
 if(!png){fclose(fp);return 0;}
 png_infop info=png_create_info_struct(png);
 if(!info){png_destroy_read_struct(&png,NULL,NULL);fclose(fp);return 0;}
 png_bytep *rows=NULL;
 if(setjmp(png_jmpbuf(png))){free(rows);image_free(im);png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 0;}
 png_init_io(png,fp);png_set_sig_bytes(png,8);png_read_info(png,info);
 png_uint_32 w=png_get_image_width(png,info),h=png_get_image_height(png,info);
 if(!image_size_ok(w,h)){png_error(png,"Image too large");}
 int color=png_get_color_type(png,info),depth=png_get_bit_depth(png,info);
 if(depth==16)png_set_strip_16(png);
 if(color==PNG_COLOR_TYPE_PALETTE)png_set_palette_to_rgb(png);
 if(color==PNG_COLOR_TYPE_GRAY&&depth<8)png_set_expand_gray_1_2_4_to_8(png);
 if(png_get_valid(png,info,PNG_INFO_tRNS))png_set_tRNS_to_alpha(png);
 if(color==PNG_COLOR_TYPE_GRAY||color==PNG_COLOR_TYPE_GRAY_ALPHA)png_set_gray_to_rgb(png);
 if(!(color&PNG_COLOR_MASK_ALPHA)&&!png_get_valid(png,info,PNG_INFO_tRNS))png_set_add_alpha(png,255,PNG_FILLER_AFTER);
 png_read_update_info(png,info);
 if(png_get_rowbytes(png,info)!=(size_t)w*4)png_error(png,"Unexpected PNG format");
 im->rgba=malloc((size_t)w*h*4);rows=malloc((size_t)h*sizeof *rows);
 if(!im->rgba||!rows)png_error(png,"Out of memory");
 for(png_uint_32 y=0;y<h;y++)rows[y]=im->rgba+(size_t)y*w*4;
 png_read_image(png,rows);png_read_end(png,NULL);im->w=(int)w;im->h=(int)h;
 free(rows);png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 1;
}
static int image_png(const char *path,UserImage *im){
 if(png_graphics_mode()&&image_png_probe(path,im))return 1;
 return image_png_full(path,im);
}
static int image_gif(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size>33554432)return 0;
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);if(!gif)return 0;
 int ok=0;
 if(DGifSlurp(gif)==GIF_OK&&image_size_ok((unsigned)gif->SWidth,(unsigned)gif->SHeight)&&gif->ImageCount>0&&gif->ImageCount<=200){
  int w=gif->SWidth,h=gif->SHeight;im->rgba=calloc((size_t)w*h,4);
  if(im->rgba){
   SavedImage *frame=&gif->SavedImages[0];ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   int transparent=-1;
   for(int k=0;k<frame->ExtensionBlockCount;k++){
    ExtensionBlock *ex=&frame->ExtensionBlocks[k];
    if(ex->Function==GRAPHICS_EXT_FUNC_CODE&&ex->ByteCount>=4&&(ex->Bytes[0]&1))transparent=(unsigned char)ex->Bytes[3];
   }
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=w||yy>=h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==transparent)continue;
     GifColorType c=map->Colors[index];unsigned char *out=im->rgba+((size_t)yy*w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
    im->w=w;im->h=h;ok=1;
   }
  }
 }
 if(ok)im->gif=gif;
 else {DGifCloseFile(gif,&err);image_free(im);}
 return ok;
}
static int image_load(const char *path,UserImage *im){
 const char *ext=strrchr(path,'.');
 if(ext&&(!strcasecmp(ext,".png")))return image_png(path,im);
 if(ext&&(!strcasecmp(ext,".gif")))return image_gif(path,im);
 return 0;
}
static void image_row(const UserImage *im,size_t row,int width,int height){
 for(int x=0;x<width;x++){
  double sx=((double)x+0.5)*im->w/width-0.5;
  double sy[2]={((double)(2*row)+0.5)*im->h/(2*height)-0.5,
                ((double)(2*row)+1.5)*im->h/(2*height)-0.5};
  unsigned char colors[2][4],mixed[2][4];
  int x0=(int)floor(sx);double fx=sx-x0;
  if(x0<0){x0=0;fx=0;}if(x0>=im->w-1){x0=im->w-1;fx=0;}
  int x1=x0+1<im->w?x0+1:x0;
  for(int k=0;k<2;k++){
   int y0=(int)floor(sy[k]);double fy=sy[k]-y0;
   if(y0<0){y0=0;fy=0;}if(y0>=im->h-1){y0=im->h-1;fy=0;}
   int y1=y0+1<im->h?y0+1:y0;
   const unsigned char *p[4]={
    im->rgba+((size_t)y0*im->w+x0)*4,im->rgba+((size_t)y0*im->w+x1)*4,
    im->rgba+((size_t)y1*im->w+x0)*4,im->rgba+((size_t)y1*im->w+x1)*4};
   double weights[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double a=0,r=0,g=0,b=0;
   for(int j=0;j<4;j++){double aw=weights[j]*p[j][3];a+=aw;r+=aw*p[j][0];g+=aw*p[j][1];b+=aw*p[j][2];}
   colors[k][3]=(unsigned char)lround(a);
   colors[k][0]=a>0?(unsigned char)lround(r/a):0;
   colors[k][1]=a>0?(unsigned char)lround(g/a):0;
   colors[k][2]=a>0?(unsigned char)lround(b/a):0;
   tux_pixel_mix(colors[k],mixed[k]);
  }
  pixel_pair(mixed[0],mixed[1],colors[0][3]>=12,colors[1][3]>=12);
 }
 if(output_color)fputs(R,stdout);
}



/* PNG uses two distinct native placements: Kitty supports scrollback-linked
   Unicode placeholders; Konsole supports cursor-bound placement but does NOT
   support those placeholders. Do not send private-use glyphs to Konsole. */
static int image_backend=0;
static int terminal_is_kitty(void){
 const char *term=getenv("TERM"),*id=getenv("KITTY_WINDOW_ID");
 return (id&&*id)||(term&&strstr(term,"kitty")!=NULL);
}
static int terminal_is_konsole(void){
 if(terminal_is_kitty())return 0;
 const char *version=getenv("KONSOLE_VERSION"),*service=getenv("KONSOLE_DBUS_SERVICE"),*program=getenv("TERM_PROGRAM");
 return (version&&*version)||(service&&*service)||(program&&!strcasecmp(program,"konsole"));
}
/* 0 = ANSI fallback, 1 = Kitty placeholders, 2 = Konsole physical placement.
   Neither terminal is assumed to accept graphics in a pipe. */
static int png_graphics_mode(void){
 if(image_backend==1)return 0;
 if(image_backend==3)return 2;
 if(image_backend==2)return terminal_is_konsole()?2:1;
 if(!isatty(STDOUT_FILENO))return 0;
 return terminal_is_kitty()?1:(terminal_is_konsole()?2:0);
}
static int native_graphics_supported(void){
 if(image_backend==1)return 0;
 if(terminal_is_konsole())return 0;
 if(image_backend==2)return 1;
 if(!isatty(STDOUT_FILENO))return 0;
 return terminal_is_kitty();
}
static void kitty_payload(const char *header,const unsigned char *data,size_t len){
 static const char alphabet[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 size_t i=0;int first=1;
 /* Every continuation of an animated frame MUST carry a=f. Otherwise Kitty
    can accept the root frame but silently lose subsequent large GIF frames. */
 const int frame=strncmp(header,"a=f,",4)==0;
 while(i<len){
  size_t count=len-i;if(count>3072)count=3072;
  int more=i+count<len;
  if(first)printf("\033_G%s,m=%d;",header,more);
  else if(frame)printf("\033_Ga=f,m=%d;",more);
  else printf("\033_Gm=%d;",more);
  for(size_t j=0;j<count;j+=3){
   unsigned a=data[i+j],b=j+1<count?data[i+j+1]:0,c=j+2<count?data[i+j+2]:0;
   putchar(alphabet[a>>2]);putchar(alphabet[((a&3)<<4)|(b>>4)]);
   putchar(j+1<count?alphabet[((b&15)<<2)|(c>>6)]:'=');
   putchar(j+2<count?alphabet[c&63]:'=');
  }
  fputs("\033\\",stdout);i+=count;first=0;
 }
}
/* RGBA is zlib-compressed before base64: huge GIFs no longer fall back to a
   grainy static preview just because the raw frame count exceeds 48 MiB. */
static void kitty_rgba(const char *header,const unsigned char *pixels,size_t len){
 uLongf bound=compressBound((uLong)len),compressed_len=bound;
 unsigned char *compressed=malloc((size_t)bound);
 if(compressed&&compress2(compressed,&compressed_len,pixels,(uLong)len,Z_BEST_SPEED)==Z_OK&&compressed_len<len){
  char control[192];snprintf(control,sizeof control,"%s,o=z",header);
  kitty_payload(control,compressed,(size_t)compressed_len);
 }else kitty_payload(header,pixels,len);
 free(compressed);
}
static unsigned kitty_image_id=0;
/* Send the ORIGINAL PNG bytes (Kitty f=100), not a decoded/resampled RGBA
   copy. This preserves exact image quality and avoids a second encode. */
static int kitty_png_render(const char *path,int cols,int rows,int physical){
 if(cols<1||rows<1||cols>120||rows>120)return 0;
 struct stat st;
 if(stat(path,&st)||st.st_size<=8||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 size_t len=(size_t)st.st_size;
 unsigned char *data=malloc(len);
 if(!data){fclose(fp);return 0;}
 int ok=fread(data,1,len,fp)==len;
 fclose(fp);
 if(ok){
  unsigned id=((unsigned)getpid()*2654435761u^(unsigned)time(NULL))&0xffffffu;
  if(!id)id=1;
  kitty_image_id=id;
  char header[128];snprintf(header,sizeof header,"a=t,f=100,i=%u,q=2",id);
  kitty_payload(header,data,len);
  if(physical)printf("\033_Ga=p,i=%u,c=%d,r=%d,C=1,q=2;\033\\",id,cols,rows);
  else printf("\033_Ga=p,U=1,i=%u,c=%d,r=%d,q=2;\033\\",id,cols,rows);
 }
 free(data);
 return ok;
}
/* Scale only when the source is larger than what the terminal can actually
   show.  Bilinear RGBA interpolation is premultiplied to keep transparency
   crisp (no washed-out/white border); pixels are losslessly transferred. */
static void image_downsample(const unsigned char *src,int sw,int sh,
                             unsigned char *dst,int dw,int dh){
 if(sw==dw&&sh==dh){memcpy(dst,src,(size_t)dw*dh*4);return;}
 for(int y=0;y<dh;y++){
  double sy=((double)y+0.5)*sh/dh-0.5;
  int y0=(int)floor(sy);double fy=sy-y0;
  if(y0<0){y0=0;fy=0;}if(y0>=sh-1){y0=sh-1;fy=0;}
  int y1=y0+1<sh?y0+1:y0;
  for(int x=0;x<dw;x++){
   double sx=((double)x+0.5)*sw/dw-0.5;
   int x0=(int)floor(sx);double fx=sx-x0;
   if(x0<0){x0=0;fx=0;}if(x0>=sw-1){x0=sw-1;fx=0;}
   int x1=x0+1<sw?x0+1:x0;
   const unsigned char *a=src+((size_t)y0*sw+x0)*4,*b=src+((size_t)y0*sw+x1)*4;
   const unsigned char *c=src+((size_t)y1*sw+x0)*4,*d=src+((size_t)y1*sw+x1)*4;
   const unsigned char *p[4]={a,b,c,d};
   double w[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double alpha=0,r=0,g=0,blue=0;
   for(int k=0;k<4;k++){double wa=w[k]*p[k][3];alpha+=wa;r+=wa*p[k][0];g+=wa*p[k][1];blue+=wa*p[k][2];}
   unsigned char *o=dst+((size_t)y*dw+x)*4;
   o[3]=(unsigned char)lround(alpha);
   o[0]=alpha>0?(unsigned char)lround(r/alpha):0;
   o[1]=alpha>0?(unsigned char)lround(g/alpha):0;
   o[2]=alpha>0?(unsigned char)lround(blue/alpha):0;
  }
 }
}
/* Scrollback-linked Kitty image placeholders (official Unicode mapping). */
static const unsigned short kitty_marks[]={0x0305,0x030D,0x030E,0x0310,0x0312,0x033D,0x033E,0x033F,0x0346,0x034A,0x034B,0x034C,0x0350,0x0351,0x0352,0x0357,0x035B,0x0363,0x0364,0x0365,0x0366,0x0367,0x0368,0x0369,0x036A,0x036B,0x036C,0x036D,0x036E,0x036F,0x0483,0x0484,0x0485,0x0486,0x0487,0x0592,0x0593,0x0594,0x0595,0x0597,0x0598,0x0599,0x059C,0x059D,0x059E,0x059F,0x05A0,0x05A1,0x05A8,0x05A9,0x05AB,0x05AC,0x05AF,0x05C4,0x0610,0x0611,0x0612,0x0613,0x0614,0x0615,0x0616,0x0617,0x0657,0x0658,0x0659,0x065A,0x065B,0x065D,0x065E,0x06D6,0x06D7,0x06D8,0x06D9,0x06DA,0x06DB,0x06DC,0x06DF,0x06E0,0x06E1,0x06E2,0x06E4,0x06E7,0x06E8,0x06EB,0x06EC,0x0730,0x0732,0x0733,0x0735,0x0736};
static void kitty_utf8(unsigned code){
 if(code<0x800){putchar(0xc0|(code>>6));putchar(0x80|(code&63));}
 else if(code<0x10000){putchar(0xe0|(code>>12));putchar(0x80|((code>>6)&63));putchar(0x80|(code&63));}
 else {putchar(0xf0|(code>>18));putchar(0x80|((code>>12)&63));putchar(0x80|((code>>6)&63));putchar(0x80|(code&63));}
}
static void kitty_placeholder_row(int row,int width){
 unsigned id=kitty_image_id;
 printf("\033[38;2;%u;%u;%um",(id>>16)&255,(id>>8)&255,id&255);
 for(int col=0;col<width;col++){
  kitty_utf8(0x10eeee);
  kitty_utf8(kitty_marks[row]);
  kitty_utf8(kitty_marks[col]);
 }
 fputs("\033[39m",stdout);
}

static int kitty_render(const char *path,const UserImage *im,int cols,int rows,int cycles){
 if(!native_graphics_supported()||cols<1||rows<1||cols>90||rows>90)return 0;
 const char *ext=strrchr(path,'.');
 int gif_file=ext&&!strcasecmp(ext,".gif");
 GifFileType *gif=gif_file?im->gif:NULL;
 if(gif_file){if(!gif)return 0;
  if(gif->ImageCount<1||gif->ImageCount>200||gif->SWidth!=im->w||gif->SHeight!=im->h)return 0;
 }
 size_t bytes=(size_t)im->w*im->h*4;
 /* Render at the terminal's real pixel density, without upscaling originals.
    Keep more image detail than two ANSI half-block pixels per cell. */
 int render_w=im->w,render_h=im->h;
 double factor=1.0;
 if(render_w>cols*10)factor=(double)(cols*10)/render_w;
 if(render_h*factor>rows*20)factor=(double)(rows*20)/render_h;
 if(factor<1.0){render_w=(int)lround(im->w*factor);render_h=(int)lround(im->h*factor);}
 if(render_w<1)render_w=1;
 if(render_h<1)render_h=1;
 size_t framebytes=(size_t)render_w*render_h*4;
 unsigned char *scaled=malloc(framebytes);
 if(!scaled)return 0;
 unsigned char *canvas=NULL,*previous=NULL;
 if(gif){canvas=calloc(bytes,1);previous=malloc(bytes);
  if(!canvas||!previous){free(scaled);free(canvas);free(previous);return 0;}
 }
 unsigned id=((unsigned)getpid()*2654435761u ^ (unsigned)time(NULL))&0xffffffu;if(!id)id=1; kitty_image_id=id;
 int prev_disp=0,px=0,py=0,pw=0,ph=0;
 int transfer_frames=gif?(cycles==-2?1:gif->ImageCount):1;
 for(int f=0;f<transfer_frames;f++){
  const unsigned char *pixels=im->rgba;
  GraphicsControlBlock gcb={0};
  if(gif){
   SavedImage *frame=&gif->SavedImages[f];
   if(f){
    if(prev_disp==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
     if(x>=0&&x<im->w&&y>=0&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
    }else if(prev_disp==3)memcpy(canvas,previous,bytes);
   }
   memcpy(previous,canvas,bytes);
   DGifSavedExtensionToGCB(gif,f,&gcb);
   ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
     GifColorType c=map->Colors[index];unsigned char *out=canvas+((size_t)yy*im->w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
   }
   prev_disp=gcb.DisposalMode;px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
   pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
   pixels=canvas;
  }
  image_downsample(pixels,im->w,im->h,scaled,render_w,render_h);
  char header[160];
  /* Transmit without placing first; after every frame is loaded, create the
     virtual placement whose Unicode cells can scroll like normal text. */
  if(f==0)snprintf(header,sizeof header,"a=t,f=32,s=%d,v=%d,i=%u,q=2",render_w,render_h,id);
  else snprintf(header,sizeof header,"a=f,f=32,s=%d,v=%d,i=%u,X=1,z=%d,q=2",render_w,render_h,id,
   gcb.DelayTime>1?gcb.DelayTime*10:100);
  kitty_rgba(header,scaled,framebytes);
  if(f==0&&gif){
   int delay=gcb.DelayTime>1?gcb.DelayTime*10:100;
   printf("\033_Ga=a,i=%u,r=1,z=%d,q=2\033\\",id,delay);
  }
  /* Mirror Kitty's own icat loader: once two frames exist, enter loading
     mode.  After text placeholders are printed, switch to normal looping. */
  if(f==1&&gif&&transfer_frames>1)
   printf("\033_Ga=a,i=%u,s=2,q=2\033\\",id);
 }
 printf("\033_Ga=p,U=1,i=%u,c=%d,r=%d,q=2;\033\\",id,cols,rows);
 if(gif&&gif->ImageCount>1&&cycles!=-2)
  printf("\033_Ga=a,i=%u,s=3,v=%d,q=2\033\\",id,cycles>0?cycles+1:1);
 free(scaled);free(canvas);free(previous);
 return 1;
}
/* GIF playback: background repaint is restricted to the image rectangle.
   Cursor position is preserved for interactive shell input.
   Composites transparency and disposal=2 (restore background); disposal=3
   restores the previous canvas. */
static void gif_animate(const char *path,UserImage *im,int width,int height,size_t output_rows,int cycles,int start_row){
 (void)output_rows;
 if(width<1||height<1||!isatty(STDOUT_FILENO))return;
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);if(!gif)return;
 if(DGifSlurp(gif)!=GIF_OK||gif->ImageCount<2||gif->ImageCount>200||gif->SWidth!=im->w||gif->SHeight!=im->h){DGifCloseFile(gif,&err);return;}
 size_t bytes=(size_t)im->w*im->h*4;
 unsigned char *canvas=calloc(bytes,1),*previous=malloc(bytes);
 if(!canvas||!previous){free(canvas);free(previous);DGifCloseFile(gif,&err);return;}
 for(int cycle=0;cycles==0||cycle<cycles;cycle++){
  memset(canvas,0,bytes);
  int prior_disposal=0,px=0,py=0,pw=0,ph=0;
  for(int f=0;f<gif->ImageCount;f++){
   SavedImage *frame=&gif->SavedImages[f];
   if(f>0){
    if(prior_disposal==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
     if(x>=0&&y>=0&&x<im->w&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
    }else if(prior_disposal==3)memcpy(canvas,previous,bytes);
   }
   memcpy(previous,canvas,bytes);
   GraphicsControlBlock gcb={0};
   DGifSavedExtensionToGCB(gif,f,&gcb);
   ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
     GifColorType c=map->Colors[index];unsigned char *out=canvas+((size_t)yy*im->w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
   }
   prior_disposal=gcb.DisposalMode;
   px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
   pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
   UserImage view={canvas,im->w,im->h,NULL};
   /* Atomic terminal update where supported (DEC 2026); no cursor jumps. */
   fputs("\033[?2026h\0337",stdout);
   for(int y=0;y<height;y++){
    printf("\033[%d;1H",start_row+y);
    image_row(&view,(size_t)y,width,height);
   }
   fputs("\033[0m\0338\033[?2026l",stdout);fflush(stdout);
   int delay=gcb.DelayTime>0?gcb.DelayTime*10:100;
   if(delay<30)delay=30;
   if(delay>1000)delay=1000;
   struct timespec ts={delay/1000,(delay%1000)*1000000L};nanosleep(&ts,NULL);
  }
 }
 free(canvas);free(previous);DGifCloseFile(gif,&err);
}


/* Ask the terminal for the starting row before printing the fetch.  This is
   only used for interactive TTYs; no shell input is consumed after startup. */
static int __attribute__((unused)) cursor_row_query(void){
 if(!isatty(STDIN_FILENO)||!isatty(STDOUT_FILENO))return 0;
 struct termios saved,raw;
 if(tcgetattr(STDIN_FILENO,&saved)!=0)return 0;
 raw=saved;raw.c_lflag&=(tcflag_t)~(ICANON|ECHO);
 raw.c_cc[VMIN]=0;raw.c_cc[VTIME]=0;
 if(tcsetattr(STDIN_FILENO,TCSANOW,&raw)!=0)return 0;
 fflush(stdout);write(STDOUT_FILENO,"\033[6n",4);
 char buf[48];size_t n=0;int row=0;
 for(int attempts=0;attempts<4&&n<sizeof(buf)-1;attempts++){
  fd_set fds;FD_ZERO(&fds);FD_SET(STDIN_FILENO,&fds);
  struct timeval tv={0,35000};
  if(select(STDIN_FILENO+1,&fds,NULL,NULL,&tv)<=0)break;
  ssize_t got=read(STDIN_FILENO,buf+n,sizeof(buf)-1-n);
  if(got<=0)break;
  n+=(size_t)got;buf[n]=0;
  int col=0;if(sscanf(buf,"\033[%d;%dR",&row,&col)==2&&row>0)break;
 }
 tcsetattr(STDIN_FILENO,TCSANOW,&saved);
 return row;
}
/* Detached worker writes only to its own terminal, and stops when the shell
   that launched NISFETCH exits. Never holds stdin or a shell job open. */
/* Explicit animated preview in the alternate screen. The shell is deliberately
   paused while this preview runs; it never writes over live shell input. */
static volatile sig_atomic_t preview_stop=0;
static void preview_signal(int sig){(void)sig;preview_stop=1;}
static void gif_preview(const char *path,UserImage *im,int width,int height,int cycles){
 if(!isatty(STDOUT_FILENO))return;
 struct sigaction sa={0},oldint={0},oldterm={0};
 sa.sa_handler=preview_signal;sigemptyset(&sa.sa_mask);
 sigaction(SIGINT,&sa,&oldint);sigaction(SIGTERM,&sa,&oldterm);
 preview_stop=0;
 fputs("\033[?1049h\033[?25l",stdout);fflush(stdout);
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);
 if(gif && DGifSlurp(gif)==GIF_OK && gif->ImageCount>0){
  size_t bytes=(size_t)im->w*im->h*4;
  unsigned char *canvas=calloc(bytes,1),*previous=malloc(bytes);
  if(canvas&&previous){
   for(int cycle=0;!preview_stop&&(cycles==0||cycle<cycles);cycle++){
    memset(canvas,0,bytes);
    int prior_disposal=0,px=0,py=0,pw=0,ph=0;
    for(int f=0;f<gif->ImageCount&&!preview_stop;f++){
     SavedImage *frame=&gif->SavedImages[f];
     if(f>0){
      if(prior_disposal==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
       if(x>=0&&y>=0&&x<im->w&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
      }else if(prior_disposal==3)memcpy(canvas,previous,bytes);
     }
     memcpy(previous,canvas,bytes);
     GraphicsControlBlock gcb={0};DGifSavedExtensionToGCB(gif,f,&gcb);
     ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
     if(map&&frame->RasterBits){
      for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
       int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
       if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
       int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
       if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
       GifColorType c=map->Colors[index];unsigned char *o=canvas+((size_t)yy*im->w+xx)*4;
       o[0]=c.Red;o[1]=c.Green;o[2]=c.Blue;o[3]=255;
      }
     }
     prior_disposal=gcb.DisposalMode;px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
     pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
     UserImage view={canvas,im->w,im->h,NULL};
     fputs("\033[H",stdout);
     for(int y=0;y<height;y++){image_row(&view,(size_t)y,width,height);putchar('\n');}
     fputs("\033[0m",stdout);fflush(stdout);
     int delay=gcb.DelayTime>0?gcb.DelayTime*10:100;
     if(delay<30)delay=30;
     if(delay>1000)delay=1000;
     struct timespec ts={delay/1000,(delay%1000)*1000000L};
     while(!preview_stop&&nanosleep(&ts,&ts)<0&&errno==EINTR){}
    }
   }
  }
  free(canvas);free(previous);
 }
 if(gif)DGifCloseFile(gif,&err);
 fputs("\033[0m\033[?25h\033[?1049l",stdout);fflush(stdout);
 sigaction(SIGINT,&oldint,NULL);sigaction(SIGTERM,&oldterm,NULL);
}

static void __attribute__((unused)) start_gif_worker(const char *path,UserImage *im,int width,int height,
                             size_t rows,int cycles,int start_row){
 if(start_row<1||!isatty(STDOUT_FILENO))return;
 char *tty=ttyname(STDOUT_FILENO);if(!tty)return;
 char tty_path[256];snprintf(tty_path,sizeof tty_path,"%s",tty);
 pid_t shell=getppid();fflush(stdout);
 pid_t child=fork();if(child!=0)return;
 if(setsid()<0)_exit(0);
 int fd=open(tty_path,O_WRONLY|O_NOCTTY|O_CLOEXEC);
 if(fd<0)_exit(0);
 dup2(fd,STDOUT_FILENO);if(fd!=STDOUT_FILENO)close(fd);
 close(STDIN_FILENO);close(STDERR_FILENO);
 signal(SIGINT,SIG_IGN);signal(SIGHUP,SIG_DFL);signal(SIGPIPE,SIG_DFL);
 /* Monitor the original shell in a separate watchdog process. */
 pid_t watcher=fork();
 if(watcher==0){
  for(;;){struct timespec t={1,0};nanosleep(&t,NULL);
   if(kill(shell,0)<0&&errno==ESRCH){kill(getppid(),SIGTERM);_exit(0);}
  }
 }
 if(watcher<0)_exit(0);
 /* Unbuffered output prevents stale frame data in a forked stdio buffer. */
 setvbuf(stdout,NULL,_IONBF,0);
 gif_animate(path,im,width,height,rows,cycles,start_row);
 kill(watcher,SIGTERM);
 _exit(0);
}

typedef struct {const char *name,*color;int height;const char *rows[8];} DistroLogo;
static const DistroLogo distro_logos[]={
 {"arch","#1793d1",7,{"       /\\       ","      /  \\      ","     /\\   \\     ","    /      \\    ","   /   ,,   \\   ","  /   |  |  -\\  "," /_-''    ''-_\\ "}},
 {"debian","#d70a53",7,{"    _____     ","   /  __ \\    ","  |  /    |   ","  |  \\___-    ","  -_          ","    --_       ",""}},
 {"ubuntu","#e95420",7,{"    .--.     ","  /  __  \\   "," |  (  )  |  ","  \\  --  /   ","    '--'     ","",""}},
 {"fedora","#51a2da",7,{"   ______    ","  / ____ \\   "," | |  __| |  "," | | |__  |  "," |  \\___| |  ","  \\______/   ",""}},
 {"manjaro","#35bf5c",7,{" |\\  | | | | "," | \\ | | | | "," |  \\| | | | "," | | | | | | "," |_| |_| |_| ","",""}},
 {"linuxmint","#87cf3e",7,{"  __________  "," /  ______  \\ "," | |  __  | | "," | | |  | | | "," | |_|  |_| | "," \\__________/ ",""}},
 {"opensuse","#73ba25",7,{"    _______   ","  /  ___  \\  "," /  /   \\  \\ "," | |  () | | "," \\  \\___/  / ","  \\_______/  ",""}},
 {"gentoo","#b7a2d3",7,{"   ______    ","  /  __  \\   "," /  /  \\  \\  "," | |   /  /  "," \\  \\__/  /  ","  \\______/   ",""}},
 {"alpine","#0d597f",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / /  \\ \\   ","  /_/    \\_\\  ","",""}},
 {"nixos","#7ebae4",7,{"  \\  /\\  /   ","   \\/  \\/    ","  /\\  /\\    "," /  \\/  \\   "," \\  /\\  /   ","  \\/  \\/    ",""}},
 {"android","#3ddc84",7,{"   /\\    /\\  ","  /  \\__/  \\ "," |  o    o | "," |          | "," |__________| ","  |  |  |  | ",""}},
 {"termux","#80cbc4",7,{"  __________ "," | >_       |"," |          |"," |__________|","","",""}},
 {"void","#478061",7,{"    ______    ","   / ____ \\   ","  | |    | |  ","  | |____| |  ","   \\______/   ","",""}},
 {"artix","#10a0cc",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / ____ \\   ","  /_/    \\_\\  ","",""}},
 {"endeavouros","#7f3fbf",7,{"       /\\     ","      /  \\    ","     / /\\ \\   ","    / /  \\ \\  ","   /_/____\\_\\ ","",""}},
 {"kali","#557c94",7,{"   __       ","  /  \\___   "," /  / __ \\  "," |  \\___/ / ","  \\______/  ","",""}},
 {"raspbian","#c51a4a",7,{"   .-''-.   ","  / .--. \\  "," | (____) | ","  \\ (__) /  ","   '----'   ","",""}},
 {"slackware","#526db0",7,{"   _______   ","  |   S   |  ","  |_______|  ","","","",""}},
 {"redhat","#ee0000",7,{"   _______   ","  /       \\  "," |  REDHAT  | ","  \\_______/  ","","",""}},
 {"popos","#48b9c7",7,{"  __________ "," |  POP!_   |"," |__________|","","","",""}},
};
static const DistroLogo *find_logo(const char *name){
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)
  if(!strcmp(name,distro_logos[i].name))return &distro_logos[i];
 return NULL;
}
static int distro_width(const DistroLogo *logo){
 int width=0;for(int i=0;i<logo->height;i++){int n=(int)strlen(logo->rows[i]);if(n>width)width=n;}
 return width;
}
static void distro_row(const DistroLogo *logo,int row,int width){
 unsigned int r=255,g=255,b=255;
 sscanf(logo->color+1,"%2x%2x%2x",&r,&g,&b);
 const char *line=logo->rows[row];int n=(int)strlen(line);
 if(output_color)printf("\033[1;38;2;%u;%u;%um",r,g,b);
 for(int i=0;i<width;i++)putchar(i<n?line[i]:' ');
 if(output_color)fputs(R,stdout);
}
static void list_logos(void){
 puts("tux (default)");
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)puts(distro_logos[i].name);
}

/* User-supplied logo artwork, same 58x72 pixel canvas as the default Tux. */
static const unsigned char *distro_pixels(const char *name){
 if(!strcmp(name,"arch"))return logo_arch;
 if(!strcmp(name,"debian"))return logo_debian;
 if(!strcmp(name,"fedora"))return logo_fedora;
 if(!strcmp(name,"popos"))return logo_popos;
 if(!strcmp(name,"kali"))return logo_kali;
 if(!strcmp(name,"linuxmint"))return logo_linuxmint;
 if(!strcmp(name,"redhat"))return logo_redhat;
 if(!strcmp(name,"gentoo"))return logo_gentoo;
 if(!strcmp(name,"opensuse"))return logo_opensuse;
 if(!strcmp(name,"slackware"))return logo_slackware;
 if(!strcmp(name,"alpine"))return logo_alpine;
 if(!strcmp(name,"void"))return logo_void;
 if(!strcmp(name,"manjaro"))return logo_manjaro;
 if(!strcmp(name,"nixos"))return logo_nixos;
 if(!strcmp(name,"android"))return logo_android;

 return NULL;
}
/* Truecolor upper/lower half-block renderer; alpha zero uses terminal default
   background, so the logo has no ugly opaque rectangle. */
static void pixel_logo_bounds(const unsigned char *img,int *top,int *bottom){
 int first=DISTRO_H,last=-1;
 for(int y=0;y<DISTRO_H;y++)
  for(int x=0;x<DISTRO_W;x++)
   if(img[(y*DISTRO_W+x)*4+3]>=96){
    if(y<first)first=y;
    if(y>last)last=y;
   }
 if(last<first){first=0;last=DISTRO_H-1;}
 *top=first;*bottom=last+1;
}
static void pixel_logo_row(const unsigned char *img,size_t row,int width,int height,int crop_top,int crop_bottom){
 for(int x=0;x<width;x++){
  /* Premultiplied bilinear sampling keeps colored logos sharp without the
     white halo produced by interpolating transparent RGB directly. */
  unsigned char color[2][4],mixed[2][4];
  double sx=((double)x+0.5)*DISTRO_W/width-0.5;
  int x0=(int)floor(sx);double fx=sx-x0;
  if(x0<0){x0=0;fx=0;}if(x0>=DISTRO_W-1){x0=DISTRO_W-1;fx=0;}
  int x1=x0+1<DISTRO_W?x0+1:x0;
  for(int k=0;k<2;k++){
   double sy=crop_top+((double)(2*row)+0.5+k)*(crop_bottom-crop_top)/(2.0*height)-0.5;
   int y0=(int)floor(sy);double fy=sy-y0;
   if(y0<0){y0=0;fy=0;}if(y0>=DISTRO_H-1){y0=DISTRO_H-1;fy=0;}
   int y1=y0+1<DISTRO_H?y0+1:y0;
   const unsigned char *p[4]={img+((size_t)y0*DISTRO_W+x0)*4,img+((size_t)y0*DISTRO_W+x1)*4,
    img+((size_t)y1*DISTRO_W+x0)*4,img+((size_t)y1*DISTRO_W+x1)*4};
   double weights[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double alpha=0,r=0,g=0,b=0;
   for(int j=0;j<4;j++){double a=weights[j]*p[j][3];alpha+=a;r+=a*p[j][0];g+=a*p[j][1];b+=a*p[j][2];}
   color[k][3]=(unsigned char)lround(alpha);
   color[k][0]=alpha>0?(unsigned char)lround(r/alpha):0;
   color[k][1]=alpha>0?(unsigned char)lround(g/alpha):0;
   color[k][2]=alpha>0?(unsigned char)lround(b/alpha):0;
   tux_pixel_mix(color[k],mixed[k]);
  }
  pixel_pair(mixed[0],mixed[1],color[0][3]>=26,color[1][3]>=26);
 }
 if(output_color)fputs(R,stdout);
}

/* Small JSONC reader: strings, booleans, numbers, arrays, objects, comments.
   Unknown keys are ignored; invalid config is reported, never executed. */
typedef struct {const char *p;int error;} Json;
static void jspace(Json *j){
 for(;;){while(isspace((unsigned char)*j->p))j->p++;
  if(j->p[0]=='/'&&j->p[1]=='/'){j->p+=2;while(*j->p&&*j->p!='\n')j->p++;continue;}
  if(j->p[0]=='/'&&j->p[1]=='*'){j->p+=2;while(*j->p&&!(j->p[0]=='*'&&j->p[1]=='/'))j->p++;if(*j->p)j->p+=2;else j->error=1;continue;}
  break;
 }
}
static int jstring(Json *j,char *out,size_t cap){
 jspace(j);if(*j->p!='"'){j->error=1;return 0;}j->p++;
 size_t n=0;
 while(*j->p&&*j->p!='"'){
  unsigned char c=(unsigned char)*j->p++;
  if(c=='\\'){c=(unsigned char)*j->p++;if(!c){j->error=1;return 0;}
   if(c=='n')c='\n';else if(c=='t')c='\t';else if(c=='r')c='\r';
   else if(c=='u'){/* Reject control escapes before accepting a label. */
    unsigned codepoint=0;
    for(int k=0;k<4;k++){
     unsigned char h=(unsigned char)*j->p;
     if(!isxdigit(h)){j->error=1;return 0;}
     codepoint=(codepoint<<4)+(unsigned)(h>='0'&&h<='9'?h-'0':(h>='a'&&h<='f'?h-'a'+10:h-'A'+10));
     j->p++;
    }
    if(codepoint<32||codepoint==127){j->error=1;return 0;}
    c='?';
   }
  }
  if(n+1<cap)out[n++]=(char)c;else j->error=1;
 }
 if(*j->p!='"'){j->error=1;return 0;}j->p++;if(cap)out[n]=0;return !j->error;
}
static void jskip(Json *j,int depth){
 if(depth>32){j->error=1;return;}jspace(j);
 if(*j->p=='"'){char v[512];jstring(j,v,sizeof v);return;}
 if(*j->p=='{'||*j->p=='['){
  char end=*j->p++=='{'?'}':']';jspace(j);
  while(*j->p&&*j->p!=end&&!j->error){
   if(*j->p==','||*j->p==':'){j->p++;continue;}
   jskip(j,depth+1);jspace(j);
  }
  if(*j->p==end)j->p++;else j->error=1;return;
 }
 if(!*j->p){j->error=1;return;}
 while(*j->p&&!isspace((unsigned char)*j->p)&&*j->p!=','&&*j->p!=']'&&*j->p!='}')j->p++;
}
static int jkey(Json *j,char *key,size_t cap){
 jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}
 if(*j->p==','){j->p++;jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}}
 jstring(j,key,cap);jspace(j);if(*j->p==':')j->p++;else j->error=1;
 return !j->error;
}
static char cfg_order[8192]="";
static char cfg_hidden[8192]="";
static char cfg_preset_name[24]="";
static int cfg_output_json=0;
/* Full is the compatibility default; fast counts all Pacman local entries. */
static int cfg_packages_fast=0;
static char cfg_logo_type[64]="tux";
static char cfg_image_path[1024]="";
static int cfg_logo=1,cfg_palette=1,cfg_auto=1,cfg_logo_width=0,cfg_gap=2;
static int cfg_label_width=16,cfg_palette_indent=10,cfg_key_bold=1,cfg_val_bold=1;
/* A 100% default preserves exact RGB values and the existing look. */
static int cfg_theme_brightness=100;
static int cfg_key[3]={255,218,120},cfg_val[3]={255,255,255};
static int cfg_title[3]={255,218,120},cfg_separator[3]={198,214,230};
static int cfg_user_key[3],cfg_user_val[3],cfg_user_title[3],cfg_user_separator[3];
static int cfg_has_key=0,cfg_has_val=0,cfg_has_title=0,cfg_has_separator=0;
static char cfg_theme[16]="vivid";
typedef struct {
 char name[64],label[96];
 int key_color[3],val_color[3],has_key,has_val;
} NisModuleStyle;
static NisModuleStyle cfg_styles[128];
static size_t cfg_styles_count=0;
static int cfg_color(const char *v,int rgb[3]){
 if(strlen(v)!=7||v[0]!='#')return 0;
 for(int i=1;i<7;i++)if(!isxdigit((unsigned char)v[i]))return 0;
 unsigned int a,b,c;
 if(sscanf(v+1,"%2x%2x%2x",&a,&b,&c)!=3)return 0;
 rgb[0]=(int)a;rgb[1]=(int)b;rgb[2]=(int)c;
 return 1;
}
static int cfg_bool(const char *v,int *result){
 if(!strcmp(v,"true")){*result=1;return 1;}
 if(!strcmp(v,"false")){*result=0;return 1;}
 return 0;
}
static int cfg_int(const char *v,int *result,int min,int max){
 if(!*v)return 0;
 errno=0;char *end=NULL;long n=strtol(v,&end,10);
 if(errno||end==v||*end||n<min||n>max)return 0;
 *result=(int)n;return 1;
}
static void cfg_copy_rgb(int dst[3],const int src[3]){
 for(int i=0;i<3;i++)dst[i]=src[i];
}
/* Brightness is a text-palette transform applied at render time. That also
   includes per-module RGB overrides without modifying the saved config:
   <100 blends toward black; >100 blends toward white. Integer-only hot path. */
static void cfg_brighten_rgb(const int src[3],int dst[3]){
 const int percentage=cfg_theme_brightness;
 if(percentage==100){cfg_copy_rgb(dst,src);return;}
 for(int i=0;i<3;i++){
  int component=src[i];
  if(percentage<100)dst[i]=(component*percentage+50)/100;
  else dst[i]=component+((255-component)*(percentage-100)+50)/100;
 }
}
/* The title is an accent of the *current theme*, not a separate fixed-yellow
   line. The same rule must hold for both JSONC and an explicit --theme. */
static const char *cfg_normalize_theme(const char *name){
 if(!strcmp(name,"bright"))return "vivid";
 return name;
}
static int cfg_known_theme(const char *name){
 name=cfg_normalize_theme(name);
 return !strcmp(name,"vivid")||!strcmp(name,"soft")||
        !strcmp(name,"mono")||!strcmp(name,"classic")||
        !strcmp(name,"ice")||!strcmp(name,"forest")||
        !strcmp(name,"rose");
}
static void cfg_apply_theme(void){
 const char *theme=cfg_normalize_theme(cfg_theme);
 if(!strcmp(theme,"soft")){
  const int key[]={219,190,143},val[]={232,237,245},sep[]={145,164,186};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else if(!strcmp(theme,"mono")){
  const int key[]={232,238,246},val[]={255,255,255},sep[]={195,204,214};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else if(!strcmp(theme,"ice")){
  const int key[]={120,211,255},val[]={252,254,255},sep[]={132,182,212};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else if(!strcmp(theme,"forest")){
  const int key[]={143,238,168},val[]={250,255,251},sep[]={132,194,158};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else if(!strcmp(theme,"rose")){
  const int key[]={255,167,203},val[]={255,251,254},sep[]={202,144,181};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else if(!strcmp(theme,"classic")){
  const int key[]={255,211,110},val[]={235,241,245},sep[]={195,204,214};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }else{
  const int key[]={255,218,120},val[]={255,255,255},sep[]={198,214,230};
  cfg_copy_rgb(cfg_key,key);cfg_copy_rgb(cfg_val,val);
  cfg_copy_rgb(cfg_separator,sep);
 }
 if(cfg_has_key)cfg_copy_rgb(cfg_key,cfg_user_key);
 if(cfg_has_val)cfg_copy_rgb(cfg_val,cfg_user_val);
 cfg_copy_rgb(cfg_title,cfg_key);
 if(cfg_has_title)cfg_copy_rgb(cfg_title,cfg_user_title);
 if(cfg_has_separator)cfg_copy_rgb(cfg_separator,cfg_user_separator);
}
static int cfg_safe_text(const char *s){
 if(!*s)return 0;
 for(const unsigned char *p=(const unsigned char *)s;*p;p++)
  if(*p<32||*p==127)return 0;
 return 1;
}
static NisModuleStyle *cfg_style(const char *name,int create){
 for(size_t i=0;i<cfg_styles_count;i++)
  if(!strcmp(cfg_styles[i].name,name))return &cfg_styles[i];
 if(!create||cfg_styles_count>=sizeof cfg_styles/sizeof cfg_styles[0])return NULL;
 NisModuleStyle *style=&cfg_styles[cfg_styles_count++];
 snprintf(style->name,sizeof style->name,"%s",name);
 return style;
}
static void cfg_module_map(Json *j,const char *map){
 jspace(j);if(*j->p!='{'){j->error=1;return;}j->p++;
 char key[64],value[128];
 while(jkey(j,key,sizeof key)&&!j->error){
  if(!cfg_safe_text(key)||strlen(key)>=64){j->error=1;break;}
  if(!jstring(j,value,sizeof value)||!cfg_safe_text(value)){j->error=1;break;}
  NisModuleStyle *style=cfg_style(key,1);if(!style){j->error=1;break;}
  if(!strcmp(map,"moduleLabels")){
   if(strlen(value)>=sizeof style->label){j->error=1;break;}
   snprintf(style->label,sizeof style->label,"%s",value);
  }else if(!strcmp(map,"moduleColors")){
   if(!cfg_color(value,style->key_color)){j->error=1;break;}
   style->has_key=1;
  }else if(!strcmp(map,"moduleValueColors")){
   if(!cfg_color(value,style->val_color)){j->error=1;break;}
   style->has_val=1;
  }
 }
}
static void cfg_value(Json *j,char *v,size_t cap){
 jspace(j);if(*j->p=='"')jstring(j,v,cap);
 else {size_t n=0;while(*j->p&&*j->p!=','&&*j->p!='}'&&*j->p!=']'&&!isspace((unsigned char)*j->p)){
 if(n+1<cap)v[n++]=*j->p;else j->error=1;
 j->p++;
 }v[n]=0;}
}
/* Explicit presets never alter the default KDE/Termux adaptive selection.
   The full preset is expanded later to include dynamically registered groups. */
static const char *cfg_preset_modules(const char *name){
 if(!strcmp(name,"auto"))return NULL;
 if(!strcmp(name,"compact"))return "title:separator:os:kernel:uptime:packages:cpu:gpu:memory:disk:locale";
 if(!strcmp(name,"balanced"))return "title:separator:os:host:kernel:uptime:packages:display:desktop:wm:cpu:cpucores:processes:gpu:memory:swap:disk:homedisk:locale:load1";
 if(!strcmp(name,"hardware"))return "title:separator:os:host:board:bios:kernel:cpu:cpucores:cpufreq:gpudriver:gpu:gpuvendor:gpuvram:memory:ramtype:ramfrequency:rammodules:ramslots:disk:diskdevice:diskfilesystem:homedisk:homefilesystem:load1";
 if(!strcmp(name,"network"))return "title:separator:os:hostname:network:interfaces:ipv4:ipv6:gateway:dns";
 if(!strcmp(name,"phone"))return "title:separator:os:host:kernel:uptime:packages:androidbrand:androidmanufacturer:androidmodel:androidsoc:androidversion:androidsdk:androidsecuritypatch:battery:batteryhealth:batterycycles:brightness:memory:disk:locale";
 if(!strcmp(name,"full"))return "@full";
 return NULL;
}
static int cfg_preset_valid(const char *name){
 return !strcmp(name,"auto")||cfg_preset_modules(name)!=NULL;
}
static void cfg_section(Json *j,const char *section){
 jspace(j);if(*j->p!='{'){j->error=1;return;}j->p++;
 char key[128],val[1024];
 while(jkey(j,key,sizeof key)&&!j->error){
  if(*j->p=='{'||*j->p=='['){jskip(j,0);continue;}
  cfg_value(j,val,sizeof val);
  if(!strcmp(section,"logo")){
   if(!strcmp(key,"enabled")){if(!cfg_bool(val,&cfg_logo))j->error=1;}
   else if(!strcmp(key,"autoScale")){if(!cfg_bool(val,&cfg_auto))j->error=1;}
   else if(!strcmp(key,"width")){if(!cfg_int(val,&cfg_logo_width,0,TUX_W))j->error=1;}
   else if(!strcmp(key,"type"))snprintf(cfg_logo_type,sizeof cfg_logo_type,"%.63s",val);
   else if(!strcmp(key,"image"))snprintf(cfg_image_path,sizeof cfg_image_path,"%s",val);
  }else if(!strcmp(section,"display")){
   if(!strcmp(key,"palette")){if(!cfg_bool(val,&cfg_palette))j->error=1;}
   else if(!strcmp(key,"gap")){if(!cfg_int(val,&cfg_gap,0,12))j->error=1;}
   else if(!strcmp(key,"labelWidth")){if(!cfg_int(val,&cfg_label_width,8,32))j->error=1;}
   else if(!strcmp(key,"paletteIndent")){if(!cfg_int(val,&cfg_palette_indent,0,32))j->error=1;}
   else if(!strcmp(key,"themeBrightness")){if(!cfg_int(val,&cfg_theme_brightness,20,180))j->error=1;}
   else if(!strcmp(key,"keyBold")){if(!cfg_bool(val,&cfg_key_bold))j->error=1;}
   else if(!strcmp(key,"valueBold")){if(!cfg_bool(val,&cfg_val_bold))j->error=1;}
   else if(!strcmp(key,"format")){
    if(!strcmp(val,"json"))cfg_output_json=1;
    else if(!strcmp(val,"text"))cfg_output_json=0;
    else j->error=1;
   }
   else if(!strcmp(key,"theme")){
    if(!cfg_known_theme(val))j->error=1;
    else snprintf(cfg_theme,sizeof cfg_theme,"%.15s",val);
   }
   else if(!strcmp(key,"keyColor")){
    if(!cfg_color(val,cfg_user_key))j->error=1;else cfg_has_key=1;
   }
   else if(!strcmp(key,"valueColor")){
    if(!cfg_color(val,cfg_user_val))j->error=1;else cfg_has_val=1;
   }
   else if(!strcmp(key,"titleColor")){
    if(!cfg_color(val,cfg_user_title))j->error=1;else cfg_has_title=1;
   }
   else if(!strcmp(key,"separatorColor")){
    if(!cfg_color(val,cfg_user_separator))j->error=1;else cfg_has_separator=1;
   }
  }
 }
}
static void cfg_module_list(Json *j,char *target,size_t cap){
 if(*j->p!='['){j->error=1;return;}j->p++;
 target[0]=0;
 while(!j->error){
  jspace(j);if(*j->p==']'){j->p++;break;}
  if(*j->p==','){j->p++;continue;}
  char name[128];if(!jstring(j,name,sizeof name))break;
  if(!cfg_safe_text(name)){j->error=1;break;}
  size_t len=strlen(target),n=strlen(name);
  if(len+n+2>=cap){j->error=1;break;}
  if(len)strcat(target,":");
  strcat(target,name);
 }
}
static int cfg_parse(const char *source){
 Json j={source,0};jspace(&j);if(*j.p!='{')return 0;j.p++;
 char key[128];
 while(jkey(&j,key,sizeof key)&&!j.error){
  jspace(&j);
  if(!strcmp(key,"logo")||!strcmp(key,"display"))cfg_section(&j,key);
  else if(!strcmp(key,"modules"))cfg_module_list(&j,cfg_order,sizeof cfg_order);
  else if(!strcmp(key,"preset")){
   char preset[64];if(!jstring(&j,preset,sizeof preset)||!cfg_preset_valid(preset))j.error=1;
   else snprintf(cfg_preset_name,sizeof cfg_preset_name,"%.23s",preset);
  }
  else if(!strcmp(key,"packagesMode")){
   char mode[16];if(!jstring(&j,mode,sizeof mode))j.error=1;
   else if(!strcmp(mode,"fast"))cfg_packages_fast=1;
   else if(!strcmp(mode,"full"))cfg_packages_fast=0;
   else j.error=1;
  }
  else if(!strcmp(key,"hiddenModules"))cfg_module_list(&j,cfg_hidden,sizeof cfg_hidden);
  else if(!strcmp(key,"moduleLabels")||!strcmp(key,"moduleColors")||!strcmp(key,"moduleValueColors"))
   cfg_module_map(&j,key);
  else jskip(&j,0);
 }
 jspace(&j);
 if(!j.error&&!*j.p)cfg_apply_theme();
 return !j.error&&!*j.p;
}
static int cfg_load(const char *path,int required){
 FILE *f=fopen(path,"rb");if(!f){if(required)fprintf(stderr,"Cannot open config: %s\n",path);return !required;}
 if(fseek(f,0,SEEK_END)){fclose(f);return 0;}
 long n=ftell(f);rewind(f);
 if(n<0||n>262144){fprintf(stderr,"Config too large: %s\n",path);fclose(f);return 0;}
 char *buf=malloc((size_t)n+1);if(!buf){fclose(f);return 0;}
 size_t got=fread(buf,1,(size_t)n,f);fclose(f);buf[got]=0;
 int ok=got==(size_t)n&&cfg_parse(buf);free(buf);
 if(!ok)fprintf(stderr,"Invalid JSONC config: %s\n",path);
 return ok;
}
static const char nis_config_example[]=
 "{\n"
 "  // NISFETCH 3.9.0: portable Linux/Termux collectors, themes and JSON.\n"
 "  // Optional: \"preset\": \"balanced\", // auto, compact, balanced, hardware, network, phone, full\n"
 "  \"packagesMode\": \"full\", // fast = total Pacman packages, full = native + AUR/foreign\n"
 "  \"logo\": {\"type\": \"tux\", \"image\": \"\", \"enabled\": true, \"autoScale\": true, \"width\": 0},\n"
 "  \"display\": {\n"
 "    \"theme\": \"vivid\", \"format\": \"text\", \"gap\": 2, \"palette\": true,\n"
 "    \"labelWidth\": 16, \"paletteIndent\": 10,\n"
 "    \"themeBrightness\": 100, // 20..180 percent; 100 preserves original RGB.\n"
 "    \"keyBold\": true, \"valueBold\": true\n"
 "    // Optional exact colors: \"keyColor\", \"valueColor\", \"titleColor\", \"separatorColor\".\n"
 "  },\n"
 "  \"moduleLabels\": {}, // Example: \"cpu\": \"Processor\", \"memory\": \"RAM\"\n"
 "  \"moduleColors\": {}, // Example: \"cpu\": \"#ffa500\"\n"
 "  \"moduleValueColors\": {}, // Example: \"gpu\": \"#ffffff\"\n"
 "  \"hiddenModules\": [] // Example: \"wmtheme\", \"plasmatheme\"\n"
 "  // Optional fixed order: \"modules\": [\"title\", \"separator\", \"os\", \"cpu\", \"memory\"]\n"
 "}\n";
static int cfg_default_path(char *out,size_t cap){
 const char *xdg=getenv("XDG_CONFIG_HOME"),*home=getenv("HOME");
 if(xdg&&*xdg)return snprintf(out,cap,"%s/nisfetch/config.jsonc",xdg)<(int)cap;
 if(home&&*home)return snprintf(out,cap,"%s/.config/nisfetch/config.jsonc",home)<(int)cap;
 return 0;
}
static int cfg_ensure_directory(const char *path){
 if(mkdir(path,0700)!=0&&errno!=EEXIST)return 0;
 struct stat st;return stat(path,&st)==0&&S_ISDIR(st.st_mode);
}
static int cfg_init_file(void){
 char path[PATH_MAX];
 if(!cfg_default_path(path,sizeof path)){fputs("Cannot resolve config path (set HOME or XDG_CONFIG_HOME)\n",stderr);return 2;}
 char base[PATH_MAX];snprintf(base,sizeof base,"%s",path);
 char *slash=strrchr(base,'/');if(!slash)return 2;
 *slash=0;
 char parent[PATH_MAX];snprintf(parent,sizeof parent,"%s",base);
 char *parentslash=strrchr(parent,'/');if(!parentslash)return 2;
 *parentslash=0;
 if(!cfg_ensure_directory(parent)||!cfg_ensure_directory(base)){
  fprintf(stderr,"Cannot create config directory: %s\n",base);return 2;
 }
 int flags=O_WRONLY|O_CREAT|O_EXCL;
#ifdef O_NOFOLLOW
 flags|=O_NOFOLLOW;
#endif
 int fd=open(path,flags,0600);
 if(fd<0){
  fprintf(stderr,"Config not created (%s): %s\n",strerror(errno),path);return 2;
 }
 const char *p=nis_config_example;size_t left=strlen(p);int ok=1;
 while(left){
  ssize_t n=write(fd,p,left);
  if(n<0&&errno==EINTR)continue;
  if(n<=0){ok=0;break;}
  p+=n;left-=(size_t)n;
 }
 if(close(fd)!=0)ok=0;
 if(!ok){unlink(path);fprintf(stderr,"Could not finish config: %s\n",path);return 2;}
 printf("Created: %s\n",path);
 return 0;
}
static char info[MAX_ROWS][512];
static int ninfo=0;
static char info_id[MAX_ROWS][64];
/* Populated only when JSON is explicitly requested. Render remains unchanged
   for ordinary fetches, and JSON never has to parse formatted ANSI text. */
static char info_value[MAX_ROWS][512];
#define LABEL_WIDTH cfg_label_width

static const char *selected_modules=NULL;
static int cli_modules_explicit=0;
static int is_termux(void);
/* The default Termux preset hides desktop-only fields. Explicit --modules,
   --all and config module selections always retain full control. */
static int android_default_hidden(const char *name){
 static const char *const hidden[]={
  "display","desktop","wm","wmtheme","theme","plasmatheme",
  "icons","font","cursor","gpu"
 };
 if(!is_termux())return 0;
 for(size_t i=0;i<sizeof hidden/sizeof hidden[0];i++)
  if(!strcmp(name,hidden[i]))return 1;
 return 0;
}
static int cfg_name_in_list(const char *list,const char *name){
 const char *p=list;size_t n=strlen(name);
 while(*p){
  while(*p==':'||*p==' '||*p=='\n')p++;
  if(!strncmp(p,name,n)&&(p[n]==':'||p[n]==0||p[n]==' '||p[n]=='\n'))return 1;
  while(*p&&*p!=':'&&*p!='\n')p++;
 }
 return 0;
}
static int module_enabled(const char *name){
 if(!cli_modules_explicit&&cfg_name_in_list(cfg_hidden,name))return 0;
 if(!selected_modules)return !android_default_hidden(name);
 return cfg_name_in_list(selected_modules,name);
}
static const char *all_modules="title:separator:os:host:kernel:uptime:packages:display:desktop:wm:wmtheme:theme:plasmatheme:icons:font:cursor:session:terminal:cpu:gpu:memory:swap:disk:homedisk:localip:locale:board:bios:chassis:shell:processes:loadavg:load1:load5:load15:datetime:timezone:hostname:architecture:cpucores:cpufreq:battery:brightness:bluetooth:network:diskusage:diskfilesystem:termux:androidversion:androidsdk:androidmanufacturer:androidmodel:androidsoc:bootid:virtualization:editor:users:language:distro:osversion:kernelversion:kernelarch:machineid:cpuvendor:cpumodel:cpubogomips:cpuload:memtotal:memavailable:swaptotal:swapfree:diskfree:disktotal:diskpercent:rootfs:mounts:interfaces:ipv4:ipv6:gateway:dns:username:uid:gid:home:path:shellversion:terminaltype:displayserver:sessiondesktop:xdgconfig:xdgcache:xdgdata:pid:parentpid:threads:systemd:init:cgroup:entropy:thermalzones:fans:batterycount:powerstate:androiddevice:androidboard:androidfingerprint:androidsecuritypatch:termuxprefix:termuxhome:timezoneoffset:epoch:week:dayofyear:bootdate:procversion:filesystems:environment:cpuonline:cpuconfigured:procsrunning:procstotal:memused:mempercent:diskavailable:uptimeseconds:bootepoch:loadtasks:kernelhostname:systemhz:gpuusage:gpuvram:gpumemoryused:cpugovernor:cpufreqmin:cpufreqmax:memcached:batteryhealth:androidbrand:androidhardware:gpudriver:gpuvendor:cpul3:memorypressure:batterycycles:biosdate";
static const char *module_names[]={"title","separator","os","host","kernel","uptime","packages","display","desktop","wm","wmtheme","theme","plasmatheme","icons","font","cursor","session","terminal","cpu","gpu","memory","swap","disk","homedisk","localip","locale","board","bios","chassis","shell","processes","loadavg","load1","load5","load15","datetime","timezone","hostname","architecture","cpucores","cpufreq","battery","brightness","bluetooth","network","diskusage","diskfilesystem","termux","androidversion","androidsdk","androidmanufacturer","androidmodel","androidsoc","bootid","virtualization","editor","users","language","distro","osversion","kernelversion","kernelarch","machineid","cpuvendor","cpumodel","cpubogomips","cpuload","memtotal","memavailable","swaptotal","swapfree","diskfree","disktotal","diskpercent","rootfs","mounts","interfaces","ipv4","ipv6","gateway","dns","username","uid","gid","home","path","shellversion","terminaltype","displayserver","sessiondesktop","xdgconfig","xdgcache","xdgdata","pid","parentpid","threads","systemd","init","cgroup","entropy","thermalzones","fans","batterycount","powerstate","androiddevice","androidboard","androidfingerprint","androidsecuritypatch","termuxprefix","termuxhome","timezoneoffset","epoch","week","dayofyear","bootdate","procversion","filesystems","environment","cpuonline","cpuconfigured","procsrunning","procstotal","memused","mempercent","diskavailable","uptimeseconds","bootepoch","loadtasks","kernelhostname","systemhz","gpuusage","gpuvram","gpumemoryused","cpugovernor","cpufreqmin","cpufreqmax","memcached","batteryhealth","androidbrand","androidhardware","gpudriver","gpuvendor","cpul3","memorypressure","batterycycles","biosdate"};
static const char *monitor_modules[]={"monitor","refreshrate","displayconnector","displaysize","monitorcount"};
static const char *hardware_modules[]={
 "ramtype","ramfrequency","ramslots","rammodules","rammanufacturer","rampart",
 "diskdevice","homedevice","homefilesystem","diskmountopts","diskinodes","homeinodes"
};
static int valid_modules(const char *list){
 char buf[8192];snprintf(buf,sizeof buf,"%s",list);
 for(char *p=strtok(buf,": \t\r\n");p;p=strtok(NULL,": \t\r\n")){
  int found=0;
  for(size_t i=0;i<sizeof module_names/sizeof module_names[0];i++)if(!strcmp(p,module_names[i])){found=1;break;}
  for(size_t i=0;i<sizeof monitor_modules/sizeof monitor_modules[0];i++)
   if(!strcmp(p,monitor_modules[i])){found=1;break;}
  for(size_t i=0;i<sizeof hardware_modules/sizeof hardware_modules[0];i++)
   if(!strcmp(p,hardware_modules[i])){found=1;break;}
  if(!found){fprintf(stderr,"Unknown module: %s\n",p);return 0;}
 }
 return 1;
}
static int nis_text_columns(const char *s){
 mbstate_t state={0};int columns=0;
 while(*s){
  wchar_t wc=0;size_t n=mbrtowc(&wc,s,MB_CUR_MAX,&state);
  if(n==(size_t)-1||n==(size_t)-2){memset(&state,0,sizeof state);s++;columns++;continue;}
  if(!n)break;
  int width=wcwidth(wc);columns+=width>0?width:0;s+=n;
 }
 return columns;
}
static void add(const char *name,const char *label,const char *value) {
 if(ninfo>=MAX_ROWS)return;
 const NisModuleStyle *style=cfg_style(name,0);
 char custom[112]="";
 if(*label&&style&&*style->label){
  snprintf(custom,sizeof custom,"%s",style->label);
  size_t len=strlen(custom);
  if(len&&custom[len-1]!=':'&&len+2<sizeof custom){custom[len]=':';custom[len+1]=0;}
  label=custom;
 }
 const int *key=style&&style->has_key?style->key_color:cfg_key;
 const int *val=style&&style->has_val?style->val_color:cfg_val;
 if(!strcmp(name,"title")&&!(style&&style->has_val))val=cfg_title;
 if(!strcmp(name,"separator")&&!(style&&style->has_val))val=cfg_separator;
 int adjusted_key[3],adjusted_val[3];
 if(output_color){
  cfg_brighten_rgb(key,adjusted_key);
  cfg_brighten_rgb(val,adjusted_val);
  key=adjusted_key;val=adjusted_val;
 }
 int width=nis_text_columns(label),pad=LABEL_WIDTH-width;
 if(!*label)pad=0;
 else if(pad<1)pad=1;
 char padded[200];snprintf(padded,sizeof padded,"%s%*s",label,pad,"");
 if(output_color)
  snprintf(info[ninfo],sizeof info[0],"\033[%s38;2;%d;%d;%dm%s" R "\033[%s38;2;%d;%d;%dm%s" R,
   cfg_key_bold?"1;":"",key[0],key[1],key[2],padded,
   cfg_val_bold?"1;":"",val[0],val[1],val[2],value&&*value?value:"Unknown");
 else snprintf(info[ninfo],sizeof info[0],"%s%s",padded,value&&*value?value:"Unknown");
 if(cfg_output_json)snprintf(info_value[ninfo],sizeof info_value[0],"%s",value&&*value?value:"Unknown");
 ninfo++;
}
static void add_module(const char *name,const char *label,const char *value){
 if(!module_enabled(name))return;
 /* Desktop defaults are adaptive; don't list KDE-only settings as N/A on
    GNOME, Sway, TTY, or unsupported hosts. Explicit requests remain visible. */
 if(!selected_modules && (!value||!*value||!strncmp(value,"Unavailable",11)) &&
    (!strcmp(name,"wmtheme")||!strcmp(name,"theme")||
     !strcmp(name,"plasmatheme")||!strcmp(name,"icons")||
     !strcmp(name,"font")||!strcmp(name,"cursor")||
     !strcmp(name,"wm")||!strcmp(name,"gpu")))return;
 int prev=ninfo;add(name,label,value);
 if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);
}
static void trim(char *s){size_t n=strlen(s);while(n&&(s[n-1]=='\n'||s[n-1]=='\r'||isspace((unsigned char)s[n-1])))s[--n]=0;}
static int is_termux(void){
 static int cached=-1;
 if(cached>=0)return cached;
 const char *p=getenv("PREFIX");
 const char *version=getenv("TERMUX_VERSION"),*app=getenv("TERMUX_APP__PACKAGE_NAME");
 cached=(p&&strstr(p,"com.termux")) || (version&&*version) ||
        (app&&strstr(app,"termux")) || access("/data/data/com.termux/files/usr",F_OK)==0;
 return cached;
}
#ifndef __ANDROID__
typedef struct {char key[96],value[384];} AndroidProp;
/* Some Linux-cross-built executables run in Termux without Bionic's property
   API. One getprop snapshot avoids spawning a shell for every requested field. */
static AndroidProp android_props[256];
static size_t android_prop_count=0;
static void load_android_properties(void){
 static int loaded=0;if(loaded)return;loaded=1;
 FILE *f=popen("getprop 2>/dev/null","r");if(!f)return;
 char line[768];
 /* Always drain the pipe, even after the bounded property table is full.
    Stopping reads early can deadlock pclose if getprop blocks on a full pipe. */
 while(fgets(line,sizeof line,f)){
  if(android_prop_count>=sizeof android_props/sizeof android_props[0])continue;
  char *start=strchr(line,'[');if(!start)continue;
  char *mid=strstr(start, "]: [");if(!mid)continue;
  char *end=strchr(mid+4,']');if(!end)continue;
  size_t keylen=(size_t)(mid-(start+1)),valuelen=(size_t)(end-(mid+4));
  if(keylen<3||strncmp(start+1,"ro.",3))continue;
  if(!keylen||keylen>=sizeof android_props[0].key||valuelen>=sizeof android_props[0].value)continue;
  AndroidProp *item=&android_props[android_prop_count++];
  memcpy(item->key,start+1,keylen);item->key[keylen]=0;
  memcpy(item->value,mid+4,valuelen);item->value[valuelen]=0;
 }
 pclose(f);
}
#endif
static void property(const char *key,char *out,size_t cap){
 out[0]=0;
 if(!is_termux())return;
#ifdef __ANDROID__
 /* Termux builds can query bionic properties in-process instead of spawning
    getprop once per Android module. */
 char value[PROP_VALUE_MAX];
 if(__system_property_get(key,value)>0){snprintf(out,cap,"%s",value);return;}
 /* A missing property is expected on many devices; no subprocess needed. */
#else
 load_android_properties();
 for(size_t i=0;i<android_prop_count;i++)if(!strcmp(key,android_props[i].key)){
  snprintf(out,cap,"%s",android_props[i].value);break;
 }
#endif
}
static void motherboard(char *out,size_t cap){
 if(is_termux()){
  char model[256]="",brand[128]="";
  property("ro.product.model",model,sizeof model);
  property("ro.product.manufacturer",brand,sizeof brand);
  if(*model){snprintf(out,cap,"%s%s%s",brand,(*brand&&!strstr(model,brand))?" ":"",model);return;}
  snprintf(out,cap,"Android device");return;
 }
 char board[256]="",vendor[256]="",product[256]="";
 FILE *f=fopen("/sys/class/dmi/id/board_name","r");
 if(f){if(fgets(board,sizeof board,f))trim(board);fclose(f);}
 f=fopen("/sys/class/dmi/id/board_vendor","r");
 if(f){if(fgets(vendor,sizeof vendor,f))trim(vendor);fclose(f);}
 if(!*board||!strcmp(board,"Default string")||!strcmp(board,"To be filled by O.E.M.")||!strcmp(board,"Not Specified")){
  f=fopen("/sys/class/dmi/id/product_name","r");
  if(f){if(fgets(product,sizeof product,f))trim(product);fclose(f);}
  if(*product)snprintf(board,sizeof board,"%s",product);
 }
 if(!*board){snprintf(out,cap,"Unknown motherboard");return;}
 if(*vendor && !strstr(board,vendor))snprintf(out,cap,"%s %s",vendor,board);
 else snprintf(out,cap,"%s",board);
}
/* freedesktop os-release may live in /etc or /usr/lib. Prefer PRETTY_NAME,
   but keep NAME and ID as safe fallbacks for minimal distros/containers. */
static int osrelease_name_from(const char *path,char *out,size_t cap){
 FILE *f=fopen(path,"r");if(!f)return 0;
 char line[1024],pretty[256]="",name[256]="",id[128]="";
 while(fgets(line,sizeof line,f)){
  char *target=NULL;size_t target_cap=0;char *value=NULL;
  if(!strncmp(line,"PRETTY_NAME=",12)){target=pretty;target_cap=sizeof pretty;value=line+12;}
  else if(!strncmp(line,"NAME=",5)){target=name;target_cap=sizeof name;value=line+5;}
  else if(!strncmp(line,"ID=",3)){target=id;target_cap=sizeof id;value=line+3;}
  if(!target)continue;
  trim(value);
  size_t n=strlen(value);
  if(n>=2&&(*value=='"'||*value=='\'' )&&value[n-1]==*value){value[n-1]=0;value++;}
  if(*value)snprintf(target,target_cap,"%s",value);
 }
 fclose(f);
 const char *best=*pretty?pretty:*name?name:id;
 if(!*best)return 0;
 snprintf(out,cap,"%s",best);return 1;
}
static void osname(char *out,size_t cap){
 if(is_termux()){
  char ver[80]="";property("ro.build.version.release",ver,sizeof ver);
  snprintf(out,cap,"Android%s%s (Termux)",*ver?" ":"",ver);return;
 }
 if(osrelease_name_from("/etc/os-release",out,cap))return;
 if(osrelease_name_from("/usr/lib/os-release",out,cap))return;
 snprintf(out,cap,"Linux");
}
static void cpuinfo(char *out,size_t cap){
 if(is_termux()){
  property("ro.soc.model",out,cap);
  if(!*out)property("ro.board.platform",out,cap);
  if(*out)return;
 }
 snprintf(out,cap,"Unknown");FILE *f=fopen("/proc/cpuinfo","r");if(!f)return;
 char line[512];while(fgets(line,sizeof line,f)){if(!strncmp(line,"model name",10)||!strncmp(line,"Hardware",8)){
 char *v=strchr(line,':');if(v){v++;while(isspace((unsigned char)*v))v++;trim(v);snprintf(out,cap,"%s",v);break;}}}fclose(f);
}

static unsigned long long read_khz(const char *path){
 int fd=open(path,O_RDONLY|O_CLOEXEC);
 if(fd<0)return 0;
 char text[48];ssize_t n=read(fd,text,sizeof text-1);
 close(fd);
 if(n<=0)return 0;
 text[n]=0;
 if(text[0]<'0'||text[0]>'9')return 0;
 errno=0;char *end=NULL;
 unsigned long long v=strtoull(text,&end,10);
 return errno==0&&end!=text?v:0;
}
static void cpu_max_frequency(char *cpu,size_t cap){
 unsigned long long best=0;
 DIR *d=opendir("/sys/devices/system/cpu/cpufreq");
 if(d){struct dirent *e;
  while((e=readdir(d))){
   if(strncmp(e->d_name,"policy",6))continue;
   char path[512];
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/cpuinfo_max_freq",e->d_name);
   unsigned long long v=read_khz(path);
   if(!v){snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/scaling_max_freq",e->d_name);v=read_khz(path);}
   if(v>best)best=v;
  }
  closedir(d);
 }
 if(!best)best=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
 if(!best)return;
 size_t n=strlen(cpu);
 if(n+24<cap)snprintf(cpu+n,cap-n," @ %.2f GHz",best/1000000.0);
}
static void terminal_name(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Termux");return;}
 /* TERM describes capabilities, not the terminal emulator. */
 const char *v=getenv("KITTY_WINDOW_ID");
 if(v&&*v){snprintf(out,cap,"kitty");return;}
 v=getenv("KONSOLE_VERSION");if(v&&*v){snprintf(out,cap,"Konsole");return;}
 v=getenv("WEZTERM_PANE");if(v&&*v){snprintf(out,cap,"WezTerm");return;}
 v=getenv("ALACRITTY_WINDOW_ID");if(v&&*v){snprintf(out,cap,"Alacritty");return;}
 v=getenv("GHOSTTY_RESOURCES_DIR");if(v&&*v){snprintf(out,cap,"Ghostty");return;}
 v=getenv("WT_SESSION");if(v&&*v){snprintf(out,cap,"Windows Terminal");return;}
 v=getenv("TERM_PROGRAM");
 if(v&&*v && strcmp(v,"vscode")!=0){snprintf(out,cap,"%s",v);return;}
 if(v&&strcmp(v,"vscode")==0){snprintf(out,cap,"VS Code");return;}
 /* Walk process ancestry: shell -> terminal (also works when env is absent). */
 pid_t pid=getppid();
 for(int i=0;i<12 && pid>1;i++){
  char path[96],comm[128]="",statline[2048];
  snprintf(path,sizeof path,"/proc/%ld/comm",(long)pid);
  FILE *f=fopen(path,"r");
  if(f){if(fgets(comm,sizeof comm,f))trim(comm);fclose(f);}
  const char *name=NULL;
  if(strstr(comm,"konsole"))name="Konsole";
  else if(strstr(comm,"kitty"))name="kitty";
  else if(strstr(comm,"alacritty"))name="Alacritty";
  else if(strstr(comm,"wezterm"))name="WezTerm";
  else if(strstr(comm,"gnome-terminal"))name="GNOME Terminal";
  else if(strstr(comm,"ghostty"))name="Ghostty";
  else if(strstr(comm,"xfce4-terminal"))name="Xfce Terminal";
  else if(strstr(comm,"foot"))name="foot";
  else if(strstr(comm,"tilix"))name="Tilix";
  else if(strstr(comm,"terminator"))name="Terminator";
  else if(strstr(comm,"xterm"))name="xterm";
  if(name){snprintf(out,cap,"%s",name);return;}
  snprintf(path,sizeof path,"/proc/%ld/stat",(long)pid);
  f=fopen(path,"r");if(!f)break;
  if(!fgets(statline,sizeof statline,f)){fclose(f);break;}fclose(f);
  char *p=strrchr(statline,')');if(!p)break;
  char state;long ppid=0;
  if(sscanf(p+1," %c %ld",&state,&ppid)!=2)break;
  if(ppid<=1||ppid==pid)break;
  pid=(pid_t)ppid;
 }
 const char *term=getenv("TERM");snprintf(out,cap,"%s",term&&*term?term:"Unknown");
}
static void meminfo_numbers(unsigned long long *total,unsigned long long *available);
static void meminfo(char *out,size_t cap){
 unsigned long long total=0,avail=0;
 meminfo_numbers(&total,&avail);
 if(total){
  double pct=100.0*(total-avail)/total;
  const char *color=pct<50.0?"\033[1;32m":pct<=75.0?"\033[1;33m":"\033[1;31m";
  snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%\033[0m)",
           (total-avail)/1048576.,total/1048576.,color,pct);
  return;
 }

 snprintf(out,cap,"Unavailable");
}
static int cache_read(const char *key,char *out,size_t cap,long ttl){
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[512],file[640];struct stat st;
 if(base&&*base)snprintf(dir,sizeof dir,"%s/nisfetch",base);
 else if(home&&*home)snprintf(dir,sizeof dir,"%s/.cache/nisfetch",home);
 else return 0;
 if(snprintf(file,sizeof file,"%s/%s",dir,key)>=(int)sizeof file)return 0;
 time_t now=time(NULL);
 if(stat(file,&st)||!S_ISREG(st.st_mode)||st.st_size<=0||
    (size_t)st.st_size>=cap||st.st_mtime>now||now-st.st_mtime>ttl)return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 int ok=fgets(out,(int)cap,f)!=NULL;fclose(f);
 if(ok)trim(out);
 return ok&&*out;
}
static void cache_write(const char *key,const char *value){
 if(!value||!*value)return;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[1024],file[1200],tmp[1240],parent[512];
 if(base&&*base)snprintf(parent,sizeof parent,"%s",base);
 else if(home&&*home)snprintf(parent,sizeof parent,"%s/.cache",home);
 else return;
 if(mkdir(parent,0700)&&errno!=EEXIST)return;
 if(snprintf(dir,sizeof dir,"%s/nisfetch",parent)>=(int)sizeof dir)return;
 if(mkdir(dir,0700)&&errno!=EEXIST)return;
 if(snprintf(file,sizeof file,"%s/%s",dir,key)>=(int)sizeof file)return;
 if(snprintf(tmp,sizeof tmp,"%s/.%s.XXXXXX",dir,key)>=(int)sizeof tmp)return;
 int fd=mkstemp(tmp);if(fd<0)return;
 size_t len=strlen(value);int ok=1;
 if(write(fd,value,len)!=(ssize_t)len||write(fd,"\n",1)!=1)ok=0;
 if(close(fd))ok=0;
 if(ok&&rename(tmp,file)==0)return; /* atomic, even across parallel shells */
 unlink(tmp);
}
static unsigned long count_lines(const char *cmd){
 FILE *f=popen(cmd,"r");unsigned long n=0;
 if(f){if(fscanf(f,"%lu",&n)!=1)n=0;pclose(f);}return n;
}
/* Count installed packages from their database directories without starting
   the package manager. Foreign classification uses optional runtime libalpm. */
static unsigned long count_subdirs_portable(const char *path){
 DIR *d=opendir(path);if(!d)return 0;
 unsigned long n=0;struct dirent *e;
 while((e=readdir(d))!=NULL){
  if(e->d_name[0]=='.')continue;
#ifdef DT_DIR
  /* pacman's local DB has thousands of entries: d_type avoids one stat(2)
     per package on ext4/btrfs. Unknown d_type still gets a safe stat. */
  if(e->d_type==DT_DIR){n++;continue;}
  if(e->d_type!=DT_UNKNOWN)continue;
#endif
  {
   char file[PATH_MAX];struct stat st;
   if(snprintf(file,sizeof file,"%s/%s",path,e->d_name)<(int)sizeof file &&
      stat(file,&st)==0 && S_ISDIR(st.st_mode))n++;
  }
 }
 closedir(d);return n;
}
/* Linux Pacman installs usually contain thousands of local package folders.
   A buffered getdents64 scan avoids per-entry libc readdir dispatch. This
   function retains fstatat for filesystems that do not report d_type and
   transparently falls back to readdir on an unsupported syscall/error. */
static unsigned long count_subdirs(const char *path){
#if defined(__linux__) && !defined(__ANDROID__) && defined(SYS_getdents64)
 struct nis_dirent64 {
  uint64_t ino;
  int64_t off;
  unsigned short reclen;
  unsigned char type;
  char name[];
 };
 int fd=open(path,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
 if(fd<0)return 0;
 unsigned long count=0;
 union {uint64_t align;char bytes[32768];} buffer;
 int valid=1;
 for(;;){
  long size=syscall(SYS_getdents64,fd,buffer.bytes,sizeof buffer.bytes);
  if(size==0)break;
  if(size<0){valid=0;break;}
  for(size_t off=0;off<(size_t)size;){
   struct nis_dirent64 *item=(struct nis_dirent64*)(buffer.bytes+off);
   size_t remain=(size_t)size-off;
   size_t min_entry=offsetof(struct nis_dirent64,name)+1;
   if(remain<min_entry || item->reclen<min_entry || item->reclen>remain){valid=0;break;}
   off+=item->reclen;
   if(item->name[0]=='.')continue;
   if(item->type==DT_DIR){count++;continue;}
   if(item->type==DT_UNKNOWN){
    struct stat st;
    if(fstatat(fd,item->name,&st,0)==0&&S_ISDIR(st.st_mode))count++;
   }
  }
  if(!valid)break;
 }
 close(fd);
 if(valid)return count;
#endif
 return count_subdirs_portable(path);
}
/* dpkg and Alpine apk both expose compact on-disk package status files.
   Reading them directly skips a shell, grep, wc and a package-manager spawn. */
static unsigned long dpkg_installed_count(const char *path){
 FILE *f=fopen(path,"r");if(!f)return 0;
 unsigned long n=0;char line[1024];
 while(fgets(line,sizeof line,f))
  if(!strncmp(line,"Status: install ok installed",28) &&
     (line[28]=='\n'||line[28]=='\r'||line[28]==0))n++;
 fclose(f);return n;
}
static unsigned long apk_installed_count(const char *path){
 FILE *f=fopen(path,"r");if(!f)return 0;
 unsigned long n=0;char line[1024];
 while(fgets(line,sizeof line,f))if(line[0]=='P'&&line[1]==':'&&line[2]!='\n')n++;
 fclose(f);return n;
}
static unsigned long portage_installed_count(void){
 DIR *d=opendir("/var/db/pkg");if(!d)return 0;
 unsigned long total=0;struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"/var/db/pkg/%s",e->d_name)>=(int)sizeof path)continue;
#ifdef DT_DIR
  if(e->d_type!=DT_DIR && e->d_type!=DT_UNKNOWN)continue;
#endif
  total+=count_subdirs(path);
 }
 closedir(d);return total;
}
/* Spawn a single package manager with no shell, grep, awk, or wc. */
static unsigned long count_process_lines(const char *program,const char *arg1,const char *arg2){
 int fds[2];if(pipe(fds)!=0)return 0;
 pid_t pid=fork();
 if(pid<0){close(fds[0]);close(fds[1]);return 0;}
 if(pid==0){
  close(fds[0]);if(dup2(fds[1],STDOUT_FILENO)<0)_exit(127);close(fds[1]);
  int null=open("/dev/null",O_WRONLY);
  if(null>=0){dup2(null,STDERR_FILENO);close(null);}
  execlp(program,program,arg1,arg2,(char*)NULL);_exit(127);
 }
 close(fds[1]);unsigned long n=0;char buf[4096];ssize_t got;
 for(;;){
  got=read(fds[0],buf,sizeof buf);
  if(got<0&&errno==EINTR)continue;
  if(got<=0)break;
  for(ssize_t i=0;i<got;i++)if(buf[i]=='\n')n++;
 }
 close(fds[0]);int status=0;pid_t waited;
 do{waited=waitpid(pid,&status,0);}while(waited<0&&errno==EINTR);
 return waited==pid&&WIFEXITED(status)&&WEXITSTATUS(status)==0?n:0;
}
/* Foreign means "installed package name absent from all enabled sync repos".
   Read the pacman configuration, then use libalpm in-process when available.
   No pacman headers are required; dlopen keeps other distros/Termux portable.
   Unsupported/custom configurations fall back to pacman -Qmq for accuracy. */
typedef struct {
 char root[PATH_MAX],dbpath[PATH_MAX],config_path[PATH_MAX],repos[48][128];
 size_t nrepos;
} PacmanConfig;
static int pacman_config_from(const char *config_path,PacmanConfig *cfg){
 memset(cfg,0,sizeof *cfg);
 snprintf(cfg->root,sizeof cfg->root,"/");
 snprintf(cfg->dbpath,sizeof cfg->dbpath,"/var/lib/pacman");
 if(snprintf(cfg->config_path,sizeof cfg->config_path,"%s",config_path)>=(int)sizeof cfg->config_path)return 0;
 FILE *f=fopen(config_path,"r");if(!f)return 0;
 char line[2048],section[128]="";int ok=1,custom_db=0;
 while(fgets(line,sizeof line,f)){
  char *p=line;while(isspace((unsigned char)*p))p++;
  if(!*p||*p=='#')continue;
  if(*p=='['){
   char *end=strchr(p+1,']');
   if(!end||end-p>=128){ok=0;break;}
   *end=0;snprintf(section,sizeof section,"%s",p+1);
   if(!strcasecmp(section,"options"))continue;
   for(const char *q=section;*q;q++)
    if(!isalnum((unsigned char)*q)&&*q!='-'&&*q!='_'&&*q!='.'&&*q!='+')ok=0;
   if(!ok||cfg->nrepos>=48){ok=0;break;}
   snprintf(cfg->repos[cfg->nrepos++],128,"%s",section);
   continue;
  }
  char *eq=strchr(p,'=');if(!eq)continue;
  *eq++=0;trim(p);
  while(isspace((unsigned char)*eq))eq++;
  char *comment=strchr(eq,'#');if(comment)*comment=0;
  trim(eq);
  if(strcasecmp(section,"options"))continue;
  if(!strcasecmp(p,"Include")){ok=0;break;} /* may contain more repos */
  if(!strcasecmp(p,"RootDir")){
   if(*eq!='/'){ok=0;break;}
   if(snprintf(cfg->root,sizeof cfg->root,"%s",eq)>=(int)sizeof cfg->root){ok=0;break;}
  }else if(!strcasecmp(p,"DBPath")){
   if(*eq!='/'){ok=0;break;}
   if(snprintf(cfg->dbpath,sizeof cfg->dbpath,"%s",eq)>=(int)sizeof cfg->dbpath){ok=0;break;}
   custom_db=1;
  }
 }
 fclose(f);
 if(!ok||!cfg->nrepos)return 0;
 if(!custom_db&&strcmp(cfg->root,"/")){
  if(snprintf(cfg->dbpath,sizeof cfg->dbpath,"%s/var/lib/pacman",cfg->root)>=(int)sizeof cfg->dbpath)return 0;
 }
 return 1;
}
static int pacman_config(PacmanConfig *cfg){
 return pacman_config_from("/etc/pacman.conf",cfg);
}
static int pacman_db_files_ready(const PacmanConfig *cfg,time_t newer_than){
 for(size_t i=0;i<cfg->nrepos;i++){
  char path[PATH_MAX];struct stat st;
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[i])>=(int)sizeof path ||
     stat(path,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<=0||st.st_mtime>newer_than)return 0;
 }
 return 1;
}
static void *pacman_load_alpm(void){
 static const char *names[]={"libalpm.so","libalpm.so.17","libalpm.so.16",
                            "libalpm.so.15","libalpm.so.14","libalpm.so.13",NULL};
 for(size_t i=0;names[i];i++){
  void *lib=dlopen(names[i],RTLD_NOW|RTLD_LOCAL);
  if(lib)return lib;
 }
 return NULL;
}
/* All signatures here are the public libalpm ABI; no struct layout assumed.
   The installed names come from pacman's name-version-release directory
   convention, avoiding a second scan of every local package desc file. */
static int pacman_foreign_libalpm(const PacmanConfig *cfg,unsigned long *result){
 void *lib=pacman_load_alpm();if(!lib)return 0;
 void *(*init)(const char*,const char*,int*)=dlsym(lib,"alpm_initialize");
 int (*release)(void*)=dlsym(lib,"alpm_release");
 void *(*register_db)(void*,const char*,int)=dlsym(lib,"alpm_register_syncdb");
 void *(*get_pkg)(void*,const char*)=dlsym(lib,"alpm_db_get_pkg");
 int (*db_valid)(void*)=dlsym(lib,"alpm_db_get_valid");
 if(!init||!release||!register_db||!get_pkg||!db_valid){dlclose(lib);return 0;}
 int err=0,ok=1;
 void *handle=init(cfg->root,cfg->dbpath,&err);
 if(!handle){dlclose(lib);return 0;}
 void *dbs[48];
 for(size_t i=0;i<cfg->nrepos;i++){
  dbs[i]=register_db(handle,cfg->repos[i],0);
  if(!dbs[i]||db_valid(dbs[i])!=0){ok=0;break;}
 }
 unsigned long foreign=0;
 if(ok){
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"%s/local",cfg->dbpath)>=(int)sizeof path)ok=0;
  DIR *dir=ok?opendir(path):NULL;
  if(!dir)ok=0;
  if(dir){
   struct dirent *e;
   while((e=readdir(dir))!=NULL){
    if(e->d_name[0]=='.')continue;
#ifdef DT_DIR
    if(e->d_type!=DT_DIR){
     if(e->d_type!=DT_UNKNOWN)continue;
     struct stat st;
     if(fstatat(dirfd(dir),e->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
    }
#else
    struct stat st;
    if(fstatat(dirfd(dir),e->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
#endif
    char name[NAME_MAX+1];snprintf(name,sizeof name,"%s",e->d_name);
    char *release_part=strrchr(name,'-');
    if(!release_part){ok=0;break;}
    *release_part=0;
    char *version_part=strrchr(name,'-');
    if(!version_part){ok=0;break;}
    *version_part=0;
    if(!*name){ok=0;break;}
    size_t i=0;
    for(;i<cfg->nrepos;i++)if(get_pkg(dbs[i],name))break;
    if(i==cfg->nrepos)foreign++;
   }
   closedir(dir);
  }
 }
 release(handle);dlclose(lib);
 if(ok)*result=foreign;
 return ok;
}
static unsigned long pacman_foreign_direct(void){
 return count_process_lines("pacman","-Qmq",NULL);
}
/* The authoritative foreign-package query must read every enabled sync DB.
   Keep its exact result in XDG_STATE_HOME and validate it against both the
   local DB and every configured sync DB. Clearing disposable XDG_CACHE_HOME
   then does not force a full repository parse. This is a persistent index,
   not a claim that a genuinely unindexed first launch is free. */
static uint64_t pacman_hash_byte(uint64_t h,unsigned char b){
 return (h^(uint64_t)b)*UINT64_C(1099511628211);
}
static uint64_t pacman_hash_u64(uint64_t h,uint64_t v){
 for(int i=0;i<8;i++){h=pacman_hash_byte(h,(unsigned char)v);v>>=8;}
 return h;
}
static uint64_t pacman_hash_str(uint64_t h,const char *s){
 for(;*s;s++)h=pacman_hash_byte(h,(unsigned char)*s);
 return pacman_hash_byte(h,0);
}
static uint64_t pacman_hash_stat(uint64_t h,const struct stat *st){
 h=pacman_hash_u64(h,(uint64_t)st->st_dev);
 h=pacman_hash_u64(h,(uint64_t)st->st_ino);
 h=pacman_hash_u64(h,(uint64_t)st->st_size);
 h=pacman_hash_u64(h,(uint64_t)st->st_mtim.tv_sec);
 h=pacman_hash_u64(h,(uint64_t)st->st_mtim.tv_nsec);
 h=pacman_hash_u64(h,(uint64_t)st->st_ctim.tv_sec);
 return pacman_hash_u64(h,(uint64_t)st->st_ctim.tv_nsec);
}
static int pacman_db_fingerprint(const PacmanConfig *cfg,uint64_t *fingerprint){
 uint64_t h=UINT64_C(14695981039346656037);
 h=pacman_hash_str(h,cfg->root);
 h=pacman_hash_str(h,cfg->dbpath);
 struct stat st;char path[PATH_MAX+16];
 if(stat(cfg->config_path,&st)!=0||!S_ISREG(st.st_mode))return 0;
 h=pacman_hash_stat(pacman_hash_str(h,cfg->config_path),&st);
 if(snprintf(path,sizeof path,"%s/local",cfg->dbpath)>=(int)sizeof path ||
    stat(path,&st)!=0||!S_ISDIR(st.st_mode))return 0;
 h=pacman_hash_stat(h,&st);
 for(size_t i=0;i<cfg->nrepos;i++){
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[i])>=(int)sizeof path ||
     stat(path,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<=0)return 0;
  h=pacman_hash_stat(pacman_hash_str(h,cfg->repos[i]),&st);
 }
 *fingerprint=h;
 return 1;
}
static int pacman_state_file(char *file,size_t cap,int create){
 const char *xdg=getenv("XDG_STATE_HOME"),*home=getenv("HOME");
 char base[PATH_MAX],dir[PATH_MAX],parent[PATH_MAX];
 int default_state=!xdg||!*xdg;
 if(!default_state){
  if(snprintf(base,sizeof base,"%s",xdg)>=(int)sizeof base)return 0;
 }else{
  if(!home||!*home)return 0;
  if(snprintf(parent,sizeof parent,"%s/.local",home)>=(int)sizeof parent)return 0;
  if(snprintf(base,sizeof base,"%s/state",parent)>=(int)sizeof base)return 0;
 }
 if(snprintf(dir,sizeof dir,"%s/nisfetch",base)>=(int)sizeof dir ||
    snprintf(file,cap,"%s/pacman-foreign.index",dir)>=(int)cap)return 0;
 if(create){
  if(default_state&&mkdir(parent,0700)&&errno!=EEXIST)return 0;
  if(mkdir(base,0700)&&errno!=EEXIST)return 0;
  if(mkdir(dir,0700)&&errno!=EEXIST)return 0;
 }
 return 1;
}
static int pacman_index_read(uint64_t fingerprint,unsigned long *count){
 char file[PATH_MAX];
 if(!pacman_state_file(file,sizeof file,0))return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 char line[128];int read_ok=fgets(line,sizeof line,f)!=NULL;
 fclose(f);if(!read_ok)return 0;
 unsigned long long key=0;unsigned long found=0;char extra=0;
 if(sscanf(line,"NISFETCH-ALPM1 %llx %lu %c",&key,&found,&extra)!=2 ||
    (uint64_t)key!=fingerprint)return 0;
 *count=found;
 return 1;
}
static void pacman_index_write(uint64_t fingerprint,unsigned long count){
 char file[PATH_MAX],tmp[PATH_MAX+32],content[128];
 if(!pacman_state_file(file,sizeof file,1))return;
 /* The index path is stable; staging in the same directory makes rename atomic. */
 if(snprintf(tmp,sizeof tmp,"%s.XXXXXXXX",file)>=(int)sizeof tmp)return;
 int fd=mkstemp(tmp);if(fd<0)return;
 int len=snprintf(content,sizeof content,"NISFETCH-ALPM1 %016llx %lu\n",
                  (unsigned long long)fingerprint,count);
 int ok=len>0&&(size_t)len<sizeof content&&
        write(fd,content,(size_t)len)==len;
 if(close(fd)!=0)ok=0;
 if(ok&&rename(tmp,file)==0)return;
 unlink(tmp);
}
/* Preserve the existing foreign-package index. A separate, equally validated
   total-count index avoids scanning the local Pacman directory on every cold
   XDG_CACHE_HOME launch. Both indexes are invalidated by the same DB stamp. */
static int pacman_total_file(char *file,size_t cap,int create){
 char foreign[PATH_MAX];
 if(!pacman_state_file(foreign,sizeof foreign,create))return 0;
 char *slash=strrchr(foreign,'/');if(!slash)return 0;
 *slash=0;
 return snprintf(file,cap,"%s/pacman-total.index",foreign)<(int)cap;
}
static int pacman_total_read(uint64_t fingerprint,unsigned long *count){
 char file[PATH_MAX],line[128];
 if(!pacman_total_file(file,sizeof file,0))return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 int ok=fgets(line,sizeof line,f)!=NULL;fclose(f);
 if(!ok)return 0;
 unsigned long long key=0;unsigned long result=0;char extra=0;
 if(sscanf(line,"NISFETCH-TOTAL1 %llx %lu %c",&key,&result,&extra)!=2 ||
    (uint64_t)key!=fingerprint)return 0;
 *count=result;return 1;
}
static void pacman_total_write(uint64_t fingerprint,unsigned long count){
 char file[PATH_MAX],tmp[PATH_MAX+32],line[128];
 if(!pacman_total_file(file,sizeof file,1))return;
 if(snprintf(tmp,sizeof tmp,"%s.XXXXXXXX",file)>=(int)sizeof tmp)return;
 int fd=mkstemp(tmp);if(fd<0)return;
 int len=snprintf(line,sizeof line,"NISFETCH-TOTAL1 %016llx %lu\n",
                  (unsigned long long)fingerprint,count);
 int ok=len>0&&(size_t)len<sizeof line&&write(fd,line,(size_t)len)==len;
 if(close(fd)!=0)ok=0;
 if(ok&&rename(tmp,file)==0)return;
 unlink(tmp);
}
static unsigned long pacman_total_packages(const PacmanConfig *cfg,const char *local){
 uint64_t fingerprint=0;unsigned long total=0;
 int valid=pacman_db_fingerprint(cfg,&fingerprint);
 if(valid&&pacman_total_read(fingerprint,&total))return total;
 total=count_subdirs(local);
 if(valid)pacman_total_write(fingerprint,total);
 return total;
}
/* Fast cold-start fallback: read repository name indexes directly from the
   compressed sync .db archives. libarchive is already a Pacman dependency on
   Arch; load it only for an uncached foreign-package query. The lookup stores
   exact package names in a compact arena, never lossy hashes alone. */
typedef struct {uint64_t hash;uint32_t offset;unsigned char matched;} NisRepoSlot;
typedef struct {
 NisRepoSlot *slots;size_t capacity,used;
 char *arena;size_t arena_cap,arena_used;
} NisRepoNames;
static void nis_repo_names_free(NisRepoNames *set){
 free(set->slots);free(set->arena);memset(set,0,sizeof *set);
}
static int nis_repo_names_rehash(NisRepoNames *set,size_t capacity){
 NisRepoSlot *slots=calloc(capacity,sizeof *slots);if(!slots)return 0;
 for(size_t i=0;i<set->capacity;i++)if(set->slots[i].offset){
  NisRepoSlot slot=set->slots[i];
  size_t j=(size_t)slot.hash&(capacity-1);
  while(slots[j].offset)j=(j+1)&(capacity-1);
  slots[j]=slot;
 }
 free(set->slots);set->slots=slots;set->capacity=capacity;
 return 1;
}
static int nis_repo_names_has(const NisRepoNames *set,const char *name){
 if(!set->capacity)return 0;
 uint64_t hash=pacman_hash_str(UINT64_C(14695981039346656037),name);
 size_t i=(size_t)hash&(set->capacity-1);
 while(set->slots[i].offset){
  const NisRepoSlot *slot=&set->slots[i];
  if(slot->hash==hash&&!strcmp(set->arena+slot->offset-1,name))return 1;
  i=(i+1)&(set->capacity-1);
 }
 return 0;
}
static int nis_repo_names_mark(NisRepoNames *set,const char *name){
 if(!set->capacity)return 0;
 uint64_t hash=pacman_hash_str(UINT64_C(14695981039346656037),name);
 size_t i=(size_t)hash&(set->capacity-1);
 while(set->slots[i].offset){
  NisRepoSlot *slot=&set->slots[i];
  if(slot->hash==hash&&!strcmp(set->arena+slot->offset-1,name)){
   if(slot->matched)return 0;
   slot->matched=1;return 1;
  }
  i=(i+1)&(set->capacity-1);
 }
 return 0;
}
static int nis_repo_names_add(NisRepoNames *set,const char *name){
 if(!*name)return 0;
 if(!set->capacity&&!nis_repo_names_rehash(set,4096))return 0;
 uint64_t hash=pacman_hash_str(UINT64_C(14695981039346656037),name);
 size_t i=(size_t)hash&(set->capacity-1);
 while(set->slots[i].offset){
  if(set->slots[i].hash==hash &&
     !strcmp(set->arena+set->slots[i].offset-1,name))return 1;
  i=(i+1)&(set->capacity-1);
 }
 /* Bound untrusted archives; if exceeded, fall back to libalpm. */
 if(set->used>600000||set->capacity>=1U<<21)return 0;
 if((set->used+1)*10>set->capacity*7){
  if(!nis_repo_names_rehash(set,set->capacity*2))return 0;
  i=(size_t)hash&(set->capacity-1);
  while(set->slots[i].offset)i=(i+1)&(set->capacity-1);
 }
 size_t n=strlen(name)+1;
 if(n>UINT32_MAX||set->arena_used>UINT32_MAX-n)return 0;
 if(set->arena_used+n>set->arena_cap){
  size_t next=set->arena_cap?set->arena_cap*2:16384;
  while(next<set->arena_used+n)next*=2;
  char *buf=realloc(set->arena,next);if(!buf)return 0;
  set->arena=buf;set->arena_cap=next;
 }
 memcpy(set->arena+set->arena_used,name,n);
 set->slots[i].hash=hash;
 set->slots[i].offset=(uint32_t)(set->arena_used+1);
 set->arena_used+=n;set->used++;
 return 1;
}
/* Both sync and local DBs use pkgname-version-release naming. Reject rather
   than guess if an entry does not fit this format, and try libalpm instead. */
static int nis_pacman_entry_name(const char *entry,char *out,size_t cap){
 const char *slash=strrchr(entry,'/');
 if(!slash||strcmp(slash,"/desc"))return 0;
 size_t n=(size_t)(slash-entry);
 if(n<4||n>=cap)return -1;
 memcpy(out,entry,n);out[n]=0;
 if(!strncmp(out,"./",2))memmove(out,out+2,strlen(out+2)+1);
 if(strchr(out,'/'))return -1;
 char *rel=strrchr(out,'-');if(!rel)return -1;
 *rel=0;
 char *ver=strrchr(out,'-');if(!ver||!ver[1])return -1;
 *ver=0;
 return *out?1:-1;
}
static int nis_pacman_local_name(const char *entry,char *out,size_t cap){
 size_t n=strlen(entry);
 if(n<4||n>=cap)return 0;
 memcpy(out,entry,n+1);
 char *rel=strrchr(out,'-');if(!rel)return 0;
 *rel=0;
 char *ver=strrchr(out,'-');if(!ver||!ver[1])return 0;
 *ver=0;
 return *out!=0;
}
#include "nis_pacman_stream.h"
static int pacman_foreign_libarchive(const PacmanConfig *cfg,unsigned long *result){
 static const char *const libraries[]={"libarchive.so","libarchive.so.13",
  "libarchive.so.14","libarchive.so.12",NULL};
 void *lib=NULL;
 for(size_t k=0;libraries[k];k++)if((lib=dlopen(libraries[k],RTLD_NOW|RTLD_LOCAL)))break;
 if(!lib)return 0;
 void *(*new_archive)(void)=dlsym(lib,"archive_read_new");
 int (*filters)(void*)=dlsym(lib,"archive_read_support_filter_all");
 int (*tar)(void*)=dlsym(lib,"archive_read_support_format_tar");
 int (*open_file)(void*,const char*,size_t)=dlsym(lib,"archive_read_open_filename");
 int (*next_header)(void*,void**)=dlsym(lib,"archive_read_next_header");
 const char *(*pathname)(void*)=dlsym(lib,"archive_entry_pathname");
 int (*free_archive)(void*)=dlsym(lib,"archive_read_free");
 if(!new_archive||!filters||!tar||!open_file||!next_header||!pathname||!free_archive){
  dlclose(lib);return 0;
 }
 NisRepoNames names={0};int ok=1;
 for(size_t r=0;r<cfg->nrepos&&ok;r++){
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[r])>=(int)sizeof path){ok=0;break;}
  void *archive=new_archive();if(!archive){ok=0;break;}
  if(filters(archive)!=0||tar(archive)!=0||open_file(archive,path,32768)!=0)ok=0;
  unsigned long entries=0;
  while(ok){
   void *item=NULL;int status=next_header(archive,&item);
   if(status==1)break; /* ARCHIVE_EOF */
   if(status!=0||!item){ok=0;break;}
   const char *entry=pathname(item);if(!entry)continue;
   char name[512];int parsed=nis_pacman_entry_name(entry,name,sizeof name);
   if(parsed<0){ok=0;break;}
   if(parsed>0){
    if(!nis_repo_names_add(&names,name)){ok=0;break;}
    entries++;
   }
  }
  if(!entries)ok=0;
  if(free_archive(archive)!=0)ok=0;
 }
 if(ok){
  char local[PATH_MAX];
  if(snprintf(local,sizeof local,"%s/local",cfg->dbpath)>=(int)sizeof local)ok=0;
  DIR *d=ok?opendir(local):NULL;if(!d)ok=0;
  if(d){
   struct dirent *entry;unsigned long foreign=0;
   while((entry=readdir(d))!=NULL){
    if(entry->d_name[0]=='.')continue;
#ifdef DT_DIR
    if(entry->d_type!=DT_DIR){
     if(entry->d_type!=DT_UNKNOWN)continue;
#endif
     struct stat st;
     if(fstatat(dirfd(d),entry->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
#ifdef DT_DIR
    }
#endif
    char name[512];
    if(!nis_pacman_local_name(entry->d_name,name,sizeof name)){ok=0;break;}
    if(!nis_repo_names_has(&names,name))foreign++;
   }
   closedir(d);
   if(ok)*result=foreign;
  }
 }
 nis_repo_names_free(&names);
 dlclose(lib);
 return ok;
}
static unsigned long foreign_packages(const PacmanConfig *cfg){
 char buf[80];struct stat db,cache,pacman_conf;
 uint64_t fingerprint=0;unsigned long indexed=0;
 int indexed_db=pacman_db_fingerprint(cfg,&fingerprint);
 if(indexed_db&&pacman_index_read(fingerprint,&indexed))return indexed;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char file[PATH_MAX];
 if(base&&*base)snprintf(file,sizeof file,"%s/nisfetch/foreign_count",base);
 else if(home&&*home)snprintf(file,sizeof file,"%s/.cache/nisfetch/foreign_count",home);
 else file[0]=0;
 char local[PATH_MAX];
 if(snprintf(local,sizeof local,"%s/local",cfg->dbpath)>=(int)sizeof local)return pacman_foreign_direct();
 /* Invalidate on either an installed-package or sync-repository DB change. */
 /* A fingerprint mismatch is authoritative. Do not resurrect an old count
    from the legacy timestamp-only cache (coarse mtime can miss same-second
    repository updates). Only use that cache if fingerprinting is unavailable. */
 if(!indexed_db && file[0] && stat(local,&db)==0 &&
    stat(file,&cache)==0 && cache.st_mtime>=db.st_mtime &&
    (stat(cfg->config_path,&pacman_conf)!=0||cache.st_mtime>=pacman_conf.st_mtime) &&
    pacman_db_files_ready(cfg,cache.st_mtime) &&
    time(NULL)-cache.st_mtime<3600 && cache_read("foreign_count",buf,sizeof buf,3600)){
  char *end;unsigned long n=strtoul(buf,&end,10);
  if(end!=buf && !*end){
   if(indexed_db)pacman_index_write(fingerprint,n);
   return n;
  }
 }
 unsigned long n=0;
 int alpm_ok=indexed_db&&
   (pacman_foreign_libarchive(cfg,&n)||pacman_foreign_stream(cfg,&n)||
    pacman_foreign_libalpm(cfg,&n));
 if(!alpm_ok)
  n=pacman_foreign_direct();
 else pacman_index_write(fingerprint,n);
 snprintf(buf,sizeof buf,"%lu",n);cache_write("foreign_count",buf);
 return n;
}
static unsigned long flatpak_apps(void){
 unsigned long n=0;
 const char *home=getenv("HOME");char path[PATH_MAX];
 n+=count_subdirs("/var/lib/flatpak/app");
 if(home&&*home && snprintf(path,sizeof path,"%s/.local/share/flatpak/app",home)<(int)sizeof path)
  n+=count_subdirs(path);
 return n;
}
static void packages_uncached(char *out,size_t cap){
 out[0]=0;
 size_t used=0;
 if(is_termux()){
  char path[PATH_MAX];unsigned long n=0;
  const char *prefix=getenv("PREFIX");
  if(prefix&&*prefix&&snprintf(path,sizeof path,"%s/var/lib/dpkg/status",prefix)<(int)sizeof path)
   n=dpkg_installed_count(path);
  if(!n)n=dpkg_installed_count("/data/data/com.termux/files/usr/var/lib/dpkg/status");
  if(!n)n=count_lines("dpkg-query -W -f='${db:Status-Abbrev}\\n' 2>/dev/null | grep -c '^ii'");
  if(n){snprintf(out,cap,"%lu (dpkg/Termux)",n);return;}
 }
 PacmanConfig pacman_cfg;
 int has_pacman_cfg=(!cfg_packages_fast||access("/var/lib/pacman/local",F_OK)!=0)?
  pacman_config(&pacman_cfg):0;
 char pacman_local[PATH_MAX+16]="/var/lib/pacman/local";
 /* In fast mode the standard Pacman local DB is sufficient. Avoid loading
    and hashing compressed repository databases and creating foreign indexes. */
 if(!cfg_packages_fast&&has_pacman_cfg)
  snprintf(pacman_local,sizeof pacman_local,"%s/local",pacman_cfg.dbpath);
 else if(cfg_packages_fast&&access(pacman_local,F_OK)!=0&&has_pacman_cfg)
  snprintf(pacman_local,sizeof pacman_local,"%s/local",pacman_cfg.dbpath);
 if(access(pacman_local,F_OK)==0){
  if(cfg_packages_fast){
   /* Fastfetch-compatible workload: all installed Pacman packages, without
      classifying AUR/foreign packages. Never label it a native-only count. */
   unsigned long total=count_subdirs(pacman_local);
   if(total)used=(size_t)snprintf(out,cap,"%lu (pacman total)",total);
  }else{
   /* Native = pacman -Qn; foreign = pacman -Qm (usually AUR). */
   unsigned long total=has_pacman_cfg?pacman_total_packages(&pacman_cfg,pacman_local):count_subdirs(pacman_local);
   unsigned long foreign=has_pacman_cfg?foreign_packages(&pacman_cfg):pacman_foreign_direct();
   unsigned long native=total>=foreign?total-foreign:0;
   if(native)used+=(size_t)snprintf(out+used,cap-used,"%lu (pacman)",native);
   if(foreign && used<cap)used+=(size_t)snprintf(out+used,cap-used,"%s%lu (AUR/foreign)",used?", ":"",foreign);
  }
 }else if(access("/var/lib/dpkg/status",R_OK)==0){
  unsigned long n=dpkg_installed_count("/var/lib/dpkg/status");
  if(n)used=(size_t)snprintf(out,cap,"%lu (dpkg)",n);
 }else if(access("/usr/lib/sysimage/rpm",F_OK)==0||access("/var/lib/rpm",F_OK)==0){
  unsigned long n=count_process_lines("rpm","-qa",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (rpm)",n);
 }else if(access("/lib/apk/db/installed",R_OK)==0||access("/var/lib/apk/db/installed",R_OK)==0){
  unsigned long n=apk_installed_count(access("/lib/apk/db/installed",R_OK)==0?
   "/lib/apk/db/installed":"/var/lib/apk/db/installed");
  if(n)used=(size_t)snprintf(out,cap,"%lu (apk)",n);
 }else if(access("/etc/gentoo-release",F_OK)==0){
  unsigned long n=portage_installed_count();
  if(n)used=(size_t)snprintf(out,cap,"%lu (portage)",n);
 }else if(access("/var/db/xbps",F_OK)==0){
  unsigned long n=count_process_lines("xbps-query","-l",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (xbps)",n);
 }else if(access("/var/db/pkg",F_OK)==0){
  unsigned long n=count_process_lines("pkg","info",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (pkg)",n);
 }
 /* Flatpak apps across user and system installations, if installed. */
 unsigned long flat=flatpak_apps();
 if(flat && used<cap)snprintf(out+used,cap-used,"%s%lu (flatpak)",used?", ":"",flat);
 if(!*out)snprintf(out,cap,"Unavailable");
}
static void packages(char *out,size_t cap){
 const char *key=cfg_packages_fast?"packages_fast":"packages";
 if(cache_read(key,out,cap,15))return;
 packages_uncached(out,cap);
 if(*out && strcmp(out,"Unavailable"))cache_write(key,out);
}
static const char *env_or(const char *name,const char *fallback){const char *v=getenv(name);return v&&*v?v:fallback;}


static void command_first(const char *cmd,char *out,size_t cap){
 out[0]=0;
 FILE *f=popen(cmd,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 pclose(f);
}
static void ini_value(const char *path,const char *section,const char *key,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 char line[512];int active=0;
 while(fgets(line,sizeof line,f)){
  trim(line);
  if(line[0]=='['){active=(strlen(line)==strlen(section)+2 && line[1+strlen(section)]==']' && !strncmp(line+1,section,strlen(section)));continue;}
  if(active && !strncmp(line,key,strlen(key)) && line[strlen(key)]=='='){
   snprintf(out,cap,"%s",line+strlen(key)+1);break;
  }
 }
 fclose(f);
}
static void config_file(char *out,size_t cap,const char *name){
 const char *base=getenv("XDG_CONFIG_HOME");
 if(base&&*base)snprintf(out,cap,"%s/%s",base,name);
 else snprintf(out,cap,"%s/.config/%s",env_or("HOME",""),name);
}
static void swapinfo(char *out,size_t cap){
 struct sysinfo s;if(sysinfo(&s)){snprintf(out,cap,"Unavailable");return;}
 unsigned long long total=(unsigned long long)s.totalswap*s.mem_unit;
 unsigned long long used=(unsigned long long)(s.totalswap-s.freeswap)*s.mem_unit;
 if(!total){snprintf(out,cap,"Disabled");return;}
 snprintf(out,cap,"%.2f GiB / %.2f GiB",used/1073741824.,total/1073741824.);
}
static void displayinfo(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Android display");return;}
 const char *session=getenv("XDG_SESSION_TYPE");
 if(session&&!strcasecmp(session,"wayland")){
  /* Xrandr commonly reports a virtual XWayland screen, not the actual monitor. */
  snprintf(out,cap,"Wayland");return;
 }
 const char *display=getenv("DISPLAY");
 if(!display||!*display){
  snprintf(out,cap,"%s",session&&*session?session:"TTY");return;
 }
 command_first("command -v xrandr >/dev/null && xrandr --current 2>/dev/null | awk '/\\*/ {print $1 \" @ \" $2; exit}'",out,cap);
 if(!*out)snprintf(out,cap,"%s",session&&*session?session:"TTY");
}
typedef struct {unsigned width,height;double hz;} NisActiveMode;
/* KScreen marks the selected mode with '*'; '?' and '!' designate other
 * properties and must not be mistaken for an active frequency. */
static int nis_kscreen_parse_line(const char *line,NisActiveMode *mode){
 for(const char *p=line;*p;p++){
  if(!isdigit((unsigned char)*p))continue;
  unsigned w=0,h=0;double hz=0;int parsed=0;
  if(sscanf(p,"%ux%u@%lf%n",&w,&h,&hz,&parsed)!=3 || parsed<=0)continue;
  if(w<320||w>20000||h<200||h>20000||hz<10.0||hz>1000.0)continue;
  const char *end=p+parsed;int active=0;
  while(*end&&!isspace((unsigned char)*end)&&*end!=':'){
   if(*end=='*')active=1;
   end++;
  }
  if(active){mode->width=w;mode->height=h;mode->hz=hz;return 1;}
  p=end-1;
 }
 return 0;
}
static int nis_kscreen_current(NisActiveMode *mode){
 const char *fixture=getenv("NISFETCH_TEST_KSCREEN_FILE");
 FILE *f=fixture&&*fixture?fopen(fixture,"r"):
  popen("if command -v kscreen-doctor >/dev/null 2>&1; then kscreen-doctor -o 2>/dev/null; fi","r");
 if(!f)return 0;
 char line[16384];int found=0;
 while(fgets(line,sizeof line,f))if(nis_kscreen_parse_line(line,mode)){found=1;break;}
 if(fixture&&*fixture)fclose(f);else pclose(f);
 return found;
}
static void nis_monitor_label(const NisMonitor *monitor,char *out,size_t cap){
 out[0]=0;
 if(!monitor->valid_edid)return;
 if(*monitor->model){
  if(!strncasecmp(monitor->model,monitor->vendor,strlen(monitor->vendor)))
   snprintf(out,cap,"%s",monitor->model);
  else snprintf(out,cap,"%s %s",monitor->vendor,monitor->model);
 }else snprintf(out,cap,"%s",monitor->vendor);
}
static void kde_read(const char *file,const char *group,const char *key,char *out,size_t cap){
 char path[512];config_file(path,sizeof path,file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 /* KDE configuration can be inherited from system defaults. */
 snprintf(path,sizeof path,"/etc/xdg/%s",file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 const char *xdg=getenv("XDG_CONFIG_DIRS");
 if(xdg&&*xdg){
  char *copy=strdup(xdg);if(!copy)return;
  char *save=NULL;
  for(char *dir=strtok_r(copy,":",&save);dir;dir=strtok_r(NULL,":",&save)){
   if(snprintf(path,sizeof path,"%s/%s",dir,file)>=(int)sizeof path)continue;
   ini_value(path,group,key,out,cap);if(*out)break;
  }
  free(copy);
 }
}
static void kde_command(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* KDE's own configuration reader understands merged configuration. */
 char cmd[512];
 if(snprintf(cmd,sizeof cmd,
    "if command -v kreadconfig6 >/dev/null 2>&1; then kreadconfig6 --file %s --group %s --key %s 2>/dev/null; "
    "elif command -v kreadconfig5 >/dev/null 2>&1; then kreadconfig5 --file %s --group %s --key %s 2>/dev/null; fi",
    file,group,key,file,group,key)>=(int)sizeof cmd)return;
 command_first(cmd,out,cap);
}
static void kde_setting(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* First read KDE's native INI files. Cache only the expensive KDE fallback,
    including missing keys; never cache the native path. */
 out[0]=0;
 kde_read(file,group,key,out,cap);
 if(*out)return;
 char cache_key[192],cached[512];
 snprintf(cache_key,sizeof cache_key,"kde_%s_%s_%s",file,group,key);
 if(cache_read(cache_key,cached,sizeof cached,60)){
  if(strcmp(cached,"__NISFETCH_EMPTY__"))snprintf(out,cap,"%.*s",(int)cap-1,cached);
  return;
 }
 kde_command(file,group,key,out,cap);
 cache_write(cache_key,*out?out:"__NISFETCH_EMPTY__");
}
static int is_kde(void){
 const char *d=getenv("XDG_CURRENT_DESKTOP");
 return d&&(strstr(d,"KDE")||strstr(d,"Plasma"));
}
/* Resolve only selected KDE modules, rather than eagerly resolving all six
   settings (and fontconfig) for every single-module request. */
static void themeinfo(char *wmtheme,size_t wtcap,char *theme,size_t tcap,
                      char *icons,size_t icap,char *font,size_t fcap,
                      char *cursor,size_t ccap,char *plasma,size_t pcap){
 const int want_wm=module_enabled("wmtheme");
 const int want_theme=module_enabled("theme");
 const int want_icons=module_enabled("icons");
 const int want_font=module_enabled("font");
 const int want_cursor=module_enabled("cursor");
 const int want_plasma=module_enabled("plasmatheme");
 if(!is_kde()){
  (void)wtcap;(void)pcap;(void)want_wm;(void)want_plasma;
  /* Direct environment overrides work across desktops at negligible cost.
     A GTK theme must not be mislabeled as a window-decoration theme. */
  if(want_theme){const char *e=getenv("GTK_THEME");if(e&&*e)snprintf(theme,tcap,"%s",e);}
  if(want_icons){const char *e=getenv("GTK_ICON_THEME");if(e&&*e)snprintf(icons,icap,"%s",e);}
  if(want_font){const char *e=getenv("GTK_FONT_NAME");if(e&&*e)snprintf(font,fcap,"%s",e);}
  if(want_cursor){const char *e=getenv("XCURSOR_THEME");if(e&&*e)snprintf(cursor,ccap,"%s",e);}
  return;
 }
 if(want_wm){
  kde_setting("kwinrc","org.kde.kdecoration2","theme",wmtheme,wtcap);
  if(!*wmtheme)kde_setting("kwinrc","org.kde.kdecoration2","library",wmtheme,wtcap);
  if(!*wmtheme)snprintf(wmtheme,wtcap,"Breeze (assumed default)");
 }
 if(want_theme){
  kde_setting("kdeglobals","General","ColorScheme",theme,tcap);
  if(!*theme)snprintf(theme,tcap,"Breeze (assumed default)");
 }
 if(want_icons){
  kde_setting("kdeglobals","Icons","Theme",icons,icap);
  if(!*icons)snprintf(icons,icap,"breeze (assumed default)");
 }
 if(want_font){
  kde_setting("kdeglobals","General","font",font,fcap);
  if(!*font){
   if(!cache_read("fontconfig_family",font,fcap,300)){
    command_first("fc-match -f '%{family}\n' sans-serif 2>/dev/null",font,fcap);
    if(*font)cache_write("fontconfig_family",font);
   }
   if(!*font)snprintf(font,fcap,"Not configured");
   else {size_t n=strlen(font);if(n<fcap)snprintf(font+n,fcap-n," (fontconfig)");}
  }
  char *comma=strchr(font,',');if(comma)*comma=0;
 }
 if(want_cursor){
  kde_setting("kcminputrc","Mouse","cursorTheme",cursor,ccap);
  if(!*cursor)snprintf(cursor,ccap,"Breeze (assumed default)");
 }
 if(want_plasma){
  kde_setting("plasmarc","Theme","name",plasma,pcap);
  if(!*plasma)snprintf(plasma,pcap,"Breeze (assumed default)");
 }
}
static void kde_display(char *out,size_t cap){
 /* Cache KScreen mode lookup; EDID itself is a cheap binary sysfs read. */
 /* v3.1 has new fields: do not reuse v3.0's resolution-only cache. */
 if(cache_read("display_v31",out,cap,30))return;
 if(is_termux()){displayinfo(out,cap);return;}
 NisMonitor monitor;nis_monitor_probe(&monitor);
 NisActiveMode active={0};int has_active=is_kde()&&nis_kscreen_current(&active);
 char mode[128]="",model[160]="";
 if(has_active){
  snprintf(mode,sizeof mode,"%ux%u @ %.2f Hz",active.width,active.height,active.hz);
 }else{
  displayinfo(mode,sizeof mode);
  /* XRandR can expose the actual active refresh rate on X11. */
  char *at=strstr(mode," @ ");
  if(at){
   double hz=atof(at+3);
   if(hz>10.0&&hz<1000.0)snprintf(at,(size_t)(mode+sizeof mode-at)," @ %.2f Hz",hz);
  }
  if((!*mode||!strcmp(mode,"Wayland")||!strcmp(mode,"TTY"))&&
     monitor.preferred_width&&monitor.preferred_height){
   if(monitor.preferred_hz>0)
    snprintf(mode,sizeof mode,"%ux%u @ %.2f Hz (preferred)",
             monitor.preferred_width,monitor.preferred_height,monitor.preferred_hz);
   else snprintf(mode,sizeof mode,"%ux%u (preferred)",
                 monitor.preferred_width,monitor.preferred_height);
  }
 }
 nis_monitor_label(&monitor,model,sizeof model);
 if(*model)snprintf(out,cap,"%s | %s",mode,model);
 else snprintf(out,cap,"%s",mode);
 if(*out && strcmp(out,"Unavailable"))cache_write("display_v31",out);
}
static void wm_info(char *out,size_t cap){
 const char *desktop=env_or("XDG_CURRENT_DESKTOP",env_or("XDG_SESSION_DESKTOP",""));
 const char *wm=NULL;
 if(getenv("HYPRLAND_INSTANCE_SIGNATURE"))wm="Hyprland";
 else if(getenv("SWAYSOCK"))wm="Sway";
 else if(getenv("NIRI_SOCKET"))wm="niri";
 else if(getenv("I3SOCK"))wm="i3";
 else if(strstr(desktop,"Hyprland"))wm="Hyprland";
 else if(strstr(desktop,"sway")||strstr(desktop,"Sway"))wm="Sway";
 else if(strstr(desktop,"COSMIC"))wm="cosmic-comp";
 else if(strstr(desktop,"labwc"))wm="labwc";
 else if(strstr(desktop,"river"))wm="river";
 else if(strstr(desktop,"Wayfire"))wm="Wayfire";
 else if(strstr(desktop,"KDE")||strstr(desktop,"Plasma"))wm="KWin";
 else if(strstr(desktop,"GNOME"))wm="Mutter";
 else if(strstr(desktop,"Cinnamon"))wm="Muffin";
 else if(strstr(desktop,"MATE"))wm="Marco";
 else if(strstr(desktop,"XFCE")||strstr(desktop,"Xfce"))wm="Xfwm4";
 if(wm)snprintf(out,cap,"%s (%s)",wm,env_or("XDG_SESSION_TYPE","unknown"));
 else out[0]=0;
}
static void disk_path(const char *path,char *out,size_t cap){
 struct statvfs v;if(statvfs(path,&v)){snprintf(out,cap,"Unavailable");return;}
 double t=(double)v.f_blocks*v.f_frsize,used=(double)(v.f_blocks-v.f_bfree)*v.f_frsize;
 double pct=t?100*used/t:0;
 const char *c=pct<50?"\033[1;32m":pct<=75?"\033[1;33m":"\033[1;31m";
 snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%" R ")",used/1073741824.,t/1073741824.,c,pct);
}
static void palette_row(int row){
 for(int i=0;i<8;i++)printf("\033[48;5;%dm   ",row*8+i);
 fputs(R,stdout);
}

static int read_temp(const char *path,double *celsius){
 FILE *f=fopen(path,"r");if(!f)return 0;
 long val=0;int ok=fscanf(f,"%ld",&val)==1;fclose(f);
 if(!ok||val< -30000||val>150000)return 0;
 *celsius=val/1000.0;return 1;
}
static int sensor_temp(const char *driver,double *value){
 DIR *d=opendir("/sys/class/hwmon");if(!d)return 0;
 struct dirent *e;int found=0;
 while((e=readdir(d))){
  if(strncmp(e->d_name,"hwmon",5))continue;
  char path[512],name[128];
  snprintf(path,sizeof path,"/sys/class/hwmon/%s/name",e->d_name);
  FILE *f=fopen(path,"r");if(!f)continue;
  if(!fgets(name,sizeof name,f)){fclose(f);continue;}fclose(f);trim(name);
  if(strcmp(name,driver))continue;
  for(int i=1;i<=4;i++){
   snprintf(path,sizeof path,"/sys/class/hwmon/%s/temp%d_input",e->d_name,i);
   if(read_temp(path,value)){found=1;break;}
  }
  if(found)break;
 }
 closedir(d);return found;
}
static void temp_suffix(char *out,size_t cap,const char *driver1,const char *driver2){
 double temp;
 if(sensor_temp(driver1,&temp)||sensor_temp(driver2,&temp)){
  const char *color=temp<50?"\033[1;32m":temp<=75?"\033[1;33m":"\033[1;31m";
  size_t n=strlen(out);
  if(n<cap)snprintf(out+n,cap-n," (%s%.0f°C\033[0m)",color,temp);
 }
}
/* Linux DRM sysfs fast path. Only name IDs we can identify unambiguously;
   unknown GPUs retain the renderer/PCI fallbacks. No subprocesses. */
static int gpu_drm_fast(char *out,size_t cap){
#ifdef __linux__
 DIR *dir=opendir("/sys/class/drm");
 if(!dir)return 0;
 struct dirent *entry;
 while((entry=readdir(dir))!=NULL){
  if(strncmp(entry->d_name,"card",4)!=0)continue;
  const char *p=entry->d_name+4;
  if(!isdigit((unsigned char)*p))continue;
  while(isdigit((unsigned char)*p))p++;
  if(*p)continue; /* skip card0-DP-1 connectors */
  char file[PATH_MAX],buf[64];unsigned vendor=0,device=0;
  if(snprintf(file,sizeof file,"/sys/class/drm/%s/device/vendor",entry->d_name)>=(int)sizeof file)continue;
  FILE *f=fopen(file,"r");if(!f)continue;
  if(fgets(buf,sizeof buf,f))vendor=(unsigned)strtoul(buf,NULL,0);
  fclose(f);
  if(snprintf(file,sizeof file,"/sys/class/drm/%s/device/device",entry->d_name)>=(int)sizeof file)continue;
  f=fopen(file,"r");if(!f)continue;
  if(fgets(buf,sizeof buf,f))device=(unsigned)strtoul(buf,NULL,0);
  fclose(f);
  /* Navi 22: 0x73df is shared by several board variants. */
  if(vendor==0x1002 && device==0x73df){
   snprintf(out,cap,"AMD Radeon RX 6700 series (Navi 22)");
   closedir(dir);return 1;
  }
 }
 closedir(dir);
#else
 (void)out;(void)cap;
#endif
 return 0;
}
static void gpu_short_uncached(char *out,size_t cap){
 /* Plain Termux has no desktop GL context and Android often denies direct
    GPU device access. Do not try desktop-only glxinfo/vulkaninfo/lspci there.
    Termux:X11 sessions with a display retain the normal detection path. */
 if(is_termux()&&!getenv("DISPLAY")&&!getenv("WAYLAND_DISPLAY")){
  snprintf(out,cap,"Unavailable (Android GPU access)");return;
 }
 if(gpu_drm_fast(out,cap))return;
 char line[1024]="",raw[512]="";
 /* Renderer can distinguish cards sharing the same PCI device ID. */
 command_first("LC_ALL=C glxinfo -B 2>/dev/null | grep -m1 'OpenGL renderer string:'",line,sizeof line);
 if(*line){
  char *p=strchr(line,':');
  if(p){p++;while(isspace((unsigned char)*p))p++;
   char *end=strstr(p," (");if(end)*end=0;
   if(strstr(p,"Radeon RX ") || strstr(p,"GeForce ") || strstr(p,"Arc ")){
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C vulkaninfo --summary 2>/dev/null | grep -m1 'deviceName[[:space:]]*='",line,sizeof line);
 if(*line){
  char *p=strchr(line,'=');if(p){p++;while(isspace((unsigned char)*p))p++;
   if(strstr(p,"Radeon RX ")||strstr(p,"GeForce ")||strstr(p,"Arc ")){
    char *end=strstr(p," (");if(end)*end=0;
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C lspci -mm 2>/dev/null | grep -Ei 'VGA compatible controller|3D controller|Display controller' | head -n 1",line,sizeof line);
 char *parts[8]={0};int n=0;
 for(char *p=line;*p&&n<8;){
  if(*p!='"'){p++;continue;}p++;parts[n++]=p;
  char *end=strchr(p,'"');if(!end)break;*end=0;p=end+1;
 }
 if(n>=3)snprintf(raw,sizeof raw,"%s",parts[2]);
 else if(n>=2)snprintf(raw,sizeof raw,"%s",parts[n-1]);
 else {snprintf(out,cap,"Unavailable (pciutils)");return;}
 /* Ambiguous PCI identifiers are displayed as a family, not a guessed SKU. */
 if(strstr(raw,"6700/6700 XT/6750 XT") || strstr(raw,"6800M/6850M XT")){
  snprintf(out,cap,"AMD Radeon RX 6700 series (Navi 22)");return;
 }
 const char *mark=strstr(raw,"[Radeon ");
 if(mark){mark++;char *end=strchr((char*)mark,']');if(end)*end=0;snprintf(out,cap,"AMD %s",mark);}
 else snprintf(out,cap,"%s",raw);
}
static void gpu_short(char *out,size_t cap){
 if(cache_read("gpu",out,cap,86400))return;
 gpu_short_uncached(out,cap);
 if(*out && !strstr(out,"Unavailable"))cache_write("gpu",out);
}
/* Shorten only the ambiguous GPU model, never the temperature suffix. */
static void fit_gpu(char *gpu,size_t cap,int max_visible){
 const char *suffix=strrchr(gpu,'(');
 if(!suffix || suffix==gpu || suffix[-1]!=' ')return;
 size_t base=(size_t)(suffix-gpu)-1;
 int suffix_width=0;
 for(const char *p=suffix;*p;){
  if(p[0]==27 && p[1]=='['){p+=2;while(*p && *p!='m')p++;if(*p)p++;}
  else {unsigned char c=(unsigned char)*p;p+=c>=240?4:c>=224?3:c>=192?2:1;suffix_width++;}
 }
 int keep=max_visible-suffix_width-1;
 if(keep<4)return;
 if((int)base<=keep)return;
 char result[512];
 int n=keep-3;
 if(n<1)return;
 snprintf(result,sizeof result,"%.*s... %s",n,gpu,suffix);
 snprintf(gpu,cap,"%.*s",(int)(cap-1),result);
}
/* Clip by terminal cell width, not UTF-8 byte length. Never split a codepoint
   or a CSI color sequence. Control characters from system metadata are dropped. */
static void clip_ansi(const char *src,char *dst,size_t cap,int limit){
 size_t i=0,j=0;int cells=0;
 mbstate_t state={0};
 while(src[i] && j+8<cap && cells<limit){
  if((unsigned char)src[i]==27){
   if(src[i+1]=='['){
    size_t start=i++;i++;
    while(src[i] && (unsigned char)src[i]>=0x20 && (unsigned char)src[i]<=0x3f)i++;
    if(src[i]=='m'){
     size_t n=++i-start;
     if(output_color && j+n+5<cap){memcpy(dst+j,src+start,n);j+=n;}
    }else if(src[i])i++;
   }else i++;
   continue;
  }
  wchar_t wc;size_t n=mbrtowc(&wc,src+i,MB_CUR_MAX,&state);
  if(n==(size_t)-1 || n==(size_t)-2 || n==0){memset(&state,0,sizeof state);i++;continue;}
  int width=wcwidth(wc);
  if(width<0){i+=n;continue;}
  if(cells+width>limit)break;
  if(j+n+5>=cap)break;
  memcpy(dst+j,src+i,n);j+=n;i+=n;cells+=width;
 }
 if(output_color&&j+4<cap){memcpy(dst+j,"\033[0m",4);j+=4;}
 dst[j]=0;
}


static void read_first(const char *path,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 fclose(f);
}
/* Snapshot volatile kernel values once per process so individual modules
   cannot repeatedly reopen the same /proc entries during a single render. */
static const char *nis_loadavg_snapshot(void){
 static char data[128];static int loaded=0;
 if(!loaded){read_first("/proc/loadavg",data,sizeof data);loaded=1;}
 return data;
}
static void meminfo_numbers(unsigned long long *total,unsigned long long *available){
 static unsigned long long snapshot_total=0,snapshot_available=0;
 static int loaded=0;
 if(!loaded){
  loaded=1;
  FILE *f=fopen("/proc/meminfo","r");
  if(f){
   char line[256];while(fgets(line,sizeof line,f)){
    unsigned long long n;
    if(line[0]=='M'&&!strncmp(line,"MemTotal:",9)&&sscanf(line+9,"%llu",&n)==1)snapshot_total=n;
    else if(line[0]=='M'&&!strncmp(line,"MemAvailable:",13)&&sscanf(line+13,"%llu",&n)==1)snapshot_available=n;
    if(snapshot_total&&snapshot_available)break;
   }
   fclose(f);
  }
 }
 *total=snapshot_total;*available=snapshot_available;
}
/* Additional modules use kernel files directly: no subprocesses, so custom
   module configurations keep the same fast startup characteristics. */
static unsigned long long read_ull_file(const char *path){
 char value[96]="";read_first(path,value,sizeof value);
 if(!*value)return 0;
 errno=0;char *end=NULL;unsigned long long result=strtoull(value,&end,10);
 return errno||end==value?0:result;
}
static void gpu_hwmon_value(const char *key,char *out,size_t cap){
 DIR *d=opendir("/sys/class/drm");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(strncmp(e->d_name,"card",4))continue;
  const char *suffix=e->d_name+4;
  if(!*suffix)continue;
  while(*suffix&&isdigit((unsigned char)*suffix))suffix++;
  if(*suffix)continue; /* exclude connectors such as card0-HDMI-A-1 */
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"/sys/class/drm/%s/device/%s",e->d_name,key)>=(int)sizeof path)continue;
  read_first(path,out,cap);
  if(*out)break;
 }
 closedir(d);
}
static void gpu_driver(char *out,size_t cap){
 DIR *d=opendir("/sys/class/drm");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  const char *suffix=e->d_name;
  if(strncmp(suffix,"card",4))continue;
  suffix+=4;if(!isdigit((unsigned char)*suffix))continue;
  while(isdigit((unsigned char)*suffix))suffix++;
  if(*suffix)continue;
  char path[PATH_MAX],target[PATH_MAX];
  if(snprintf(path,sizeof path,"/sys/class/drm/%s/device/driver",e->d_name)>=(int)sizeof path)continue;
  ssize_t n=readlink(path,target,sizeof target-1);
  if(n<=0)continue;
  target[n]=0;const char *last=strrchr(target,'/');
  snprintf(out,cap,"%.127s",last?last+1:target);break;
 }
 closedir(d);
}
static void battery_cycles(char *out,size_t cap){
 DIR *d=opendir("/sys/class/power_supply");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX],type[48]="";
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);
  read_first(path,type,sizeof type);if(strcmp(type,"Battery"))continue;
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/cycle_count",e->d_name);
  read_first(path,out,cap);if(*out)break;
 }
 closedir(d);
}
static void battery_health(char *out,size_t cap){
 DIR *d=opendir("/sys/class/power_supply");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX],type[64]="";
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);
  read_first(path,type,sizeof type);if(strcmp(type,"Battery"))continue;
  const char *parts[][2]={{"energy_full","energy_full_design"},{"charge_full","charge_full_design"}};
  for(size_t i=0;i<sizeof parts/sizeof parts[0];i++){
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/%s",e->d_name,parts[i][0]);
   unsigned long long full=read_ull_file(path);
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/%s",e->d_name,parts[i][1]);
   unsigned long long design=read_ull_file(path);
   if(full&&design){snprintf(out,cap,"%.0f%%",100.0*(double)full/design);break;}
  }
  if(*out)break;
 }
 closedir(d);
}
static void xdg_default(const char *key,const char *suffix,char *out,size_t cap){
 const char *e=getenv(key);if(e&&*e){snprintf(out,cap,"%s",e);return;}
 const char *home=getenv("HOME");if(home&&*home)snprintf(out,cap,"%s/%s",home,suffix);
}
static void os_release_version(char *out,size_t cap){
 FILE *f=fopen("/etc/os-release","r");if(!f)return;
 char line[512],version[256]="",id[128]="";
 while(fgets(line,sizeof line,f)){
  char *v=NULL;
  if(!strncmp(line,"VERSION_ID=",11))v=line+11;
  else if(!strncmp(line,"VERSION=",8)&&!*version)v=line+8;
  else if(!strncmp(line,"ID=",3)){
   v=line+3;size_t n=strcspn(v,"\r\n");v[n]=0;snprintf(id,sizeof id,"%.127s",v);continue;
  }
  if(v){size_t n=strcspn(v,"\r\n");v[n]=0;if(*v=='\"'){v++;n=strlen(v);if(n&&v[n-1]=='\"')v[n-1]=0;}if(*v)snprintf(version,sizeof version,"%.255s",v);}
 }fclose(f);
 if(*version)snprintf(out,cap,"%s",version);
 else if(!strcmp(id,"arch")||!strcmp(id,"artix")||!strcmp(id,"gentoo"))snprintf(out,cap,"Rolling Release");
}
static void count_file_lines(const char *path,char *out,size_t cap){
 FILE *f=fopen(path,"r");if(!f)return;unsigned long n=0;int c;
 while((c=fgetc(f))!=EOF)if(c=='\n')n++;
 fclose(f);snprintf(out,cap,"%lu",n);
}
static void proc_status_threads(char *out,size_t cap){
 FILE *f=fopen("/proc/self/status","r");if(!f)return;char line[256];
 while(fgets(line,sizeof line,f))if(!strncmp(line,"Threads:",8)){unsigned n;if(sscanf(line+8,"%u",&n)==1)snprintf(out,cap,"%u",n);break;}
 fclose(f);
}
static void root_fs_type(char *out,size_t cap){
 FILE *f=fopen("/proc/self/mountinfo","r");if(!f)return;
 char line[4096];while(fgets(line,sizeof line,f)){
  char *p=line;int field=0;char *mount=NULL;
  while(*p&&field<5){while(*p==' ')p++;char *start=p;while(*p&&*p!=' ')p++;field++;if(field==5)mount=start;if(*p)*p++=0;}
  if(mount&&strcmp(mount,"/")==0){char *sep=strstr(p," - ");if(!sep)continue;sep+=3;size_t n=strcspn(sep," ");if(n>=cap)n=cap-1;memcpy(out,sep,n);out[n]=0;break;}
 }fclose(f);
}
static void proc_cpuinfo_value(const char *first,const char *second,char *out,size_t cap){
 FILE *f=fopen("/proc/cpuinfo","r");if(!f)return;
 char line[512];
 while(fgets(line,sizeof line,f)){
  char *colon=strchr(line,':');if(!colon)continue;
  *colon=0;trim(line);
  if(strcmp(line,first)&&(!second||strcmp(line,second)))continue;
  char *value=colon+1;while(isspace((unsigned char)*value))value++;
  snprintf(out,cap,"%s",value);trim(out);break;
 }
 fclose(f);
}
static unsigned count_named_entries(const char *directory,const char *prefix){
 DIR *d=opendir(directory);if(!d)return 0;
 size_t n=strlen(prefix);unsigned count=0;struct dirent *e;
 while((e=readdir(d)))if(!strncmp(e->d_name,prefix,n))count++;
 closedir(d);return count;
}
static void network_interfaces(char *out,size_t cap){
 DIR *d=opendir("/sys/class/net");if(!d)return;
 struct dirent *e;size_t pos=0;
 while((e=readdir(d))){if(e->d_name[0]=='.')continue;
  size_t n=strlen(e->d_name);
  if(pos+n+2>=cap)break;
  if(pos)out[pos++]=',';
  memcpy(out+pos,e->d_name,n);pos+=n;out[pos]=0;
 }
 closedir(d);
}
static void hwmon_fans(char *out,size_t cap){
 DIR *d=opendir("/sys/class/hwmon");if(!d)return;
 struct dirent *e;unsigned count=0;
 while((e=readdir(d))){if(strncmp(e->d_name,"hwmon",5))continue;
  char path[PATH_MAX];snprintf(path,sizeof path,"/sys/class/hwmon/%s",e->d_name);
  DIR *sub=opendir(path);if(!sub)continue;
  struct dirent *file;
  while((file=readdir(sub))){
   if(strncmp(file->d_name,"fan",3))continue;
   const char *p=file->d_name+3;while(isdigit((unsigned char)*p))p++;
   if(p>file->d_name+3&&!strcmp(p,"_input"))count++;
  }
  closedir(sub);
 }
 closedir(d);snprintf(out,cap,"%u",count);
}
static void proc_filesystems(char *out,size_t cap){
 FILE *f=fopen("/proc/filesystems","r");if(!f)return;
 char line[160];size_t len=0;
 while(fgets(line,sizeof line,f)){
  char *name=line;while(isspace((unsigned char)*name))name++;
  if(!strncmp(name,"nodev",5)&&isspace((unsigned char)name[5])){name+=5;while(isspace((unsigned char)*name))name++;}
  trim(name);size_t n=strlen(name);if(!n||len+n+2>=cap)continue;
  if(len)out[len++]=',';
  memcpy(out+len,name,n);len+=n;out[len]=0;
 }
 fclose(f);
}
static void boot_date(char *out,size_t cap){
 FILE *f=fopen("/proc/stat","r");if(!f)return;
 char line[192];
 while(fgets(line,sizeof line,f)){
  long long epoch=0;if(sscanf(line,"btime %lld",&epoch)==1&&epoch>0){
   time_t t=(time_t)epoch;struct tm tmv;
   if(localtime_r(&t,&tmv))strftime(out,cap,"%Y-%m-%d %H:%M:%S",&tmv);
   break;
  }
 }
 fclose(f);
}
static int command_available(const char *name){
 const char *path=getenv("PATH");if(!path||!*path)return 0;
 size_t nlen=strlen(name);if(!nlen||strchr(name,'/'))return 0;
 const char *p=path;
 while(*p){
  const char *end=strchr(p,':');if(!end)end=p+strlen(p);
  size_t dlen=(size_t)(end-p);char full[PATH_MAX];
  if(dlen&&dlen+nlen+2<sizeof full){
   memcpy(full,p,dlen);full[dlen]='/';memcpy(full+dlen+1,name,nlen+1);
   if(access(full,X_OK)==0)return 1;
  }
  if(!*end)break;
  p=end+1;
 }
 return 0;
}
/* Termux:API may be absent, denied or stalled. Run it directly (no shell,
   grep or sed) and never block the shell indefinitely waiting for Android. */
static int termux_battery_percentage(char *out,size_t cap){
 if(!is_termux()||!command_available("termux-battery-status"))return 0;
 int fds[2];if(pipe(fds)!=0)return 0;
 pid_t pid=fork();
 if(pid<0){close(fds[0]);close(fds[1]);return 0;}
 if(pid==0){
  close(fds[0]);setpgid(0,0);
  if(dup2(fds[1],STDOUT_FILENO)<0)_exit(127);
  close(fds[1]);
  int null=open("/dev/null",O_WRONLY);
  if(null>=0){dup2(null,STDERR_FILENO);close(null);}
  execlp("termux-battery-status","termux-battery-status",(char*)NULL);
  _exit(127);
 }
 close(fds[1]);
 char json[4096];size_t used=0;int timed_out=0;
 struct timespec start={0},current={0};clock_gettime(CLOCK_MONOTONIC,&start);
 for(;;){
  clock_gettime(CLOCK_MONOTONIC,&current);
  long elapsed=(current.tv_sec-start.tv_sec)*1000L+
               (current.tv_nsec-start.tv_nsec)/1000000L;
  int remaining=1800-(int)elapsed;
  if(remaining<=0){timed_out=1;break;}
  struct pollfd pfd={fds[0],POLLIN|POLLHUP,0};
  int ready=poll(&pfd,1,remaining);
  if(ready<0){if(errno==EINTR)continue;timed_out=1;break;}
  if(ready==0){timed_out=1;break;}
  if(used>=sizeof json-1){timed_out=1;break;}
  ssize_t n=read(fds[0],json+used,sizeof json-1-used);
  if(n<0){if(errno==EINTR)continue;timed_out=1;break;}
  if(n==0)break;
  used+=(size_t)n;
 }
 close(fds[0]);json[used]=0;
 int status=0;pid_t waited=waitpid(pid,&status,WNOHANG);
 /* The helper may close stdout just before exiting. Give it a very short
    grace period instead of racing to kill a healthy Termux:API response. */
 if(waited==0&&!timed_out){
  for(int retry=0;retry<15&&waited==0;retry++){
   struct timespec pause={0,1000000L};nanosleep(&pause,NULL);
   waited=waitpid(pid,&status,WNOHANG);
  }
 }
 if(waited==0){
  kill(-pid,SIGKILL);kill(pid,SIGKILL);
  do{waited=waitpid(pid,&status,0);}while(waited<0&&errno==EINTR);
 }
 if(timed_out||waited!=pid||!WIFEXITED(status)||WEXITSTATUS(status)!=0)return 0;
 char *p=strstr(json,"\"percentage\"");if(!p)return 0;
 p=strchr(p,':');if(!p)return 0;
 p++;while(isspace((unsigned char)*p))p++;
 if(*p<'0'||*p>'9')return 0;
 char *end=NULL;long pct=strtol(p,&end,10);
 if(end==p||pct<0||pct>100)return 0;
 snprintf(out,cap,"%ld%%",pct);return 1;
}
static void optional_module(const char *name){
 if(!module_enabled(name))return;
 char v[512]="",p[512]="";
 if(!strcmp(name,"ramtype")||!strcmp(name,"ramfrequency")||
    !strcmp(name,"ramslots")||!strcmp(name,"rammodules")||
    !strcmp(name,"rammanufacturer")||!strcmp(name,"rampart")){
  char cpu_model[256]="";cpuinfo(cpu_model,sizeof cpu_model);
  const NisRamHardware *hw=nis_ram_hardware(cpu_model);
  if(!strcmp(name,"ramtype")&&*hw->type)
   snprintf(v,sizeof v,"%s%s",hw->type,detailed_output&&strstr(hw->source,"estimate")?" (platform estimate)":"");
  else if(!strcmp(name,"ramfrequency")&&hw->speed_mts)
   snprintf(v,sizeof v,"%u MT/s",hw->speed_mts);
  else if(!strcmp(name,"ramslots")&&hw->slots)
   snprintf(v,sizeof v,"%u",hw->slots);
  else if(!strcmp(name,"rammodules")&&hw->modules)
   snprintf(v,sizeof v,"%u",hw->modules);
  else if(!strcmp(name,"rammanufacturer")&&*hw->manufacturer)
   snprintf(v,sizeof v,"%s",hw->manufacturer);
  else if(!strcmp(name,"rampart")&&*hw->part)
   snprintf(v,sizeof v,"%s",hw->part);
 }
 else if(!strcmp(name,"diskdevice")||!strcmp(name,"homedevice")||
         !strcmp(name,"homefilesystem")||!strcmp(name,"diskmountopts")||
         !strcmp(name,"diskinodes")||!strcmp(name,"homeinodes")){
  const int home=!strcmp(name,"homedevice")||!strcmp(name,"homefilesystem")||
                 !strcmp(name,"homeinodes");
  const char *path=home?env_or("HOME","/"):"/";
  if(!strcmp(name,"diskinodes")||!strcmp(name,"homeinodes"))
   nis_mount_inode_usage(path,v,sizeof v);
  else{
   NisMountHardware mount;
   if(nis_mount_hardware(path,&mount)){
    if(!strcmp(name,"diskdevice")||!strcmp(name,"homedevice"))
     snprintf(v,sizeof v,"%s",mount.source);
    else if(!strcmp(name,"homefilesystem"))
     snprintf(v,sizeof v,"%s",mount.filesystem);
    else if(!strcmp(name,"diskmountopts"))
     snprintf(v,sizeof v,"%s",mount.options);
   }
  }
 }
 else if(!strcmp(name,"monitor")||!strcmp(name,"displayconnector")||
    !strcmp(name,"displaysize")||!strcmp(name,"monitorcount")||
    !strcmp(name,"refreshrate")){
  NisMonitor mon;nis_monitor_probe(&mon);
  if(!strcmp(name,"monitor"))nis_monitor_label(&mon,v,sizeof v);
  else if(!strcmp(name,"displayconnector")&&*mon.connector)
   snprintf(v,sizeof v,"%s",mon.connector);
  else if(!strcmp(name,"displaysize")&&mon.width_mm&&mon.height_mm)
   snprintf(v,sizeof v,"%.1f x %.1f cm",mon.width_mm/10.0,mon.height_mm/10.0);
  else if(!strcmp(name,"monitorcount")&&mon.connected)
   snprintf(v,sizeof v,"%u",mon.connected);
  else if(!strcmp(name,"refreshrate")){
   char display[256]="";kde_display(display,sizeof display);
   const char *h=strstr(display," @ ");
   if(h){double rate=atof(h+3);
    if(rate>=10.0&&rate<=1000.0)
     snprintf(v,sizeof v,"%.2f Hz%s",rate,strstr(display,"(preferred)")?" (preferred)":"");
   }
  }
 }
 else if(!strcmp(name,"board")){motherboard(v,sizeof v);}
 else if(!strcmp(name,"bios")){read_first("/sys/class/dmi/id/bios_version",v,sizeof v);}
 else if(!strcmp(name,"chassis")){read_first("/sys/class/dmi/id/chassis_type",v,sizeof v);if(!strcmp(v,"3"))snprintf(v,sizeof v,"Desktop");else if(!strcmp(v,"9")||!strcmp(v,"10")||!strcmp(v,"14"))snprintf(v,sizeof v,"Laptop");else if(!strcmp(v,"4"))snprintf(v,sizeof v,"Low Profile Desktop");else if(!strcmp(v,"6"))snprintf(v,sizeof v,"Mini Tower");else if(!strcmp(v,"7"))snprintf(v,sizeof v,"Tower");}
 else if(!strcmp(name,"shell")){snprintf(v,sizeof v,"%s",env_or("SHELL","Unknown"));}
 else if(!strcmp(name,"processes")){struct sysinfo si;if(!sysinfo(&si))snprintf(v,sizeof v,"%u",si.procs);}
 else if(!strcmp(name,"loadavg")){snprintf(v,sizeof v,"%s",nis_loadavg_snapshot());char *q=strrchr(v,' ');if(q)*q=0;}
 else if(!strcmp(name,"load1")||!strcmp(name,"load5")||!strcmp(name,"load15")){
  const char *load=nis_loadavg_snapshot();
  if(*load){double a,b,d;if(sscanf(load,"%lf %lf %lf",&a,&b,&d)==3){
   double n=!strcmp(name,"load1")?a:(!strcmp(name,"load5")?b:d);
   snprintf(v,sizeof v,"%.2f",n);
  }}
 }
 else if(!strcmp(name,"datetime")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%Y-%m-%d %H:%M:%S",&tmv);}
 else if(!strcmp(name,"timezone")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%Z",&tmv);}
 else if(!strcmp(name,"hostname")){gethostname(v,sizeof v);v[sizeof v-1]=0;}
 else if(!strcmp(name,"architecture")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"cpucores")){long n=sysconf(_SC_NPROCESSORS_ONLN);if(n>0)snprintf(v,sizeof v,"%ld",n);}
 else if(!strcmp(name,"cpufreq")){unsigned long long khz=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");if(khz)snprintf(v,sizeof v,"%.2f GHz",khz/1000000.0);}
 else if(!strcmp(name,"cpufreqmin")||!strcmp(name,"cpufreqmax")){
  const char *file=!strcmp(name,"cpufreqmin")?"/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq":"/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq";
  unsigned long long khz=read_ull_file(file);if(khz)snprintf(v,sizeof v,"%.2f GHz",khz/1000000.0);
 }
 else if(!strcmp(name,"cpugovernor")){read_first("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor",v,sizeof v);}
 else if(!strcmp(name,"gpuusage")){gpu_hwmon_value("gpu_busy_percent",v,sizeof v);if(*v){size_t n=strlen(v);snprintf(v+n,sizeof v-n,"%%");}}
 else if(!strcmp(name,"gpudriver")){gpu_driver(v,sizeof v);}
 else if(!strcmp(name,"gpuvendor")){
  char raw[64]="";gpu_hwmon_value("vendor",raw,sizeof raw);
  if(!strcmp(raw,"0x1002"))snprintf(v,sizeof v,"AMD");
  else if(!strcmp(raw,"0x10de"))snprintf(v,sizeof v,"NVIDIA");
  else if(!strcmp(raw,"0x8086"))snprintf(v,sizeof v,"Intel");
  else if(*raw)snprintf(v,sizeof v,"%s",raw);
 }
 else if(!strcmp(name,"gpuvram")||!strcmp(name,"gpumemoryused")){
  char raw[96]="";gpu_hwmon_value(!strcmp(name,"gpuvram")?"mem_info_vram_total":"mem_info_vram_used",raw,sizeof raw);
  unsigned long long bytes=strtoull(raw,NULL,10);if(bytes)snprintf(v,sizeof v,"%.2f GiB",(double)bytes/1073741824.0);
 }
 else if(!strcmp(name,"memcached")){
  FILE *f=fopen("/proc/meminfo","r");if(f){char line[256];unsigned long long n;
   while(fgets(line,sizeof line,f))if(sscanf(line,"Cached: %llu",&n)==1){snprintf(v,sizeof v,"%.2f GiB",(double)n/1048576.0);break;}
   fclose(f);
  }
 }
 else if(!strcmp(name,"cpul3")){
  for(int i=0;i<10;i++){
   char path[160],level[32]="";
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/level",i);
   read_first(path,level,sizeof level);
   if(strcmp(level,"3"))continue;
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/size",i);
   read_first(path,v,sizeof v);if(*v)break;
  }
 }
 else if(!strcmp(name,"memorypressure")){
  char line[256]="";read_first("/proc/pressure/memory",line,sizeof line);
  char *avg=strstr(line,"avg10=");
  if(avg){double p=0;if(sscanf(avg,"avg10=%lf",&p)==1)snprintf(v,sizeof v,"%.2f%% (10s)",p);}
 }
 else if(!strcmp(name,"batterycycles")){battery_cycles(v,sizeof v);}
 else if(!strcmp(name,"biosdate")){read_first("/sys/class/dmi/id/bios_date",v,sizeof v);}
 else if(!strcmp(name,"batteryhealth")){battery_health(v,sizeof v);}
 else if(!strcmp(name,"androidbrand")){property("ro.product.brand",v,sizeof v);}
 else if(!strcmp(name,"androidhardware")){property("ro.hardware",v,sizeof v);}
 else if(!strcmp(name,"battery")){
  DIR *d=opendir("/sys/class/power_supply");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],typ[80]="",pct[80]="";
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);read_first(path,typ,sizeof typ);
   if(strcmp(typ,"Battery"))continue;
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/capacity",e->d_name);read_first(path,pct,sizeof pct);
   if(*pct){snprintf(v,sizeof v,"%s%%",pct);break;}
  }closedir(d);}
  /* Android often hides /sys/class/power_supply from unprivileged apps.
     Termux:API is an optional fallback, never required on desktop. */
  if(!*v && is_termux())termux_battery_percentage(v,sizeof v);
 }
 else if(!strcmp(name,"brightness")){
  DIR *d=opendir("/sys/class/backlight");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],cur[80]="",max[80]="";
   snprintf(path,sizeof path,"/sys/class/backlight/%s/brightness",e->d_name);read_first(path,cur,sizeof cur);
   snprintf(path,sizeof path,"/sys/class/backlight/%s/max_brightness",e->d_name);read_first(path,max,sizeof max);
   long a=atol(cur),b=atol(max);if(b>0){snprintf(v,sizeof v,"%ld%%",a*100/b);break;}
  }closedir(d);}
 }
 else if(!strcmp(name,"bluetooth")){command_first("bluetoothctl list 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"network")){command_first("ip route show default 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"diskusage")){disk_path("/",v,sizeof v);}
 else if(!strcmp(name,"diskfilesystem")){root_fs_type(v,sizeof v);}
 else if(!strcmp(name,"termux")){if(is_termux())snprintf(v,sizeof v,"Termux");}
 else if(!strcmp(name,"androidversion")){property("ro.build.version.release",v,sizeof v);}
 else if(!strcmp(name,"androidsdk")){property("ro.build.version.sdk",v,sizeof v);}
 else if(!strcmp(name,"androidmanufacturer")){property("ro.product.manufacturer",v,sizeof v);}
 else if(!strcmp(name,"androidmodel")){property("ro.product.model",v,sizeof v);}
 else if(!strcmp(name,"androidsoc")){property("ro.soc.model",v,sizeof v);}
 else if(!strcmp(name,"bootid")){read_first("/proc/sys/kernel/random/boot_id",v,sizeof v);}
 else if(!strcmp(name,"virtualization")){command_first("systemd-detect-virt 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"editor")){snprintf(v,sizeof v,"%s",env_or("EDITOR","Unknown"));}
 else if(!strcmp(name,"users")){command_first("who 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"language")){snprintf(v,sizeof v,"%s",env_or("LANG","Unknown"));}

 else if(!strcmp(name,"distro")){osname(v,sizeof v);}
 else if(!strcmp(name,"osversion")){os_release_version(v,sizeof v);}
 else if(!strcmp(name,"kernelversion")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.release);}
 else if(!strcmp(name,"kernelarch")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"machineid")){read_first("/etc/machine-id",v,sizeof v);}
 else if(!strcmp(name,"cpuvendor")){proc_cpuinfo_value("vendor_id","CPU implementer",v,sizeof v);}
 else if(!strcmp(name,"cpumodel")){cpuinfo(v,sizeof v);}
 else if(!strcmp(name,"cpubogomips")){proc_cpuinfo_value("bogomips",NULL,v,sizeof v);}
 else if(!strcmp(name,"cpuload")){snprintf(v,sizeof v,"%s",nis_loadavg_snapshot());char *q=strchr(v,' ');if(q){q=strchr(q+1,' ');if(q){q=strchr(q+1,' ');if(q)*q=0;}}}
 else if(!strcmp(name,"memtotal")||!strcmp(name,"memavailable")||!strcmp(name,"swaptotal")||!strcmp(name,"swapfree")){
  struct sysinfo si;if(!sysinfo(&si)){unsigned long long n=0;
   if(!strcmp(name,"memtotal"))n=(unsigned long long)si.totalram*si.mem_unit;
   if(!strcmp(name,"memavailable")){unsigned long long a=0,t=0;meminfo_numbers(&t,&a);n=a?a*1024ULL:(unsigned long long)si.freeram*si.mem_unit;}
   if(!strcmp(name,"swaptotal"))n=(unsigned long long)si.totalswap*si.mem_unit;
   if(!strcmp(name,"swapfree"))n=(unsigned long long)si.freeswap*si.mem_unit;
   snprintf(v,sizeof v,"%.2f GiB",(double)n/1073741824.0);}}
 else if(!strcmp(name,"diskfree")||!strcmp(name,"disktotal")||!strcmp(name,"diskpercent")){
  struct statvfs fs;if(!statvfs("/",&fs)){double total=(double)fs.f_blocks*fs.f_frsize,freeb=(double)fs.f_bavail*fs.f_frsize;
   if(!strcmp(name,"diskfree"))snprintf(v,sizeof v,"%.2f GiB",freeb/1073741824.0);
   if(!strcmp(name,"disktotal"))snprintf(v,sizeof v,"%.2f GiB",total/1073741824.0);
   if(!strcmp(name,"diskpercent")&&total>0)snprintf(v,sizeof v,"%.1f%%",(total-freeb)*100.0/total);}}
 else if(!strcmp(name,"rootfs")){root_fs_type(v,sizeof v);}
 else if(!strcmp(name,"mounts")){count_file_lines("/proc/mounts",v,sizeof v);}
 else if(!strcmp(name,"interfaces")){network_interfaces(v,sizeof v);}
 else if(!strcmp(name,"ipv4")){command_first("ip -4 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"ipv6")){command_first("ip -6 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"gateway")){command_first("ip route show default 2>/dev/null | awk 'NR==1{print $3}'",v,sizeof v);}
 else if(!strcmp(name,"dns")){command_first("awk '/^nameserver/{print $2;exit}' /etc/resolv.conf 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"username")){snprintf(v,sizeof v,"%s",env_or("USER","Unknown"));}
 else if(!strcmp(name,"uid")){snprintf(v,sizeof v,"%lu",(unsigned long)getuid());}
 else if(!strcmp(name,"gid")){snprintf(v,sizeof v,"%lu",(unsigned long)getgid());}
 else if(!strcmp(name,"home")){snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"path")){snprintf(v,sizeof v,"%.200s",env_or("PATH","Unknown"));}
 else if(!strcmp(name,"shellversion")){command_first("${SHELL:-/bin/sh} --version 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"terminaltype")){snprintf(v,sizeof v,"%s",env_or("TERM","Unknown"));}
 else if(!strcmp(name,"displayserver")){snprintf(v,sizeof v,"%s",env_or("XDG_SESSION_TYPE","Unknown"));}
 else if(!strcmp(name,"sessiondesktop")){snprintf(v,sizeof v,"%s",env_or("XDG_CURRENT_DESKTOP","Unknown"));}
 else if(!strcmp(name,"xdgconfig")){xdg_default("XDG_CONFIG_HOME",".config",v,sizeof v);}
 else if(!strcmp(name,"xdgcache")){xdg_default("XDG_CACHE_HOME",".cache",v,sizeof v);}
 else if(!strcmp(name,"xdgdata")){xdg_default("XDG_DATA_HOME",".local/share",v,sizeof v);}
 else if(!strcmp(name,"pid")){snprintf(v,sizeof v,"%ld",(long)getpid());}
 else if(!strcmp(name,"parentpid")){snprintf(v,sizeof v,"%ld",(long)getppid());}
 else if(!strcmp(name,"threads")){proc_status_threads(v,sizeof v);}
 else if(!strcmp(name,"systemd")){if(access("/run/systemd/system",F_OK)==0)snprintf(v,sizeof v,"running");}
 else if(!strcmp(name,"init")){read_first("/proc/1/comm",v,sizeof v);}
 else if(!strcmp(name,"cgroup")){read_first("/proc/self/cgroup",v,sizeof v);}
 else if(!strcmp(name,"entropy")){read_first("/proc/sys/kernel/random/entropy_avail",v,sizeof v);}
 else if(!strcmp(name,"thermalzones")){snprintf(v,sizeof v,"%u",count_named_entries("/sys/class/thermal","thermal_zone"));}
 else if(!strcmp(name,"fans")){hwmon_fans(v,sizeof v);}
 else if(!strcmp(name,"batterycount")){snprintf(v,sizeof v,"%u",count_named_entries("/sys/class/power_supply","BAT"));}
 else if(!strcmp(name,"powerstate")){command_first("cat /sys/class/power_supply/BAT0/status 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"androiddevice")){property("ro.product.device",v,sizeof v);}
 else if(!strcmp(name,"androidboard")){property("ro.product.board",v,sizeof v);}
 else if(!strcmp(name,"androidfingerprint")){property("ro.build.fingerprint",v,sizeof v);}
 else if(!strcmp(name,"androidsecuritypatch")){property("ro.build.version.security_patch",v,sizeof v);}
 else if(!strcmp(name,"termuxprefix")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("PREFIX","Unknown"));}
 else if(!strcmp(name,"termuxhome")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"timezoneoffset")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%z",&tmv);}
 else if(!strcmp(name,"epoch")){snprintf(v,sizeof v,"%lld",(long long)time(NULL));}
 else if(!strcmp(name,"week")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%V",&tmv);}
 else if(!strcmp(name,"dayofyear")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%j",&tmv);}
 else if(!strcmp(name,"bootdate")){boot_date(v,sizeof v);}
 else if(!strcmp(name,"procversion")){read_first("/proc/version",v,sizeof v);}
 else if(!strcmp(name,"filesystems")){proc_filesystems(v,sizeof v);}
 else if(!strcmp(name,"environment")){snprintf(v,sizeof v,"%s",is_termux()?"Termux":"Linux");}
 else if(!strcmp(name,"cpuonline")||!strcmp(name,"cpuconfigured")){
  long n=sysconf(!strcmp(name,"cpuonline")?_SC_NPROCESSORS_ONLN:_SC_NPROCESSORS_CONF);
  if(n>0)snprintf(v,sizeof v,"%ld",n);
 }
 else if(!strcmp(name,"procsrunning")||!strcmp(name,"procstotal")||!strcmp(name,"loadtasks")){
  const char *load=nis_loadavg_snapshot();
  if(*load){char line[128];snprintf(line,sizeof line,"%s",load);{
   char *p=strchr(line,'/');
   if(p){char *a=p;while(a>line&&a[-1]>='0'&&a[-1]<='9')a--;
    if(!strcmp(name,"loadtasks"))snprintf(v,sizeof v,"%.*s",(int)(strchr(p,' ')?(size_t)(strchr(p,' ')-a):strlen(a)),a);
    else if(!strcmp(name,"procsrunning"))snprintf(v,sizeof v,"%.*s",(int)(p-a),a);
    else {p++;size_t n=0;while(p[n]>='0'&&p[n]<='9')n++;snprintf(v,sizeof v,"%.*s",(int)n,p);}
   }
  }}
 }
 else if(!strcmp(name,"memused")||!strcmp(name,"mempercent")){
  unsigned long long total=0,avail=0;meminfo_numbers(&total,&avail);
  if(total){double used=(double)(total-avail);
   if(!strcmp(name,"memused"))snprintf(v,sizeof v,"%.2f GiB",used/1048576.0);
   else snprintf(v,sizeof v,"%.1f%%",100.0*used/total);
  }
 }
 else if(!strcmp(name,"diskavailable")){
  struct statvfs fs;if(!statvfs("/",&fs))snprintf(v,sizeof v,"%.2f GiB",(double)fs.f_bavail*fs.f_frsize/1073741824.0);
 }
 else if(!strcmp(name,"uptimeseconds")||!strcmp(name,"bootepoch")){
  struct sysinfo si;if(!sysinfo(&si)){
   if(!strcmp(name,"uptimeseconds"))snprintf(v,sizeof v,"%ld",si.uptime);
   else snprintf(v,sizeof v,"%lld",(long long)time(NULL)-(long long)si.uptime);
  }
 }
 else if(!strcmp(name,"kernelhostname")){if(gethostname(v,sizeof v))v[0]=0;v[sizeof v-1]=0;}
 else if(!strcmp(name,"systemhz")){long n=sysconf(_SC_CLK_TCK);if(n>0)snprintf(v,sizeof v,"%ld Hz",n);}

 if(detailed_output&&*v){
  size_t len=strlen(v);
  if(!strcmp(name,"cpucores")){
   long configured=sysconf(_SC_NPROCESSORS_CONF);
   if(configured>0&&len+42<sizeof v)
    snprintf(v+len,sizeof v-len," online / %ld configured",configured);
  }else if(!strcmp(name,"processes")){
   char load[128]="";snprintf(load,sizeof load,"%s",nis_loadavg_snapshot());
   char *slash=strchr(load,'/');
   if(slash){char *start=slash;while(start>load&&isdigit((unsigned char)start[-1]))start--;
    if(start<slash&&len+45<sizeof v)
     snprintf(v+len,sizeof v-len," (%.*s running)",(int)(slash-start),start);
   }
  }else if(!strcmp(name,"load1")){
   double a=0,b=0,c=0;const char *load=nis_loadavg_snapshot();
   if(*load){if(sscanf(load,"%lf %lf %lf",&a,&b,&c)==3&&len+48<sizeof v)
     snprintf(v+len,sizeof v-len," | 5m %.2f, 15m %.2f",b,c);
   }
  }else if(!strcmp(name,"cpufreq")){
   char governor[48]="";
   read_first("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor",governor,sizeof governor);
   if(*governor&&len+strlen(governor)+4<sizeof v)
    snprintf(v+len,sizeof v-len," (%s)",governor);
  }else if(!strcmp(name,"battery")){
   char status[80]="";read_first("/sys/class/power_supply/BAT0/status",status,sizeof status);
   if(*status&&len+strlen(status)+4<sizeof v)
    snprintf(v+len,sizeof v-len," (%s)",status);
  }else if(!strcmp(name,"bios")){
   char date[64]="";read_first("/sys/class/dmi/id/bios_date",date,sizeof date);
   if(*date&&len+strlen(date)+4<sizeof v)
    snprintf(v+len,sizeof v-len," (%s)",date);
  }else if(!strcmp(name,"diskusage")){
   char fs[64]="";root_fs_type(fs,sizeof fs);
   if(*fs&&len+strlen(fs)+4<sizeof v)snprintf(v+len,sizeof v-len," [%s]",fs);
  }
 }

 if(*v && strcmp(v,"Unknown")){
  const char *label=name;
  if(!selected_modules){
   if(!strcmp(name,"cpucores"))label="CPU Cores";
   else if(!strcmp(name,"processes"))label="Processes";
   else if(!strcmp(name,"load1"))label="Load (1m)";
  }
  snprintf(p,sizeof p,"%s:",label);int prev=ninfo;add(name,p,v);if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);}
}

static void reorder_info(void){
 /* Default visual grouping: CPU metrics directly below the CPU line.
    User-defined module order always takes precedence. */
 if(!selected_modules){
  int cpu_index=-1;
  for(int i=0;i<ninfo;i++)if(!strcmp(info_id[i],"cpu")){cpu_index=i;break;}
  if(cpu_index>=0){
   const char *near_cpu[]={"cpucores","processes"};
   int dest=cpu_index+1;
   for(size_t k=0;k<sizeof near_cpu/sizeof near_cpu[0];k++){
    for(int j=dest;j<ninfo;j++)if(!strcmp(info_id[j],near_cpu[k])){
     char saved[512],saved_value[512],saved_id[64];
     memcpy(saved,info[j],sizeof saved);
     if(cfg_output_json)memcpy(saved_value,info_value[j],sizeof saved_value);
     memcpy(saved_id,info_id[j],sizeof saved_id);
     for(int t=j;t>dest;t--){
      memcpy(info[t],info[t-1],sizeof info[t]);
      if(cfg_output_json)memcpy(info_value[t],info_value[t-1],sizeof info_value[t]);
      memcpy(info_id[t],info_id[t-1],sizeof info_id[t]);
     }
     memcpy(info[dest],saved,sizeof saved);
     if(cfg_output_json)memcpy(info_value[dest],saved_value,sizeof saved_value);
     memcpy(info_id[dest],saved_id,sizeof saved_id);
     dest++;break;
    }
   }
  }
  /* Put Load (1m) at the very bottom of the default info list,
     after Locale on desktop and after phone details in Termux. */
  for(int j=0;j<ninfo;j++)if(!strcmp(info_id[j],"load1")){
   char saved[512],saved_value[512],saved_id[64];
   memcpy(saved,info[j],sizeof saved);
   if(cfg_output_json)memcpy(saved_value,info_value[j],sizeof saved_value);
   memcpy(saved_id,info_id[j],sizeof saved_id);
   for(int t=j;t<ninfo-1;t++){
    memcpy(info[t],info[t+1],sizeof info[t]);
    if(cfg_output_json)memcpy(info_value[t],info_value[t+1],sizeof info_value[t]);
    memcpy(info_id[t],info_id[t+1],sizeof info_id[t]);
   }
   memcpy(info[ninfo-1],saved,sizeof saved);
   if(cfg_output_json)memcpy(info_value[ninfo-1],saved_value,sizeof saved_value);
   memcpy(info_id[ninfo-1],saved_id,sizeof saved_id);
   break;
  }
  return;
 }
 /* CLI and preset selection have the same ordering guarantee as config modules. */
 const char *order=selected_modules;
 if(!order||!*order)return;
 int dest=0;
 char copy[sizeof cfg_order];snprintf(copy,sizeof copy,"%s",order);
 for(char *name=strtok(copy,":");name;name=strtok(NULL,":")){
  for(int i=dest;i<ninfo;i++)if(!strcmp(name,info_id[i])){
   char saved[512],saved_value[512],saved_id[64];
   memcpy(saved,info[i],sizeof saved);
   if(cfg_output_json)memcpy(saved_value,info_value[i],sizeof saved_value);
   memcpy(saved_id,info_id[i],sizeof saved_id);
   for(int j=i;j>dest;j--){
    memcpy(info[j],info[j-1],sizeof info[j]);
    if(cfg_output_json)memcpy(info_value[j],info_value[j-1],sizeof info_value[j]);
    memcpy(info_id[j],info_id[j-1],sizeof info_id[j]);
   }
   memcpy(info[dest],saved,sizeof saved);
   if(cfg_output_json)memcpy(info_value[dest],saved_value,sizeof saved_value);
   memcpy(info_id[dest],saved_id,sizeof saved_id);
   dest++;break;
  }
 }
}
static void nis_json_string(const char *s){
 putchar('"');
 for(const unsigned char *p=(const unsigned char *)s;*p;p++){
  unsigned char c=*p;
  if(c=='"'||c=='\\'){putchar('\\');putchar(c);}
  else if(c<32||c==127)printf("\\u%04x",(unsigned)c);
  else putchar(c);
 }
 putchar('"');
}
/* A single JSON object maps canonical module IDs to their raw values. System
   metadata may include ANSI/status escapes: sanitize it before serialization.
   No logo, terminal controls or stray blank lines appear in this format. */
static void nis_json_output(void){
 puts("{");
 for(int i=0;i<ninfo;i++){
  char clean[1024];
  clip_ansi(info_value[i],clean,sizeof clean,INT_MAX/2);
  fputs("  ",stdout);
  nis_json_string(info_id[i]);
  fputs(": ",stdout);
  nis_json_string(clean);
  fputs(i==ninfo-1?"\n":",\n",stdout);
 }
 puts("}");
}
/* Detailed mode is opt-in: keep the fast/default presentation compact, and
 * reuse direct kernel/sysfs reads instead of spawning a tool for each datum. */
static void nis_append(char *dst,size_t cap,const char *suffix){
 size_t n=strlen(dst);if(n<cap&&suffix&&*suffix)
  snprintf(dst+n,cap-n,"%s",suffix);
}
static void nis_enrich_cpu(char *cpu,size_t cap){
 char extra[128]="";long logical=sysconf(_SC_NPROCESSORS_ONLN);
 if(logical>0)snprintf(extra,sizeof extra," | %ld threads",logical);
 char cache[64]="";
 for(int i=0;i<10;i++){
  char path[160],level[16]="";
  snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/level",i);
  read_first(path,level,sizeof level);
  if(strcmp(level,"3"))continue;
  snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/size",i);
  read_first(path,cache,sizeof cache);
  if(*cache)break;
 }
 if(*cache){size_t n=strlen(extra);
  if(n+strlen(cache)+8<sizeof extra)snprintf(extra+n,sizeof extra-n,", L3 %s",cache);
 }
 nis_append(cpu,cap,extra);
}
static void nis_enrich_gpu(char *gpu,size_t cap){
 char driver[96]="",bytes[96]="",extra[128]="";
 gpu_driver(driver,sizeof driver);
 gpu_hwmon_value("mem_info_vram_total",bytes,sizeof bytes);
 unsigned long long vram=strtoull(bytes,NULL,10);
 if(*driver)snprintf(extra,sizeof extra," | %s",driver);
 if(vram){size_t n=strlen(extra);
  if(n+32<sizeof extra)snprintf(extra+n,sizeof extra-n," | %.0f GiB VRAM",(double)vram/1073741824.0);
 }
 nis_append(gpu,cap,extra);
}
static void nis_enrich_memory(char *mem,size_t cap){
 unsigned long long total=0,available=0;meminfo_numbers(&total,&available);
 if(!total)return;
 char extra[120];snprintf(extra,sizeof extra," | %.2f GiB available",available/1048576.0);
 nis_append(mem,cap,extra);
 const NisRamHardware *hw=nis_ram_hardware(NULL);
 if(hw->speed_mts){
  snprintf(extra,sizeof extra," | %u MT/s",hw->speed_mts);nis_append(mem,cap,extra);
 }
 if(hw->modules&&hw->slots){
  snprintf(extra,sizeof extra," | %u/%u DIMMs",hw->modules,hw->slots);
  nis_append(mem,cap,extra);
 }
}
static void nis_enrich_packages(char *pkgs,size_t cap){
 unsigned long long count=0;
 for(const char *p=pkgs;*p;){
  if(isdigit((unsigned char)*p)){
   char *end=NULL;unsigned long long n=strtoull(p,&end,10);
   if(end>p && *end==' ' && end[1]=='(')count+=n;
   p=end>p?end:p+1;
  }else p++;
 }
 if(count){char extra[64];snprintf(extra,sizeof extra," | %llu total",count);
  nis_append(pkgs,cap,extra);
 }
}
static void nis_append_disk_fs(const char *path,char *disk,size_t cap){
 NisMountHardware mount;
 if(nis_mount_hardware(path,&mount)&&*mount.filesystem){
  char extra[100];snprintf(extra,sizeof extra," [%s]",mount.filesystem);
  nis_append(disk,cap,extra);
 }
}
static void nis_enrich_disk(const char *path,char *disk,size_t cap){
 NisMountHardware mount;
 if(nis_mount_hardware(path,&mount)&&*mount.source){
  char extra[300];snprintf(extra,sizeof extra," | %s",mount.source);
  nis_append(disk,cap,extra);
 }
}
static void nis_enrich_swap(char *swap,size_t cap){
 struct sysinfo si;
 if(sysinfo(&si)!=0||!si.totalswap)return;
 unsigned long long used=(unsigned long long)(si.totalswap-si.freeswap)*si.mem_unit;
 unsigned long long total=(unsigned long long)si.totalswap*si.mem_unit;
 if(total){char extra[64];snprintf(extra,sizeof extra," (%.0f%% used)",100.0*(double)used/total);
  nis_append(swap,cap,extra);
 }
}
static double now_ms(void){
 struct timespec ts;
 if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (double)ts.tv_sec*1000.0+(double)ts.tv_nsec/1000000.0;
}
int main(int argc,char **argv){
 const double run_start=now_ms();
 int profile=0;
 setlocale(LC_CTYPE,"");
 static char output_buffer[32768];setvbuf(stdout,output_buffer,_IOFBF,sizeof output_buffer);
 int animate_cycles=0;int animate_preview=0;int no_logo=0,no_color=0;const char *cli_logo=NULL;const char *cli_image=NULL;const char *custom=NULL;const char *config_path=NULL;int no_config=0,check_config=0;
 const char *cli_preset=NULL;int cli_module_selection=0,cli_format=-1,cli_packages_mode=-1;
 const char *cli_theme=NULL;int cli_label_width=-1,cli_palette_indent=-1,cli_brightness=-1,cli_palette=-1;
 char all_expanded[8192];
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--no-logo"))no_logo=1;
  else if(!strcmp(argv[i],"--no-color"))no_color=1;
  else if(!strcmp(argv[i],"--no-palette"))cli_palette=0;
  else if(!strcmp(argv[i],"--palette"))cli_palette=1;
  else if(!strcmp(argv[i],"--profile"))profile=1;
  else if(!strcmp(argv[i],"--detailed"))detailed_output=1;
  else if(!strcmp(argv[i],"--version")){puts("NISFETCH 3.9.0");return 0;}
  else if(!strcmp(argv[i],"--list-presets")){
   puts("auto\ncompact\nbalanced\nhardware\nnetwork\nphone\nfull");return 0;
  }
  else if(!strcmp(argv[i],"--preset")&&i+1<argc){
   cli_preset=argv[++i];
   if(!cfg_preset_valid(cli_preset)){
    fprintf(stderr,"Unknown preset: %s (see --list-presets)\n",cli_preset);return 2;
   }
   cli_module_selection=1;cli_modules_explicit=strcmp(cli_preset,"auto")!=0;custom=NULL;
  }
  else if(!strcmp(argv[i],"--json"))cli_format=1;
  else if(!strcmp(argv[i],"--packages-mode")&&i+1<argc){
   const char *mode=argv[++i];
   if(!strcmp(mode,"fast"))cli_packages_mode=1;
   else if(!strcmp(mode,"full"))cli_packages_mode=0;
   else {fprintf(stderr,"Unknown packages mode: %s (fast or full)\n",mode);return 2;}
  }
  else if(!strcmp(argv[i],"--format")&&i+1<argc){
   const char *format=argv[++i];
   if(!strcmp(format,"json"))cli_format=1;
   else if(!strcmp(format,"text"))cli_format=0;
   else {fprintf(stderr,"Unknown format: %s (text or json)\n",format);return 2;}
  }
  else if(!strcmp(argv[i],"--theme")&&i+1<argc){
   cli_theme=argv[++i];
   if(!cfg_known_theme(cli_theme)){
    fprintf(stderr,"Unknown theme: %s (see --list-themes)\n",cli_theme);return 2;
   }
  }
  else if(!strcmp(argv[i],"--list-themes")){
   puts("vivid\nsoft\nmono\nice\nforest\nrose\nclassic\nbright (alias of vivid)");return 0;
  }
  else if(!strcmp(argv[i],"--label-width")&&i+1<argc){
   if(!cfg_int(argv[++i],&cli_label_width,8,32)){
    fputs("--label-width must be an integer from 8 to 32\n",stderr);return 2;
   }
  }
  else if(!strcmp(argv[i],"--palette-indent")&&i+1<argc){
   if(!cfg_int(argv[++i],&cli_palette_indent,0,32)){
    fputs("--palette-indent must be an integer from 0 to 32\n",stderr);return 2;
   }
  }
  else if(!strcmp(argv[i],"--theme-brightness")&&i+1<argc){
   if(!cfg_int(argv[++i],&cli_brightness,20,180)){
    fputs("--theme-brightness must be an integer from 20 to 180\n",stderr);return 2;
   }
  }
  else if(!strcmp(argv[i],"--config")&&i+1<argc)config_path=argv[++i];
  else if(!strcmp(argv[i],"--no-config"))no_config=1;
  else if(!strcmp(argv[i],"--check-config"))check_config=1;
  else if(!strcmp(argv[i],"--init-config"))return cfg_init_file();
  else if(!strcmp(argv[i],"--config-path")){
   char path[PATH_MAX];if(!cfg_default_path(path,sizeof path))return 2;
   puts(path);return 0;
  }
  else if(!strcmp(argv[i],"--list-logos")){list_logos();return 0;}
  else if(!strcmp(argv[i],"--logo")&&i+1<argc)cli_logo=argv[++i];
  else if(!strcmp(argv[i],"--image")&&i+1<argc)cli_image=argv[++i];
  else if(!strcmp(argv[i],"--image-backend")&&i+1<argc){
   const char *mode=argv[++i];
   if(!strcmp(mode,"auto"))image_backend=0;
   else if(!strcmp(mode,"ansi"))image_backend=1;
   else if(!strcmp(mode,"kitty"))image_backend=2;
   else if(!strcmp(mode,"konsole"))image_backend=3;
   else {fprintf(stderr,"Unknown image backend: %s (auto, kitty, konsole, ansi)\n",mode);return 2;}
  }
  else if(!strcmp(argv[i],"--animate")){animate_cycles=0;}
  else if(!strcmp(argv[i],"--animate-preview")){animate_cycles=0;animate_preview=1;}
  else if(!strcmp(argv[i],"--no-animate"))animate_cycles=-2;
  else if(!strcmp(argv[i],"--animate-cycles")&&i+1<argc){animate_cycles=atoi(argv[++i]);}
  else if(!strcmp(argv[i],"--gen-config")){fputs(nis_config_example,stdout);return 0;}
  else if(!strcmp(argv[i],"--help")){puts("Usage: nisfetch [--config PATH] [--check-config] [--config-path] [--init-config] [--no-config] [--gen-config] [--preset auto|compact|balanced|hardware|network|phone|full] [--list-presets] [--packages-mode fast|full] [--format text|json | --json] [--theme NAME] [--list-themes] [--theme-brightness 20..180] [--label-width 8..32] [--palette-indent 0..32] [--palette|--no-palette] [--logo NAME] [--image FILE.png|FILE.gif] [--image-backend auto|kitty|konsole|ansi] [--animate | --animate-preview] [--no-animate] [--animate-cycles N (0=forever)] [--list-logos] [--no-logo] [--no-color] [--detailed] [--modules name:name | --all] [--list-modules] [--profile] [--version]");return 0;}
  else if(!strcmp(argv[i],"--list-modules")){
   for(size_t j=0;j<sizeof module_names/sizeof module_names[0];j++)puts(module_names[j]);
   for(size_t j=0;j<sizeof monitor_modules/sizeof monitor_modules[0];j++)puts(monitor_modules[j]);
   for(size_t j=0;j<sizeof hardware_modules/sizeof hardware_modules[0];j++)puts(hardware_modules[j]);
   return 0;
  }
  else if(!strcmp(argv[i],"--all")){
   cli_preset="full";custom=NULL;cli_module_selection=1;cli_modules_explicit=1;
  }
  else if(!strcmp(argv[i],"--modules")&&i+1<argc){custom=argv[++i];cli_preset=NULL;cli_module_selection=1;cli_modules_explicit=1;}
  else {fprintf(stderr,"Unknown option: %s\n",argv[i]);return 2;}
 }
 output_color=!no_color&&isatty(STDOUT_FILENO)&&getenv("NO_COLOR")==NULL;
 if(!isatty(STDOUT_FILENO)&&!cli_logo&&!cli_image)no_logo=1;
 if(!no_config){
  if(config_path){if(!cfg_load(config_path,1))return 2;}
  else{
   char path[PATH_MAX];if(cfg_default_path(path,sizeof path)&&!cfg_load(path,0))return 2;
  }
 }
 if(cli_packages_mode>=0)cfg_packages_fast=cli_packages_mode;
 if(cli_theme){
  snprintf(cfg_theme,sizeof cfg_theme,"%.15s",cli_theme);
  /* An explicit CLI theme wins over stored global RGB overrides. */
  cfg_has_key=cfg_has_val=cfg_has_title=cfg_has_separator=0;
  cfg_apply_theme();
 }
 if(cli_label_width>=0)cfg_label_width=cli_label_width;
 if(cli_palette_indent>=0)cfg_palette_indent=cli_palette_indent;
 if(cli_brightness>=0)cfg_theme_brightness=cli_brightness;
 if(cli_palette>=0)cfg_palette=cli_palette;
 if(cli_format>=0)cfg_output_json=cli_format;
 if(cli_logo){
  snprintf(cfg_logo_type,sizeof cfg_logo_type,"%s",cli_logo);
  cfg_logo=1;
  if(!cli_image)cfg_image_path[0]=0; /* --logo overrides a configured image */
 }
 if(!output_color)cfg_palette=0;
 if(cli_image){snprintf(cfg_image_path,sizeof cfg_image_path,"%s",cli_image);cfg_logo=1;}
 /* Explicit CLI selection wins over the config, then fixed modules win over
    the config preset. Auto always means platform-adaptive defaults. */
 if(cli_module_selection){
  if(cli_preset)custom=cfg_preset_modules(cli_preset);
 }else if(*cfg_order)custom=cfg_order;
 else if(*cfg_preset_name)custom=cfg_preset_modules(cfg_preset_name);
 if(custom&&!strcmp(custom,"@full")){
  int n=snprintf(all_expanded,sizeof all_expanded,"%s",all_modules);
  for(size_t k=0;k<sizeof monitor_modules/sizeof monitor_modules[0] && n>=0 && n<(int)sizeof all_expanded;k++)
   n+=snprintf(all_expanded+n,sizeof all_expanded-(size_t)n,":%s",monitor_modules[k]);
  for(size_t k=0;k<sizeof hardware_modules/sizeof hardware_modules[0] && n>=0 && n<(int)sizeof all_expanded;k++)
   n+=snprintf(all_expanded+n,sizeof all_expanded-(size_t)n,":%s",hardware_modules[k]);
  if(n<0||n>=(int)sizeof all_expanded){fputs("Module list is too long\n",stderr);return 2;}
  custom=all_expanded;
 }
 if(custom&&!valid_modules(custom))return 2;
 if(*cfg_hidden&&!valid_modules(cfg_hidden))return 2;
 for(size_t k=0;k<cfg_styles_count;k++)if(!valid_modules(cfg_styles[k].name))return 2;
 if(custom && custom!=cfg_order)cfg_order[0]=0;
 if(check_config){puts("Config OK");return 0;}
 /* JSON is always machine-readable: never emit images, palette or ANSI. */
 if(cfg_output_json){no_logo=1;cfg_palette=0;output_color=0;}
 UserImage user_image={0};
 if(!no_logo&&cfg_logo&&*cfg_image_path&&!image_load(cfg_image_path,&user_image)){
  fprintf(stderr,"Cannot decode image: %s (PNG/GIF, max 2048x2048)\n",cfg_image_path);return 2;
 }
 int has_custom_image=user_image.w>0&&user_image.h>0;
 /* Cursor query is only needed in non-fixed mode; fixed GIFs start at row 1. */
 /* Cursor position is not used in normal scrollback mode. */
 if(!no_logo&&cfg_logo&&!has_custom_image&&strcmp(cfg_logo_type,"tux")&&!find_logo(cfg_logo_type)){
  fprintf(stderr,"Unknown logo: %s (see --list-logos)\n",cfg_logo_type);return 2;
 }
 if(cfg_gap<0)cfg_gap=0;
 if(cfg_gap>12)cfg_gap=12;
 if(cfg_logo_width<0)cfg_logo_width=0;
 if(cfg_logo_width>TUX_W)cfg_logo_width=TUX_W;
 selected_modules=custom;
 const double setup_end=now_ms();
 struct utsname u;struct sysinfo si;if(uname(&u)||sysinfo(&si)){perror("nisfetch");return 1;}
 char os[256],cpu[256],mem[128],disk[128]="",pkgs[128],tmp[512],hostname[256],board[512]="";
 char terminal[128]="",swap[128],gpu[256],display[128],theme[128],icons[128],font[256],wm[128],home_disk[128]="",wmtheme[128],cursor[128],plasma[128];
 os[0]=cpu[0]=mem[0]=pkgs[0]=0;
 if(module_enabled("os"))osname(os,sizeof os);
 if(module_enabled("cpu"))cpuinfo(cpu,sizeof cpu);
 if(module_enabled("memory"))meminfo(mem,sizeof mem);
 if(module_enabled("memory")){
  /* A memory-only request still gets the platform fallback if unambiguous. */
  if(!*cpu)cpuinfo(cpu,sizeof cpu);
  const NisRamHardware *ram=nis_ram_hardware(cpu);
  if(*ram->type){char extra[40];snprintf(extra,sizeof extra," | %.23s",ram->type);
   nis_append(mem,sizeof mem,extra);
  }
 }
 if(module_enabled("packages"))packages(pkgs,sizeof pkgs);
 if(detailed_output){
  if(module_enabled("memory"))nis_enrich_memory(mem,sizeof mem);
  if(module_enabled("packages"))nis_enrich_packages(pkgs,sizeof pkgs);
 }
 if(gethostname(hostname,sizeof hostname))snprintf(hostname,sizeof hostname,"unknown");
 hostname[sizeof hostname-1]=0;
 /* Most interactive shells set USER. Avoid an unnecessary NSS lookup. */
 const char *user=getenv("USER");
 if(!user||!*user){struct passwd *pw=getpwuid(getuid());user=pw?pw->pw_name:"user";}
 swap[0]=gpu[0]=display[0]=0;
 if(module_enabled("swap"))swapinfo(swap,sizeof swap);
 if(detailed_output&&module_enabled("swap"))nis_enrich_swap(swap,sizeof swap);
 if(module_enabled("gpu"))gpu_short(gpu,sizeof gpu);
 if(module_enabled("display"))kde_display(display,sizeof display);
 wmtheme[0]=theme[0]=icons[0]=font[0]=cursor[0]=plasma[0]=wm[0]=0;
 if(module_enabled("wmtheme")||module_enabled("theme")||module_enabled("icons")||module_enabled("font")||module_enabled("cursor")||module_enabled("plasmatheme"))
  themeinfo(wmtheme,sizeof wmtheme,theme,sizeof theme,icons,sizeof icons,font,sizeof font,cursor,sizeof cursor,plasma,sizeof plasma);
 if(module_enabled("wm"))wm_info(wm,sizeof wm);
 if(module_enabled("homedisk"))disk_path(env_or("HOME","/"),home_disk,sizeof home_disk);
 if(module_enabled("homedisk")){
  const char *path=env_or("HOME","/");
  nis_append_disk_fs(path,home_disk,sizeof home_disk);
  if(detailed_output)nis_enrich_disk(path,home_disk,sizeof home_disk);
 }
 snprintf(tmp,sizeof tmp,"%s@%s",user,hostname);
 add_module("title","",tmp);
 /* Underline exactly the visible width of user@hostname. */
 size_t title_width=strlen(user)+1+strlen(hostname);
 if(title_width>100)title_width=100;
 char underline[512];size_t off=0;
 for(size_t i=0;i<title_width && off+4<sizeof underline;i++){
  memcpy(underline+off,"─",3);off+=3;
 }
 underline[off]='\0';
 add_module("separator","",underline);
 snprintf(tmp,sizeof tmp,"%s %s",os,u.machine);add_module("os","OS:",tmp);
 if(module_enabled("host"))motherboard(board,sizeof board);
 if(detailed_output&&module_enabled("host")){
  char bios[128]="";read_first("/sys/class/dmi/id/bios_version",bios,sizeof bios);
  if(*bios){char extra[160];snprintf(extra,sizeof extra," | BIOS %s",bios);
   nis_append(board,sizeof board,extra);
  }
 }
 add_module("host","Host:",board);
 snprintf(tmp,sizeof tmp,"%s %s",u.sysname,u.release);add_module("kernel","Kernel:",tmp);
 long uptime_hours=si.uptime/3600, uptime_minutes=(si.uptime/60)%60;
 if(uptime_hours)snprintf(tmp,sizeof tmp,"%ld %s, %ld %s",uptime_hours,uptime_hours==1?"hour":"hours",uptime_minutes,uptime_minutes==1?"min":"mins");
 else snprintf(tmp,sizeof tmp,"%ld %s",uptime_minutes,uptime_minutes==1?"min":"mins");
 if(detailed_output&&module_enabled("uptime")){
  char boot[64]="";boot_date(boot,sizeof boot);
  if(*boot){char extra[90];snprintf(extra,sizeof extra," | boot %s",boot);
   nis_append(tmp,sizeof tmp,extra);
  }
 }
 add_module("uptime","Uptime:",tmp);
 add_module("packages","Packages:",pkgs);
 if(detailed_output&&module_enabled("display")&&!is_termux()){
  NisMonitor mon;nis_monitor_probe(&mon);
  if(*mon.connector){char extra[128];
   snprintf(extra,sizeof extra," [%s%s]",mon.connector,mon.connected>1?", multi-monitor":"");
   nis_append(display,sizeof display,extra);
  }
 }
 add_module("display","Display:",display);
 add_module("desktop","Desktop:",is_termux()?"Android":env_or("XDG_CURRENT_DESKTOP",env_or("XDG_SESSION_DESKTOP","TTY")));
 add_module("wm","WM:",wm);
 add_module("wmtheme","WM Theme:",wmtheme);
 add_module("theme","Theme:",theme);
 add_module("plasmatheme","Plasma Theme:",plasma);
 add_module("icons","Icons:",icons);
 add_module("font","Font:",font);
 add_module("cursor","Cursor:",cursor);
 add_module("session","Session:",is_termux()?"Termux":env_or("XDG_SESSION_TYPE","TTY"));
 if(module_enabled("terminal"))terminal_name(terminal,sizeof terminal);
 add_module("terminal","Terminal:",terminal);
 if(module_enabled("cpu")){cpu_max_frequency(cpu,sizeof cpu);temp_suffix(cpu,sizeof cpu,"k10temp","coretemp");}
 if(module_enabled("gpu"))temp_suffix(gpu,sizeof gpu,"amdgpu","nouveau");
 if(detailed_output){
  if(module_enabled("cpu"))nis_enrich_cpu(cpu,sizeof cpu);
  if(module_enabled("gpu"))nis_enrich_gpu(gpu,sizeof gpu);
 }
 struct winsize ws={0};
 int termcols=100,termrows=40;
 if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&ws)!=0)ioctl(STDIN_FILENO,TIOCGWINSZ,&ws);
 if(ws.ws_col>0)termcols=ws.ws_col;
 if(ws.ws_row>0)termrows=ws.ws_row;
 /* Balanced layout: logo gets ~42% of columns; text gets the majority.
    Never exceed the native 58-pixel source width (no blurry upscaling).
    Small terminals keep at least 38 columns for the info panel. */
 const DistroLogo *dlogo=has_custom_image?NULL:(strcmp(cfg_logo_type,"tux")?find_logo(cfg_logo_type):NULL);
 const unsigned char *pixlogo=dlogo?distro_pixels(cfg_logo_type):NULL;
 int allowed_width=termcols-38-cfg_gap;
 int balanced_width=(termcols*43)/100;
 int artwidth=cfg_logo_width?cfg_logo_width:balanced_width,artheight=0;
 if(artwidth>(has_custom_image?120:TUX_W))artwidth=has_custom_image?120:TUX_W;
 int show_tux=0,show_distro=0,show_pixel=0,show_image=0;
 int pix_top=0,pix_bottom=DISTRO_H;
 if(pixlogo)pixel_logo_bounds(pixlogo,&pix_top,&pix_bottom);
 /* All high-resolution logos use the exact same layout geometry as Tux. */
 if(!dlogo || pixlogo){
  int allowed_height=termrows-2;
  if(artwidth>allowed_width)artwidth=allowed_width;
  if(allowed_height>0){
   int by_height=(int)((long)allowed_height*TUX_W*2/TUX_H);
   if(artwidth>by_height)artwidth=by_height;
  }
  artheight=artwidth>0?(int)lround((double)artwidth*(has_custom_image?user_image.h:TUX_H)/(2.0*(has_custom_image?user_image.w:TUX_W))):0;
  if(artheight>allowed_height){artheight=allowed_height;artwidth=(int)lround((double)artheight*2.0*(has_custom_image?user_image.w:TUX_W)/(has_custom_image?user_image.h:TUX_H));}
  int visible=!no_logo&&cfg_logo&&artwidth>=12&&artheight>=8;
  if(!cfg_auto&&cfg_logo_width>0&&artwidth<cfg_logo_width)visible=0;
  show_tux=visible&&!pixlogo&&!has_custom_image;
  show_image=visible&&has_custom_image;
  show_pixel=visible&&pixlogo;
  if(!visible){artwidth=0;artheight=0;}
 }else{
  /* Retain legacy compact fallback for logos without supplied pixel artwork. */
  artwidth=distro_width(dlogo);
  artheight=dlogo->height;
  show_distro=!no_logo&&cfg_logo&&artwidth<=allowed_width&&artheight<=termrows;
  if(!show_distro){artwidth=0;artheight=0;}
 }
 int show_logo=show_tux||show_pixel||show_distro||show_image;
 fit_gpu(gpu,sizeof gpu,termcols-artwidth-cfg_gap-LABEL_WIDTH);
 add_module("cpu","CPU:",cpu);
 add_module("gpu","GPU:",gpu);
 add_module("memory","Memory:",mem);
 add_module("swap","Swap:",swap);
 if(module_enabled("disk"))disk_path("/",disk,sizeof disk);
 if(module_enabled("disk")){
  nis_append_disk_fs("/",disk,sizeof disk);
  if(detailed_output)nis_enrich_disk("/",disk,sizeof disk);
 }
 add_module("disk","Disk (/):",disk);
 add_module("homedisk",is_termux()?"Disk (HOME):":"Disk (/home):",home_disk);
 add_module("localip","Local IP:","1337.1337.1337");
 char locale_value[128];snprintf(locale_value,sizeof locale_value,"%s",env_or("LANG","Unknown"));
 if(detailed_output&&module_enabled("locale")){
  time_t now=time(NULL);struct tm tmv;char zone[48]="";
  if(localtime_r(&now,&tmv))strftime(zone,sizeof zone,"%Z",&tmv);
  if(*zone){char extra[64];snprintf(extra,sizeof extra," | %s",zone);
   nis_append(locale_value,sizeof locale_value,extra);
  }
 }
 add_module("locale","Locale:",locale_value);
 if(!selected_modules){
  optional_module("cpucores");
  optional_module("processes");
  optional_module("load1");
  if(is_termux()){
   /* Compact phone preset; optional fields disappear when unavailable. */
   static const char *phone_modules[]={
    "androidbrand","androidmanufacturer","androidmodel","androidsoc","androidversion",
    "androidsdk","androidsecuritypatch","battery","batteryhealth","batterycycles",
    "brightness","timezone"
   };
   for(size_t k=0;k<sizeof phone_modules/sizeof phone_modules[0];k++)
    optional_module(phone_modules[k]);
  }
 }
 if(selected_modules){
  for(size_t k=26;k<sizeof module_names/sizeof module_names[0];k++)
   optional_module(module_names[k]);
  for(size_t k=0;k<sizeof monitor_modules/sizeof monitor_modules[0];k++)
   optional_module(monitor_modules[k]);
  for(size_t k=0;k<sizeof hardware_modules/sizeof hardware_modules[0];k++)
   optional_module(hardware_modules[k]);
 }
 reorder_info();
 const double collect_end=now_ms();
 if(cfg_output_json){
  nis_json_output();
  if(profile){
   fflush(stdout);const double end=now_ms();
   fprintf(stderr,"NISFETCH profile: setup %.2f ms | collect %.2f ms | render %.2f ms | total %.2f ms\n",setup_end-run_start,collect_end-setup_end,end-collect_end,end-run_start);
  }
  return 0;
 }
 /* Pixel distro logos may use a shorter visible height to align with the text. */
 if(show_pixel && cfg_logo_width==0){
  int balanced_height=ninfo+(cfg_palette?3:0);
  if(balanced_height<22)balanced_height=22;
  if(balanced_height>artheight)balanced_height=artheight;
  if(balanced_height>termrows-3)balanced_height=termrows-3;
  if(balanced_height>=9)artheight=balanced_height;
 }
 /* Fastfetch-style: compact, consecutive info rows starting at the top. */
 size_t artrows=show_logo?(size_t)artheight:0;
 size_t rows=artrows;
 if((size_t)ninfo+(cfg_palette?3:0)>rows)rows=(size_t)ninfo+(cfg_palette?3:0);
 /* PNG: exact source bytes in Kitty or Konsole. Konsole needs a regular
    cursor placement, never the unsupported Unicode placeholders. GIFs retain
    their previous experimental Kitty implementation for compatibility. */
 int render_mode=0;
 if(show_image){
  const char *ext=strrchr(cfg_image_path,'.');
  if(ext&&!strcasecmp(ext,".png")){
   int mode=png_graphics_mode();
   if(mode&&kitty_png_render(cfg_image_path,artwidth,artheight,mode==2))render_mode=mode;
  }else if(kitty_render(cfg_image_path,&user_image,artwidth,artheight,animate_cycles))render_mode=1;
 }
 if(show_image&&!render_mode&&!user_image.rgba && !image_png_full(cfg_image_path,&user_image)){
  fprintf(stderr,"Cannot decode PNG fallback: %s\n",cfg_image_path);
  image_free(&user_image);return 2;
 }
 for(size_t i=0;i<rows;i++){
   if(show_logo){
    if(i<artrows){
     if(show_image){
      if(render_mode==1)kitty_placeholder_row((int)i,artwidth);
      else if(render_mode==2)printf("\033[%dC",artwidth);
      else image_row(&user_image,i,artwidth,artheight);
     }else if(show_tux)tux_row_scaled(i,artwidth,artheight);
     else if(show_pixel)pixel_logo_row(pixlogo,i,artwidth,artheight,pix_top,pix_bottom);
     else distro_row(dlogo,(int)i,artwidth);
    }else printf("%*s",artwidth,"");
   }
   if(i<(size_t)ninfo){
     int remaining=termcols-artwidth-(show_logo?cfg_gap:0);
     if(remaining<1)remaining=1;
     char clipped[1024];clip_ansi(info[i],clipped,sizeof clipped,remaining);
     printf("%*s%s",show_logo?cfg_gap:0,"",clipped);
   }else if(cfg_palette && (i==(size_t)ninfo+1 || i==(size_t)ninfo+2) && termcols-artwidth>=cfg_palette_indent+24){
     printf("%*s",cfg_palette_indent,"");
     palette_row((int)(i-(size_t)ninfo-1));
   }
   putchar('\n');
 }
 /* Restore the full terminal scroll region even if a previous hotfix
    left DECSTBM enabled.  Do not clear the screen or reposition the cursor. */
 if(show_image && !render_mode && animate_preview && animate_cycles>=0 &&
    strrchr(cfg_image_path,'.') && !strcasecmp(strrchr(cfg_image_path,'.'),".gif")){
  fflush(stdout);
  gif_preview(cfg_image_path,&user_image,artwidth,artheight,animate_cycles);
 }
 image_free(&user_image);
 /* Keep the cursor after the entire fetch; Bash starts below the artwork. */
 fputs("\n\n\n",stdout);
 /* --profile is opt-in and writes timings to stderr only. */
 if(profile){
  fflush(stdout);
  const double end=now_ms();
  fprintf(stderr,"NISFETCH profile: setup %.2f ms | collect %.2f ms | render %.2f ms | total %.2f ms\n",setup_end-run_start,collect_end-setup_end,end-collect_end,end-run_start);
 }
 return 0;
}
