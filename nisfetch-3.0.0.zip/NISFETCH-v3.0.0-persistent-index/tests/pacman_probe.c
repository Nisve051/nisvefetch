/* Compile the real source into a standalone harness to test its private
   package classifier against a temporary libalpm fixture. */
#define main nisfetch_app_main
#include "../nisfetch.c"
#undef main
int main(int argc,char **argv){
 if(argc!=3&&argc!=4)return 2;
 PacmanConfig config;
 if(!pacman_config_from(argv[1],&config))return 3;
 if(snprintf(config.dbpath,sizeof config.dbpath,"%s",argv[2])>=(int)sizeof config.dbpath)return 4;
 if(!pacman_db_files_ready(&config,time(NULL)))return 5;
 if(argc==4){
  if(!strcmp(argv[3],"state-valid")){
   uint64_t fingerprint=0;unsigned long count=0;
   if(pacman_db_fingerprint(&config,&fingerprint)&&pacman_index_read(fingerprint,&count))
    printf("valid:%lu\n",count);
   else puts("invalid");
   return 0;
  }
  if(!strcmp(argv[3],"use-state")){
   printf("%lu\n",foreign_packages(&config));
   return 0;
  }
  return 7;
 }
 unsigned long foreign=0;
 if(!pacman_foreign_libalpm(&config,&foreign))return 6;
 printf("%lu\n",foreign);
 return 0;
}
