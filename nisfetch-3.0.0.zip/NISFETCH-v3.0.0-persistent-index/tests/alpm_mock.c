#include <string.h>
#include <stdlib.h>
/* Minimal public-ABI fixture. Not a copy of libalpm or a production library. */
static int handle,core,extra;
void *alpm_initialize(const char *root,const char *dbpath,int *error){
 (void)root;(void)dbpath;if(error)*error=0;
 if(getenv("NISFETCH_TEST_NO_ALPM"))return NULL;
 return &handle;
}
int alpm_release(void *context){return context==&handle?0:-1;}
void *alpm_register_syncdb(void *context,const char *name,int level){
 (void)level;
 if(context!=&handle)return 0;
 if(!strcmp(name,"core"))return &core;
 if(!strcmp(name,"extra"))return &extra;
 return 0;
}
int alpm_db_get_valid(void *db){return db==&core||db==&extra?0:-1;}
void *alpm_db_get_pkg(void *db,const char *name){
 if(db==&core&&!strcmp(name,"bash"))return &core;
 if(db==&extra&&!strcmp(name,"nano"))return &extra;
 return 0;
}
