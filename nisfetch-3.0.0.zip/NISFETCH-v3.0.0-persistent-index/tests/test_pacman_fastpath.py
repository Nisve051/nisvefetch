import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import shlex
import shutil
import subprocess
import tempfile
import unittest


TEST_DIR = Path(__file__).resolve().parent


class NativePacmanTests(unittest.TestCase):
    def test_foreign_packages_without_pacman_process(self):
        compiler = os.environ.get("CC", "cc")
        compile_flags = shlex.split(os.environ.get("NISFETCH_TEST_CPPFLAGS", ""))
        link_flags = shlex.split(
            os.environ.get("NISFETCH_TEST_LDFLAGS", "-lm -lpng -lgif -lz -ldl")
        )
        with tempfile.TemporaryDirectory(prefix="nisfetch-alpm-") as base:
            root = Path(base)
            mock = root / "libalpm.so"
            probe = root / "probe"
            subprocess.run(
                [compiler, "-shared", "-fPIC", str(TEST_DIR / "alpm_mock.c"), "-o", str(mock)],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            subprocess.run(
                [compiler, "-std=c11", "-O2", *compile_flags,
                 str(TEST_DIR / "pacman_probe.c"), "-o", str(probe), *link_flags],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            db = root / "db"
            (db / "sync").mkdir(parents=True)
            for name in ("core", "extra"):
                (db / "sync" / f"{name}.db").write_text("fixture\n")
            for name in ("bash-5.3-1", "nano-8.2-1", "aur-fancy-2.0-1", "foo-bar-1.2-1"):
                (db / "local" / name).mkdir(parents=True)
            config = root / "pacman.conf"
            config.write_text("[options]\nArchitecture = auto\n[core]\nInclude = /tmp/example\n[extra]\n")
            env = os.environ.copy()
            env["LD_LIBRARY_PATH"] = str(root) + (
                ":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else ""
            )
            env["XDG_STATE_HOME"] = str(root / "state")
            env["XDG_CACHE_HOME"] = str(root / "cache")
            result = subprocess.run(
                [str(probe), str(config), str(db)],
                env=env,
                check=True,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.stdout.strip(), "2")

            # First use builds the durable index from the same exact result.
            create_index = subprocess.run(
                [str(probe), str(config), str(db), "use-state"],
                env=env, check=True, capture_output=True, text=True,
            )
            self.assertEqual(create_index.stdout.strip(), "2")
            self.assertTrue((root / "state/nisfetch/pacman-foreign.index").is_file())

            # A user can clear the ordinary cache and still have a valid index.
            shutil.rmtree(root / "cache", ignore_errors=True)
            no_alpm = env.copy()
            no_alpm["NISFETCH_TEST_NO_ALPM"] = "1"
            indexed = subprocess.run(
                [str(probe), str(config), str(db), "use-state"],
                env=no_alpm, check=True, capture_output=True, text=True,
            )
            self.assertEqual(indexed.stdout.strip(), "2")

            # Repository changes must invalidate the index, not return stale AUR.
            (db / "sync/extra.db").write_text("updated fixture\n")
            changed = subprocess.run(
                [str(probe), str(config), str(db), "state-valid"],
                env=env, check=True, capture_output=True, text=True,
            )
            self.assertEqual(changed.stdout.strip(), "invalid")

            # A corrupt index must be rejected and rebuilt, even when the
            # disposable cache has been removed.
            index_file = root / "state/nisfetch/pacman-foreign.index"
            index_file.write_text("broken index\n")
            repaired = subprocess.run(
                [str(probe), str(config), str(db), "use-state"],
                env=env, check=True, capture_output=True, text=True,
            )
            self.assertEqual(repaired.stdout.strip(), "2")

            # Concurrent shell startup cannot leave half-written state.
            index_file.unlink()
            shutil.rmtree(root / "cache", ignore_errors=True)
            def start_one(_):
                return subprocess.run(
                    [str(probe), str(config), str(db), "use-state"],
                    env=env, check=True, capture_output=True, text=True,
                ).stdout.strip()
            with ThreadPoolExecutor(max_workers=8) as pool:
                self.assertEqual(list(pool.map(start_one, range(8))), ["2"] * 8)
            check = subprocess.run(
                [str(probe), str(config), str(db), "state-valid"],
                env=env, check=True, capture_output=True, text=True,
            )
            self.assertEqual(check.stdout.strip(), "valid:2")


if __name__ == "__main__":
    unittest.main()
