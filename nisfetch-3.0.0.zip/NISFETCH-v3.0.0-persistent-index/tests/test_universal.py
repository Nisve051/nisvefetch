"""Portable behavior, regression and simulated Termux tests for NISFETCH 3.0."""

import concurrent.futures
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


EXECUTABLE = Path(os.environ.get("NISFETCH_BIN", str(Path.home() / ".local/bin/nisfetch")))


class UniversalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.cache = self.base / "cache"
        self.cache.mkdir()

    def run_fetch(self, *args, env=None, check=True, no_config=True):
        if env is None:
            env = os.environ.copy()
        env["XDG_CACHE_HOME"] = str(self.cache)
        prefix = ["--no-config"] if no_config else []
        return subprocess.run([str(EXECUTABLE), *prefix, *args],
                              env=env, capture_output=True, timeout=15, check=check)

    def test_major_version(self):
        self.assertEqual(self.run_fetch("--version").stdout.strip(), b"NISFETCH 3.0.0")

    def test_piped_plain_output_and_no_color(self):
        out = self.run_fetch("--no-logo", "--no-color", "--modules",
                             "os:kernel:cpu:memory:swap:disk").stdout
        self.assertIn(b"OS:", out)
        self.assertNotIn(b"\x1b", out)

    def test_non_kde_default_adapts(self):
        env = os.environ.copy()
        env.pop("KONSOLE_VERSION", None)
        env.update(XDG_CURRENT_DESKTOP="GNOME", XDG_SESSION_TYPE="wayland")
        out = self.run_fetch("--no-logo", env=env).stdout
        self.assertIn(b"Mutter (wayland)", out)
        self.assertIn(b"Wayland", out)
        self.assertNotIn(b"WM Theme:", out)
        self.assertNotIn(b"Plasma Theme:", out)

    def test_config_check_skips_missing_image_io(self):
        config = self.base / "config.jsonc"
        config.write_text('{"logo": {"type": "tux", "image": "/missing/image.png"}}')
        p = self.run_fetch("--config", str(config), "--check-config", no_config=False)
        self.assertIn(b"Config OK", p.stdout)
        p = self.run_fetch("--config", str(config), "--no-logo", "--modules", "os", no_config=False)
        self.assertIn(b"OS:", p.stdout)
        p = self.run_fetch("--config", str(config), "--logo", "tux", "--modules", "os", no_config=False)
        self.assertIn(b"OS:", p.stdout)

    def termux_env(self):
        prefix = self.base / "com.termux" / "files" / "usr"
        status = prefix / "var" / "lib" / "dpkg" / "status"
        status.parent.mkdir(parents=True)
        status.write_text(
            "Package: one\nStatus: install ok installed\n\n"
            "Package: removed\nStatus: deinstall ok config-files\n\n"
            "Package: two\nStatus: install ok installed\n\n"
            "Package: three\nStatus: install ok installed\n\n"
        )
        bindir = prefix / "bin"
        bindir.mkdir()
        prop_log = self.base / "getprop_calls"
        script = bindir / "getprop"
        script.write_text(
            '#!/bin/sh\n'
            'printf "called\\n" >> "$NISFETCH_TEST_PROP_LOG"\n'
            'printf "[ro.build.version.release]: [15]\\n"\n'
            'printf "[ro.product.model]: [Test Phone]\\n"\n'
            'printf "[ro.product.manufacturer]: [Acme]\\n"\n'
            'printf "[ro.product.brand]: [Acme]\\n"\n'
            'printf "[ro.soc.model]: [Test SOC]\\n"\n'
        )
        script.chmod(0o755)
        env = os.environ.copy()
        env.update(PREFIX=str(prefix), TERMUX_VERSION="0.120",
                   NISFETCH_TEST_PROP_LOG=str(prop_log),
                   PATH=f"{bindir}:{env.get('PATH', '')}")
        return env, prop_log

    def test_termux_native_package_count_and_one_property_snapshot(self):
        env, prop_log = self.termux_env()
        out = self.run_fetch("--no-logo", "--modules",
                             "os:host:cpu:packages:androidmodel:androidversion:androidbrand",
                             env=env).stdout
        self.assertIn(b"3 (dpkg/Termux)", out)
        self.assertIn(b"Android 15 (Termux)", out)
        self.assertIn(b"Test Phone", out)
        self.assertEqual(prop_log.read_text().splitlines(), ["called"])

    def test_termux_default_hides_linux_desktop(self):
        env, _ = self.termux_env()
        out = self.run_fetch("--no-logo", env=env).stdout
        self.assertIn(b"3 (dpkg/Termux)", out)
        self.assertIn(b"Termux", out)
        self.assertNotIn(b"WM Theme:", out)
        self.assertNotIn(b"GPU:", out)
        self.assertNotIn(b"Display:", out)
        self.assertNotIn(b"Desktop:", out)

    def test_package_cache_is_atomic_with_parallel_shells(self):
        env, _ = self.termux_env()

        def worker(_):
            return self.run_fetch("--no-logo", "--modules", "packages", env=env).stdout

        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            outputs = list(pool.map(worker, range(12)))
        self.assertTrue(all(b"3 (dpkg/Termux)" in out for out in outputs))
        self.assertEqual((self.cache / "nisfetch" / "packages").read_text().strip(),
                         "3 (dpkg/Termux)")
        self.assertEqual(list((self.cache / "nisfetch").glob(".*")), [])


if __name__ == "__main__":
    unittest.main()
