#define _XOPEN_SOURCE 700
#define _POSIX_C_SOURCE 200809L
#ifndef __ANDROID__
#define _DEFAULT_SOURCE 1
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>
#include <sys/statvfs.h>
#include <pwd.h>
#include <ctype.h>
#include <stdint.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <math.h>
#include <time.h>
#include <locale.h>
#include <wchar.h>
#include <limits.h>
#include <sys/statvfs.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
#include <png.h>
#include <gif_lib.h>
#include <zlib.h>
#include <termios.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <dlfcn.h>
#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

#define R "\033[0m"
#define MAX_ROWS 192
#define C "\033[1;38;2;244;194;105m"
#define ACCENT "\033[1;38;2;251;212;135m"
#define SOFT "\033[1;38;2;223;233;239m"
#define MUTED "\033[38;2;151;169;180m"
static int output_color=1;
#include "nis_tux.h"
#include "nis_distro_pixels.h"
/* Truecolor half-block renderer. Transparent pixels reset the terminal
   background; source pixel sampling is handled by the artwork renderers. */
static void pixel_pair(const unsigned char *top,const unsigned char *bottom,int ta,int ba){
 if(!output_color){
  fputs(!ta&&!ba?" ":ta&&ba?"█":ta?"▀":"▄",stdout);
  return;
 }
 if(!ta&&!ba){fputs("\033[49m ",stdout);return;}
 if(ta&&ba){
  printf("\033[38;2;%u;%u;%um\033[48;2;%u;%u;%um▀",top[0],top[1],top[2],bottom[0],bottom[1],bottom[2]);
 }else if(ta){
  printf("\033[49m\033[38;2;%u;%u;%um▀",top[0],top[1],top[2]);
 }else{
  printf("\033[49m\033[38;2;%u;%u;%um▄",bottom[0],bottom[1],bottom[2]);
 }
}
/* An RGBA source is retained for the native Tux artwork. The terminal has
   only two half-block pixels per cell, so interpolation is deliberately
   premultiplied and scoped to the terminal-resolution result. */
/* Preserve Tux's antialiased edge pixels instead of deleting everything with
   alpha below 245.  Premultiplied bilinear sampling avoids the light halos
   that ordinary interpolation introduces around transparent RGBA pixels. */
static void tux_sample(double x,double y,unsigned char out[4]){
 int x0=(int)floor(x),y0=(int)floor(y);
 double fx=x-x0,fy=y-y0;
 if(x0<0){x0=0;fx=0;}if(y0<0){y0=0;fy=0;}
 if(x0>=TUX_W-1){x0=TUX_W-1;fx=0;}
 if(y0>=TUX_H-1){y0=TUX_H-1;fy=0;}
 int x1=x0+1<TUX_W?x0+1:x0,y1=y0+1<TUX_H?y0+1:y0;
 double w[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
 const unsigned char *p[4]={tux_rgba+((size_t)y0*TUX_W+x0)*4,tux_rgba+((size_t)y0*TUX_W+x1)*4,
  tux_rgba+((size_t)y1*TUX_W+x0)*4,tux_rgba+((size_t)y1*TUX_W+x1)*4};
 double a=0,r=0,g=0,b=0;
 for(int i=0;i<4;i++){double aw=w[i]*p[i][3];a+=aw;r+=aw*p[i][0];g+=aw*p[i][1];b+=aw*p[i][2];}
 out[3]=(unsigned char)lround(a);
 out[0]=a>0?(unsigned char)lround(r/a):0;
 out[1]=a>0?(unsigned char)lround(g/a):0;
 out[2]=a>0?(unsigned char)lround(b/a):0;
}
static void tux_pixel_mix(const unsigned char source[4],unsigned char out[4]){
 /* The dark outline stays visible with softened edges on dark themes. */
 static const int bg[3]={18,20,25};
 for(int c=0;c<3;c++)out[c]=(unsigned char)((source[c]*source[3]+bg[c]*(255-source[3])+127)/255);
 out[3]=source[3];
}
static void tux_row_scaled(size_t row,int width,int height){
 for(int x=0;x<width;x++){
  double sx=((double)x+0.5)*TUX_W/width-0.5;
  double sy0=((double)(2*row)+0.5)*TUX_H/(2*height)-0.5;
  double sy1=((double)(2*row)+1.5)*TUX_H/(2*height)-0.5;
  unsigned char a[4],b[4],top[4],bottom[4];
  tux_sample(sx,sy0,a);tux_sample(sx,sy1,b);
  tux_pixel_mix(a,top);tux_pixel_mix(b,bottom);
  pixel_pair(top,bottom,a[3]>=12,b[3]>=12);
 }
 if(output_color)fputs(R,stdout);
}


/* Optional user artwork: PNG RGBA and GIF89a. Bounds protect terminal memory. */
typedef struct {unsigned char *rgba;int w,h;GifFileType *gif;} UserImage;
static int png_graphics_mode(void);
static void image_free(UserImage *im){
 if(im->gif){int err=0;DGifCloseFile(im->gif,&err);im->gif=NULL;}
 free(im->rgba);im->rgba=NULL;im->w=im->h=0;
}
static int image_size_ok(unsigned int w,unsigned int h){return w>0&&h>0&&w<=2048&&h<=2048&&(size_t)w*h<=4194304;}
/* For native terminal PNG rendering we only need dimensions. Validate the
   IHDR and its CRC; the terminal will decode the unmodified PNG payload. */
static int image_png_probe(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size<33||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 unsigned char h[33];int ok=fread(h,1,sizeof h,fp)==sizeof h;
 fclose(fp);
 if(!ok||png_sig_cmp(h,0,8)||memcmp(h+8,"\0\0\0\rIHDR",8))return 0;
 unsigned w=((unsigned)h[16]<<24)|((unsigned)h[17]<<16)|((unsigned)h[18]<<8)|h[19];
 unsigned height=((unsigned)h[20]<<24)|((unsigned)h[21]<<16)|((unsigned)h[22]<<8)|h[23];
 if(!image_size_ok(w,height))return 0;
 uLong crc=crc32(0L,Z_NULL,0);
 crc=crc32(crc,h+12,17);
 unsigned expected=((unsigned)h[29]<<24)|((unsigned)h[30]<<16)|((unsigned)h[31]<<8)|h[32];
 if((unsigned)crc!=expected)return 0;
 im->w=(int)w;im->h=(int)height;
 return 1;
}
static int image_png_full(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 unsigned char sig[8];if(fread(sig,1,8,fp)!=8||png_sig_cmp(sig,0,8)){fclose(fp);return 0;}
 png_structp png=png_create_read_struct(PNG_LIBPNG_VER_STRING,NULL,NULL,NULL);
 if(!png){fclose(fp);return 0;}
 png_infop info=png_create_info_struct(png);
 if(!info){png_destroy_read_struct(&png,NULL,NULL);fclose(fp);return 0;}
 png_bytep *rows=NULL;
 if(setjmp(png_jmpbuf(png))){free(rows);image_free(im);png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 0;}
 png_init_io(png,fp);png_set_sig_bytes(png,8);png_read_info(png,info);
 png_uint_32 w=png_get_image_width(png,info),h=png_get_image_height(png,info);
 if(!image_size_ok(w,h)){png_error(png,"Image too large");}
 int color=png_get_color_type(png,info),depth=png_get_bit_depth(png,info);
 if(depth==16)png_set_strip_16(png);
 if(color==PNG_COLOR_TYPE_PALETTE)png_set_palette_to_rgb(png);
 if(color==PNG_COLOR_TYPE_GRAY&&depth<8)png_set_expand_gray_1_2_4_to_8(png);
 if(png_get_valid(png,info,PNG_INFO_tRNS))png_set_tRNS_to_alpha(png);
 if(color==PNG_COLOR_TYPE_GRAY||color==PNG_COLOR_TYPE_GRAY_ALPHA)png_set_gray_to_rgb(png);
 if(!(color&PNG_COLOR_MASK_ALPHA)&&!png_get_valid(png,info,PNG_INFO_tRNS))png_set_add_alpha(png,255,PNG_FILLER_AFTER);
 png_read_update_info(png,info);
 if(png_get_rowbytes(png,info)!=(size_t)w*4)png_error(png,"Unexpected PNG format");
 im->rgba=malloc((size_t)w*h*4);rows=malloc((size_t)h*sizeof *rows);
 if(!im->rgba||!rows)png_error(png,"Out of memory");
 for(png_uint_32 y=0;y<h;y++)rows[y]=im->rgba+(size_t)y*w*4;
 png_read_image(png,rows);png_read_end(png,NULL);im->w=(int)w;im->h=(int)h;
 free(rows);png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 1;
}
static int image_png(const char *path,UserImage *im){
 if(png_graphics_mode()&&image_png_probe(path,im))return 1;
 return image_png_full(path,im);
}
static int image_gif(const char *path,UserImage *im){
 struct stat st;if(stat(path,&st)||st.st_size>33554432)return 0;
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);if(!gif)return 0;
 int ok=0;
 if(DGifSlurp(gif)==GIF_OK&&image_size_ok((unsigned)gif->SWidth,(unsigned)gif->SHeight)&&gif->ImageCount>0&&gif->ImageCount<=200){
  int w=gif->SWidth,h=gif->SHeight;im->rgba=calloc((size_t)w*h,4);
  if(im->rgba){
   SavedImage *frame=&gif->SavedImages[0];ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   int transparent=-1;
   for(int k=0;k<frame->ExtensionBlockCount;k++){
    ExtensionBlock *ex=&frame->ExtensionBlocks[k];
    if(ex->Function==GRAPHICS_EXT_FUNC_CODE&&ex->ByteCount>=4&&(ex->Bytes[0]&1))transparent=(unsigned char)ex->Bytes[3];
   }
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=w||yy>=h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==transparent)continue;
     GifColorType c=map->Colors[index];unsigned char *out=im->rgba+((size_t)yy*w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
    im->w=w;im->h=h;ok=1;
   }
  }
 }
 if(ok)im->gif=gif;
 else {DGifCloseFile(gif,&err);image_free(im);}
 return ok;
}
static int image_load(const char *path,UserImage *im){
 const char *ext=strrchr(path,'.');
 if(ext&&(!strcasecmp(ext,".png")))return image_png(path,im);
 if(ext&&(!strcasecmp(ext,".gif")))return image_gif(path,im);
 return 0;
}
static void image_row(const UserImage *im,size_t row,int width,int height){
 for(int x=0;x<width;x++){
  double sx=((double)x+0.5)*im->w/width-0.5;
  double sy[2]={((double)(2*row)+0.5)*im->h/(2*height)-0.5,
                ((double)(2*row)+1.5)*im->h/(2*height)-0.5};
  unsigned char colors[2][4],mixed[2][4];
  int x0=(int)floor(sx);double fx=sx-x0;
  if(x0<0){x0=0;fx=0;}if(x0>=im->w-1){x0=im->w-1;fx=0;}
  int x1=x0+1<im->w?x0+1:x0;
  for(int k=0;k<2;k++){
   int y0=(int)floor(sy[k]);double fy=sy[k]-y0;
   if(y0<0){y0=0;fy=0;}if(y0>=im->h-1){y0=im->h-1;fy=0;}
   int y1=y0+1<im->h?y0+1:y0;
   const unsigned char *p[4]={
    im->rgba+((size_t)y0*im->w+x0)*4,im->rgba+((size_t)y0*im->w+x1)*4,
    im->rgba+((size_t)y1*im->w+x0)*4,im->rgba+((size_t)y1*im->w+x1)*4};
   double weights[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double a=0,r=0,g=0,b=0;
   for(int j=0;j<4;j++){double aw=weights[j]*p[j][3];a+=aw;r+=aw*p[j][0];g+=aw*p[j][1];b+=aw*p[j][2];}
   colors[k][3]=(unsigned char)lround(a);
   colors[k][0]=a>0?(unsigned char)lround(r/a):0;
   colors[k][1]=a>0?(unsigned char)lround(g/a):0;
   colors[k][2]=a>0?(unsigned char)lround(b/a):0;
   tux_pixel_mix(colors[k],mixed[k]);
  }
  pixel_pair(mixed[0],mixed[1],colors[0][3]>=12,colors[1][3]>=12);
 }
 if(output_color)fputs(R,stdout);
}



/* PNG uses two distinct native placements: Kitty supports scrollback-linked
   Unicode placeholders; Konsole supports cursor-bound placement but does NOT
   support those placeholders. Do not send private-use glyphs to Konsole. */
static int image_backend=0;
static int terminal_is_kitty(void){
 const char *term=getenv("TERM"),*id=getenv("KITTY_WINDOW_ID");
 return (id&&*id)||(term&&strstr(term,"kitty")!=NULL);
}
static int terminal_is_konsole(void){
 if(terminal_is_kitty())return 0;
 const char *version=getenv("KONSOLE_VERSION"),*service=getenv("KONSOLE_DBUS_SERVICE"),*program=getenv("TERM_PROGRAM");
 return (version&&*version)||(service&&*service)||(program&&!strcasecmp(program,"konsole"));
}
/* 0 = ANSI fallback, 1 = Kitty placeholders, 2 = Konsole physical placement.
   Neither terminal is assumed to accept graphics in a pipe. */
static int png_graphics_mode(void){
 if(image_backend==1)return 0;
 if(image_backend==3)return 2;
 if(image_backend==2)return terminal_is_konsole()?2:1;
 if(!isatty(STDOUT_FILENO))return 0;
 return terminal_is_kitty()?1:(terminal_is_konsole()?2:0);
}
static int native_graphics_supported(void){
 if(image_backend==1)return 0;
 if(terminal_is_konsole())return 0;
 if(image_backend==2)return 1;
 if(!isatty(STDOUT_FILENO))return 0;
 return terminal_is_kitty();
}
static void kitty_payload(const char *header,const unsigned char *data,size_t len){
 static const char alphabet[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 size_t i=0;int first=1;
 /* Every continuation of an animated frame MUST carry a=f. Otherwise Kitty
    can accept the root frame but silently lose subsequent large GIF frames. */
 const int frame=strncmp(header,"a=f,",4)==0;
 while(i<len){
  size_t count=len-i;if(count>3072)count=3072;
  int more=i+count<len;
  if(first)printf("\033_G%s,m=%d;",header,more);
  else if(frame)printf("\033_Ga=f,m=%d;",more);
  else printf("\033_Gm=%d;",more);
  for(size_t j=0;j<count;j+=3){
   unsigned a=data[i+j],b=j+1<count?data[i+j+1]:0,c=j+2<count?data[i+j+2]:0;
   putchar(alphabet[a>>2]);putchar(alphabet[((a&3)<<4)|(b>>4)]);
   putchar(j+1<count?alphabet[((b&15)<<2)|(c>>6)]:'=');
   putchar(j+2<count?alphabet[c&63]:'=');
  }
  fputs("\033\\",stdout);i+=count;first=0;
 }
}
/* RGBA is zlib-compressed before base64: huge GIFs no longer fall back to a
   grainy static preview just because the raw frame count exceeds 48 MiB. */
static void kitty_rgba(const char *header,const unsigned char *pixels,size_t len){
 uLongf bound=compressBound((uLong)len),compressed_len=bound;
 unsigned char *compressed=malloc((size_t)bound);
 if(compressed&&compress2(compressed,&compressed_len,pixels,(uLong)len,Z_BEST_SPEED)==Z_OK&&compressed_len<len){
  char control[192];snprintf(control,sizeof control,"%s,o=z",header);
  kitty_payload(control,compressed,(size_t)compressed_len);
 }else kitty_payload(header,pixels,len);
 free(compressed);
}
static unsigned kitty_image_id=0;
/* Send the ORIGINAL PNG bytes (Kitty f=100), not a decoded/resampled RGBA
   copy. This preserves exact image quality and avoids a second encode. */
static int kitty_png_render(const char *path,int cols,int rows,int physical){
 if(cols<1||rows<1||cols>120||rows>120)return 0;
 struct stat st;
 if(stat(path,&st)||st.st_size<=8||st.st_size>33554432)return 0;
 FILE *fp=fopen(path,"rb");if(!fp)return 0;
 size_t len=(size_t)st.st_size;
 unsigned char *data=malloc(len);
 if(!data){fclose(fp);return 0;}
 int ok=fread(data,1,len,fp)==len;
 fclose(fp);
 if(ok){
  unsigned id=((unsigned)getpid()*2654435761u^(unsigned)time(NULL))&0xffffffu;
  if(!id)id=1;
  kitty_image_id=id;
  char header[128];snprintf(header,sizeof header,"a=t,f=100,i=%u,q=2",id);
  kitty_payload(header,data,len);
  if(physical)printf("\033_Ga=p,i=%u,c=%d,r=%d,C=1,q=2;\033\\",id,cols,rows);
  else printf("\033_Ga=p,U=1,i=%u,c=%d,r=%d,q=2;\033\\",id,cols,rows);
 }
 free(data);
 return ok;
}
/* Scale only when the source is larger than what the terminal can actually
   show.  Bilinear RGBA interpolation is premultiplied to keep transparency
   crisp (no washed-out/white border); pixels are losslessly transferred. */
static void image_downsample(const unsigned char *src,int sw,int sh,
                             unsigned char *dst,int dw,int dh){
 if(sw==dw&&sh==dh){memcpy(dst,src,(size_t)dw*dh*4);return;}
 for(int y=0;y<dh;y++){
  double sy=((double)y+0.5)*sh/dh-0.5;
  int y0=(int)floor(sy);double fy=sy-y0;
  if(y0<0){y0=0;fy=0;}if(y0>=sh-1){y0=sh-1;fy=0;}
  int y1=y0+1<sh?y0+1:y0;
  for(int x=0;x<dw;x++){
   double sx=((double)x+0.5)*sw/dw-0.5;
   int x0=(int)floor(sx);double fx=sx-x0;
   if(x0<0){x0=0;fx=0;}if(x0>=sw-1){x0=sw-1;fx=0;}
   int x1=x0+1<sw?x0+1:x0;
   const unsigned char *a=src+((size_t)y0*sw+x0)*4,*b=src+((size_t)y0*sw+x1)*4;
   const unsigned char *c=src+((size_t)y1*sw+x0)*4,*d=src+((size_t)y1*sw+x1)*4;
   const unsigned char *p[4]={a,b,c,d};
   double w[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double alpha=0,r=0,g=0,blue=0;
   for(int k=0;k<4;k++){double wa=w[k]*p[k][3];alpha+=wa;r+=wa*p[k][0];g+=wa*p[k][1];blue+=wa*p[k][2];}
   unsigned char *o=dst+((size_t)y*dw+x)*4;
   o[3]=(unsigned char)lround(alpha);
   o[0]=alpha>0?(unsigned char)lround(r/alpha):0;
   o[1]=alpha>0?(unsigned char)lround(g/alpha):0;
   o[2]=alpha>0?(unsigned char)lround(blue/alpha):0;
  }
 }
}
/* Scrollback-linked Kitty image placeholders (official Unicode mapping). */
static const unsigned short kitty_marks[]={0x0305,0x030D,0x030E,0x0310,0x0312,0x033D,0x033E,0x033F,0x0346,0x034A,0x034B,0x034C,0x0350,0x0351,0x0352,0x0357,0x035B,0x0363,0x0364,0x0365,0x0366,0x0367,0x0368,0x0369,0x036A,0x036B,0x036C,0x036D,0x036E,0x036F,0x0483,0x0484,0x0485,0x0486,0x0487,0x0592,0x0593,0x0594,0x0595,0x0597,0x0598,0x0599,0x059C,0x059D,0x059E,0x059F,0x05A0,0x05A1,0x05A8,0x05A9,0x05AB,0x05AC,0x05AF,0x05C4,0x0610,0x0611,0x0612,0x0613,0x0614,0x0615,0x0616,0x0617,0x0657,0x0658,0x0659,0x065A,0x065B,0x065D,0x065E,0x06D6,0x06D7,0x06D8,0x06D9,0x06DA,0x06DB,0x06DC,0x06DF,0x06E0,0x06E1,0x06E2,0x06E4,0x06E7,0x06E8,0x06EB,0x06EC,0x0730,0x0732,0x0733,0x0735,0x0736};
static void kitty_utf8(unsigned code){
 if(code<0x800){putchar(0xc0|(code>>6));putchar(0x80|(code&63));}
 else if(code<0x10000){putchar(0xe0|(code>>12));putchar(0x80|((code>>6)&63));putchar(0x80|(code&63));}
 else {putchar(0xf0|(code>>18));putchar(0x80|((code>>12)&63));putchar(0x80|((code>>6)&63));putchar(0x80|(code&63));}
}
static void kitty_placeholder_row(int row,int width){
 unsigned id=kitty_image_id;
 printf("\033[38;2;%u;%u;%um",(id>>16)&255,(id>>8)&255,id&255);
 for(int col=0;col<width;col++){
  kitty_utf8(0x10eeee);
  kitty_utf8(kitty_marks[row]);
  kitty_utf8(kitty_marks[col]);
 }
 fputs("\033[39m",stdout);
}

static int kitty_render(const char *path,const UserImage *im,int cols,int rows,int cycles){
 if(!native_graphics_supported()||cols<1||rows<1||cols>90||rows>90)return 0;
 const char *ext=strrchr(path,'.');
 int gif_file=ext&&!strcasecmp(ext,".gif");
 GifFileType *gif=gif_file?im->gif:NULL;
 if(gif_file){if(!gif)return 0;
  if(gif->ImageCount<1||gif->ImageCount>200||gif->SWidth!=im->w||gif->SHeight!=im->h)return 0;
 }
 size_t bytes=(size_t)im->w*im->h*4;
 /* Render at the terminal's real pixel density, without upscaling originals.
    Keep more image detail than two ANSI half-block pixels per cell. */
 int render_w=im->w,render_h=im->h;
 double factor=1.0;
 if(render_w>cols*10)factor=(double)(cols*10)/render_w;
 if(render_h*factor>rows*20)factor=(double)(rows*20)/render_h;
 if(factor<1.0){render_w=(int)lround(im->w*factor);render_h=(int)lround(im->h*factor);}
 if(render_w<1)render_w=1;
 if(render_h<1)render_h=1;
 size_t framebytes=(size_t)render_w*render_h*4;
 unsigned char *scaled=malloc(framebytes);
 if(!scaled)return 0;
 unsigned char *canvas=NULL,*previous=NULL;
 if(gif){canvas=calloc(bytes,1);previous=malloc(bytes);
  if(!canvas||!previous){free(scaled);free(canvas);free(previous);return 0;}
 }
 unsigned id=((unsigned)getpid()*2654435761u ^ (unsigned)time(NULL))&0xffffffu;if(!id)id=1; kitty_image_id=id;
 int prev_disp=0,px=0,py=0,pw=0,ph=0;
 int transfer_frames=gif?(cycles==-2?1:gif->ImageCount):1;
 for(int f=0;f<transfer_frames;f++){
  const unsigned char *pixels=im->rgba;
  GraphicsControlBlock gcb={0};
  if(gif){
   SavedImage *frame=&gif->SavedImages[f];
   if(f){
    if(prev_disp==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
     if(x>=0&&x<im->w&&y>=0&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
    }else if(prev_disp==3)memcpy(canvas,previous,bytes);
   }
   memcpy(previous,canvas,bytes);
   DGifSavedExtensionToGCB(gif,f,&gcb);
   ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
     GifColorType c=map->Colors[index];unsigned char *out=canvas+((size_t)yy*im->w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
   }
   prev_disp=gcb.DisposalMode;px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
   pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
   pixels=canvas;
  }
  image_downsample(pixels,im->w,im->h,scaled,render_w,render_h);
  char header[160];
  /* Transmit without placing first; after every frame is loaded, create the
     virtual placement whose Unicode cells can scroll like normal text. */
  if(f==0)snprintf(header,sizeof header,"a=t,f=32,s=%d,v=%d,i=%u,q=2",render_w,render_h,id);
  else snprintf(header,sizeof header,"a=f,f=32,s=%d,v=%d,i=%u,X=1,z=%d,q=2",render_w,render_h,id,
   gcb.DelayTime>1?gcb.DelayTime*10:100);
  kitty_rgba(header,scaled,framebytes);
  if(f==0&&gif){
   int delay=gcb.DelayTime>1?gcb.DelayTime*10:100;
   printf("\033_Ga=a,i=%u,r=1,z=%d,q=2\033\\",id,delay);
  }
  /* Mirror Kitty's own icat loader: once two frames exist, enter loading
     mode.  After text placeholders are printed, switch to normal looping. */
  if(f==1&&gif&&transfer_frames>1)
   printf("\033_Ga=a,i=%u,s=2,q=2\033\\",id);
 }
 printf("\033_Ga=p,U=1,i=%u,c=%d,r=%d,q=2;\033\\",id,cols,rows);
 if(gif&&gif->ImageCount>1&&cycles!=-2)
  printf("\033_Ga=a,i=%u,s=3,v=%d,q=2\033\\",id,cycles>0?cycles+1:1);
 free(scaled);free(canvas);free(previous);
 return 1;
}
/* GIF playback: background repaint is restricted to the image rectangle.
   Cursor position is preserved for interactive shell input.
   Composites transparency and disposal=2 (restore background); disposal=3
   restores the previous canvas. */
static void gif_animate(const char *path,UserImage *im,int width,int height,size_t output_rows,int cycles,int start_row){
 (void)output_rows;
 if(width<1||height<1||!isatty(STDOUT_FILENO))return;
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);if(!gif)return;
 if(DGifSlurp(gif)!=GIF_OK||gif->ImageCount<2||gif->ImageCount>200||gif->SWidth!=im->w||gif->SHeight!=im->h){DGifCloseFile(gif,&err);return;}
 size_t bytes=(size_t)im->w*im->h*4;
 unsigned char *canvas=calloc(bytes,1),*previous=malloc(bytes);
 if(!canvas||!previous){free(canvas);free(previous);DGifCloseFile(gif,&err);return;}
 for(int cycle=0;cycles==0||cycle<cycles;cycle++){
  memset(canvas,0,bytes);
  int prior_disposal=0,px=0,py=0,pw=0,ph=0;
  for(int f=0;f<gif->ImageCount;f++){
   SavedImage *frame=&gif->SavedImages[f];
   if(f>0){
    if(prior_disposal==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
     if(x>=0&&y>=0&&x<im->w&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
    }else if(prior_disposal==3)memcpy(canvas,previous,bytes);
   }
   memcpy(previous,canvas,bytes);
   GraphicsControlBlock gcb={0};
   DGifSavedExtensionToGCB(gif,f,&gcb);
   ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
   if(map&&frame->RasterBits){
    for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
     int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
     if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
     int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
     if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
     GifColorType c=map->Colors[index];unsigned char *out=canvas+((size_t)yy*im->w+xx)*4;
     out[0]=c.Red;out[1]=c.Green;out[2]=c.Blue;out[3]=255;
    }
   }
   prior_disposal=gcb.DisposalMode;
   px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
   pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
   UserImage view={canvas,im->w,im->h,NULL};
   /* Atomic terminal update where supported (DEC 2026); no cursor jumps. */
   fputs("\033[?2026h\0337",stdout);
   for(int y=0;y<height;y++){
    printf("\033[%d;1H",start_row+y);
    image_row(&view,(size_t)y,width,height);
   }
   fputs("\033[0m\0338\033[?2026l",stdout);fflush(stdout);
   int delay=gcb.DelayTime>0?gcb.DelayTime*10:100;
   if(delay<30)delay=30;
   if(delay>1000)delay=1000;
   struct timespec ts={delay/1000,(delay%1000)*1000000L};nanosleep(&ts,NULL);
  }
 }
 free(canvas);free(previous);DGifCloseFile(gif,&err);
}


/* Ask the terminal for the starting row before printing the fetch.  This is
   only used for interactive TTYs; no shell input is consumed after startup. */
static int __attribute__((unused)) cursor_row_query(void){
 if(!isatty(STDIN_FILENO)||!isatty(STDOUT_FILENO))return 0;
 struct termios saved,raw;
 if(tcgetattr(STDIN_FILENO,&saved)!=0)return 0;
 raw=saved;raw.c_lflag&=(tcflag_t)~(ICANON|ECHO);
 raw.c_cc[VMIN]=0;raw.c_cc[VTIME]=0;
 if(tcsetattr(STDIN_FILENO,TCSANOW,&raw)!=0)return 0;
 fflush(stdout);write(STDOUT_FILENO,"\033[6n",4);
 char buf[48];size_t n=0;int row=0;
 for(int attempts=0;attempts<4&&n<sizeof(buf)-1;attempts++){
  fd_set fds;FD_ZERO(&fds);FD_SET(STDIN_FILENO,&fds);
  struct timeval tv={0,35000};
  if(select(STDIN_FILENO+1,&fds,NULL,NULL,&tv)<=0)break;
  ssize_t got=read(STDIN_FILENO,buf+n,sizeof(buf)-1-n);
  if(got<=0)break;
  n+=(size_t)got;buf[n]=0;
  int col=0;if(sscanf(buf,"\033[%d;%dR",&row,&col)==2&&row>0)break;
 }
 tcsetattr(STDIN_FILENO,TCSANOW,&saved);
 return row;
}
/* Detached worker writes only to its own terminal, and stops when the shell
   that launched NISFETCH exits. Never holds stdin or a shell job open. */
/* Explicit animated preview in the alternate screen. The shell is deliberately
   paused while this preview runs; it never writes over live shell input. */
static volatile sig_atomic_t preview_stop=0;
static void preview_signal(int sig){(void)sig;preview_stop=1;}
static void gif_preview(const char *path,UserImage *im,int width,int height,int cycles){
 if(!isatty(STDOUT_FILENO))return;
 struct sigaction sa={0},oldint={0},oldterm={0};
 sa.sa_handler=preview_signal;sigemptyset(&sa.sa_mask);
 sigaction(SIGINT,&sa,&oldint);sigaction(SIGTERM,&sa,&oldterm);
 preview_stop=0;
 fputs("\033[?1049h\033[?25l",stdout);fflush(stdout);
 int err=0;GifFileType *gif=DGifOpenFileName(path,&err);
 if(gif && DGifSlurp(gif)==GIF_OK && gif->ImageCount>0){
  size_t bytes=(size_t)im->w*im->h*4;
  unsigned char *canvas=calloc(bytes,1),*previous=malloc(bytes);
  if(canvas&&previous){
   for(int cycle=0;!preview_stop&&(cycles==0||cycle<cycles);cycle++){
    memset(canvas,0,bytes);
    int prior_disposal=0,px=0,py=0,pw=0,ph=0;
    for(int f=0;f<gif->ImageCount&&!preview_stop;f++){
     SavedImage *frame=&gif->SavedImages[f];
     if(f>0){
      if(prior_disposal==2){for(int y=py;y<py+ph;y++)for(int x=px;x<px+pw;x++)
       if(x>=0&&y>=0&&x<im->w&&y<im->h)memset(canvas+((size_t)y*im->w+x)*4,0,4);
      }else if(prior_disposal==3)memcpy(canvas,previous,bytes);
     }
     memcpy(previous,canvas,bytes);
     GraphicsControlBlock gcb={0};DGifSavedExtensionToGCB(gif,f,&gcb);
     ColorMapObject *map=frame->ImageDesc.ColorMap?frame->ImageDesc.ColorMap:gif->SColorMap;
     if(map&&frame->RasterBits){
      for(int y=0;y<frame->ImageDesc.Height;y++)for(int x=0;x<frame->ImageDesc.Width;x++){
       int xx=frame->ImageDesc.Left+x,yy=frame->ImageDesc.Top+y;
       if(xx<0||yy<0||xx>=im->w||yy>=im->h)continue;
       int index=frame->RasterBits[y*frame->ImageDesc.Width+x];
       if(index>=map->ColorCount||index==gcb.TransparentColor)continue;
       GifColorType c=map->Colors[index];unsigned char *o=canvas+((size_t)yy*im->w+xx)*4;
       o[0]=c.Red;o[1]=c.Green;o[2]=c.Blue;o[3]=255;
      }
     }
     prior_disposal=gcb.DisposalMode;px=frame->ImageDesc.Left;py=frame->ImageDesc.Top;
     pw=frame->ImageDesc.Width;ph=frame->ImageDesc.Height;
     UserImage view={canvas,im->w,im->h,NULL};
     fputs("\033[H",stdout);
     for(int y=0;y<height;y++){image_row(&view,(size_t)y,width,height);putchar('\n');}
     fputs("\033[0m",stdout);fflush(stdout);
     int delay=gcb.DelayTime>0?gcb.DelayTime*10:100;
     if(delay<30)delay=30;
     if(delay>1000)delay=1000;
     struct timespec ts={delay/1000,(delay%1000)*1000000L};
     while(!preview_stop&&nanosleep(&ts,&ts)<0&&errno==EINTR){}
    }
   }
  }
  free(canvas);free(previous);
 }
 if(gif)DGifCloseFile(gif,&err);
 fputs("\033[0m\033[?25h\033[?1049l",stdout);fflush(stdout);
 sigaction(SIGINT,&oldint,NULL);sigaction(SIGTERM,&oldterm,NULL);
}

static void __attribute__((unused)) start_gif_worker(const char *path,UserImage *im,int width,int height,
                             size_t rows,int cycles,int start_row){
 if(start_row<1||!isatty(STDOUT_FILENO))return;
 char *tty=ttyname(STDOUT_FILENO);if(!tty)return;
 char tty_path[256];snprintf(tty_path,sizeof tty_path,"%s",tty);
 pid_t shell=getppid();fflush(stdout);
 pid_t child=fork();if(child!=0)return;
 if(setsid()<0)_exit(0);
 int fd=open(tty_path,O_WRONLY|O_NOCTTY|O_CLOEXEC);
 if(fd<0)_exit(0);
 dup2(fd,STDOUT_FILENO);if(fd!=STDOUT_FILENO)close(fd);
 close(STDIN_FILENO);close(STDERR_FILENO);
 signal(SIGINT,SIG_IGN);signal(SIGHUP,SIG_DFL);signal(SIGPIPE,SIG_DFL);
 /* Monitor the original shell in a separate watchdog process. */
 pid_t watcher=fork();
 if(watcher==0){
  for(;;){struct timespec t={1,0};nanosleep(&t,NULL);
   if(kill(shell,0)<0&&errno==ESRCH){kill(getppid(),SIGTERM);_exit(0);}
  }
 }
 if(watcher<0)_exit(0);
 /* Unbuffered output prevents stale frame data in a forked stdio buffer. */
 setvbuf(stdout,NULL,_IONBF,0);
 gif_animate(path,im,width,height,rows,cycles,start_row);
 kill(watcher,SIGTERM);
 _exit(0);
}

typedef struct {const char *name,*color;int height;const char *rows[8];} DistroLogo;
static const DistroLogo distro_logos[]={
 {"arch","#1793d1",7,{"       /\\       ","      /  \\      ","     /\\   \\     ","    /      \\    ","   /   ,,   \\   ","  /   |  |  -\\  "," /_-''    ''-_\\ "}},
 {"debian","#d70a53",7,{"    _____     ","   /  __ \\    ","  |  /    |   ","  |  \\___-    ","  -_          ","    --_       ",""}},
 {"ubuntu","#e95420",7,{"    .--.     ","  /  __  \\   "," |  (  )  |  ","  \\  --  /   ","    '--'     ","",""}},
 {"fedora","#51a2da",7,{"   ______    ","  / ____ \\   "," | |  __| |  "," | | |__  |  "," |  \\___| |  ","  \\______/   ",""}},
 {"manjaro","#35bf5c",7,{" |\\  | | | | "," | \\ | | | | "," |  \\| | | | "," | | | | | | "," |_| |_| |_| ","",""}},
 {"linuxmint","#87cf3e",7,{"  __________  "," /  ______  \\ "," | |  __  | | "," | | |  | | | "," | |_|  |_| | "," \\__________/ ",""}},
 {"opensuse","#73ba25",7,{"    _______   ","  /  ___  \\  "," /  /   \\  \\ "," | |  () | | "," \\  \\___/  / ","  \\_______/  ",""}},
 {"gentoo","#b7a2d3",7,{"   ______    ","  /  __  \\   "," /  /  \\  \\  "," | |   /  /  "," \\  \\__/  /  ","  \\______/   ",""}},
 {"alpine","#0d597f",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / /  \\ \\   ","  /_/    \\_\\  ","",""}},
 {"nixos","#7ebae4",7,{"  \\  /\\  /   ","   \\/  \\/    ","  /\\  /\\    "," /  \\/  \\   "," \\  /\\  /   ","  \\/  \\/    ",""}},
 {"android","#3ddc84",7,{"   /\\    /\\  ","  /  \\__/  \\ "," |  o    o | "," |          | "," |__________| ","  |  |  |  | ",""}},
 {"termux","#80cbc4",7,{"  __________ "," | >_       |"," |          |"," |__________|","","",""}},
 {"void","#478061",7,{"    ______    ","   / ____ \\   ","  | |    | |  ","  | |____| |  ","   \\______/   ","",""}},
 {"artix","#10a0cc",7,{"      /\\      ","     /  \\     ","    / /\\ \\    ","   / ____ \\   ","  /_/    \\_\\  ","",""}},
 {"endeavouros","#7f3fbf",7,{"       /\\     ","      /  \\    ","     / /\\ \\   ","    / /  \\ \\  ","   /_/____\\_\\ ","",""}},
 {"kali","#557c94",7,{"   __       ","  /  \\___   "," /  / __ \\  "," |  \\___/ / ","  \\______/  ","",""}},
 {"raspbian","#c51a4a",7,{"   .-''-.   ","  / .--. \\  "," | (____) | ","  \\ (__) /  ","   '----'   ","",""}},
 {"slackware","#526db0",7,{"   _______   ","  |   S   |  ","  |_______|  ","","","",""}},
 {"redhat","#ee0000",7,{"   _______   ","  /       \\  "," |  REDHAT  | ","  \\_______/  ","","",""}},
 {"popos","#48b9c7",7,{"  __________ "," |  POP!_   |"," |__________|","","","",""}},
};
static const DistroLogo *find_logo(const char *name){
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)
  if(!strcmp(name,distro_logos[i].name))return &distro_logos[i];
 return NULL;
}
static int distro_width(const DistroLogo *logo){
 int width=0;for(int i=0;i<logo->height;i++){int n=(int)strlen(logo->rows[i]);if(n>width)width=n;}
 return width;
}
static void distro_row(const DistroLogo *logo,int row,int width){
 unsigned int r=255,g=255,b=255;
 sscanf(logo->color+1,"%2x%2x%2x",&r,&g,&b);
 const char *line=logo->rows[row];int n=(int)strlen(line);
 if(output_color)printf("\033[1;38;2;%u;%u;%um",r,g,b);
 for(int i=0;i<width;i++)putchar(i<n?line[i]:' ');
 if(output_color)fputs(R,stdout);
}
static void list_logos(void){
 puts("tux (default)");
 for(size_t i=0;i<sizeof distro_logos/sizeof distro_logos[0];i++)puts(distro_logos[i].name);
}

/* User-supplied logo artwork, same 58x72 pixel canvas as the default Tux. */
static const unsigned char *distro_pixels(const char *name){
 if(!strcmp(name,"arch"))return logo_arch;
 if(!strcmp(name,"debian"))return logo_debian;
 if(!strcmp(name,"fedora"))return logo_fedora;
 if(!strcmp(name,"popos"))return logo_popos;
 if(!strcmp(name,"kali"))return logo_kali;
 if(!strcmp(name,"linuxmint"))return logo_linuxmint;
 if(!strcmp(name,"redhat"))return logo_redhat;
 if(!strcmp(name,"gentoo"))return logo_gentoo;
 if(!strcmp(name,"opensuse"))return logo_opensuse;
 if(!strcmp(name,"slackware"))return logo_slackware;
 if(!strcmp(name,"alpine"))return logo_alpine;
 if(!strcmp(name,"void"))return logo_void;
 if(!strcmp(name,"manjaro"))return logo_manjaro;
 if(!strcmp(name,"nixos"))return logo_nixos;
 if(!strcmp(name,"android"))return logo_android;

 return NULL;
}
/* Truecolor upper/lower half-block renderer; alpha zero uses terminal default
   background, so the logo has no ugly opaque rectangle. */
static void pixel_logo_bounds(const unsigned char *img,int *top,int *bottom){
 int first=DISTRO_H,last=-1;
 for(int y=0;y<DISTRO_H;y++)
  for(int x=0;x<DISTRO_W;x++)
   if(img[(y*DISTRO_W+x)*4+3]>=96){
    if(y<first)first=y;
    if(y>last)last=y;
   }
 if(last<first){first=0;last=DISTRO_H-1;}
 *top=first;*bottom=last+1;
}
static void pixel_logo_row(const unsigned char *img,size_t row,int width,int height,int crop_top,int crop_bottom){
 for(int x=0;x<width;x++){
  /* Premultiplied bilinear sampling keeps colored logos sharp without the
     white halo produced by interpolating transparent RGB directly. */
  unsigned char color[2][4],mixed[2][4];
  double sx=((double)x+0.5)*DISTRO_W/width-0.5;
  int x0=(int)floor(sx);double fx=sx-x0;
  if(x0<0){x0=0;fx=0;}if(x0>=DISTRO_W-1){x0=DISTRO_W-1;fx=0;}
  int x1=x0+1<DISTRO_W?x0+1:x0;
  for(int k=0;k<2;k++){
   double sy=crop_top+((double)(2*row)+0.5+k)*(crop_bottom-crop_top)/(2.0*height)-0.5;
   int y0=(int)floor(sy);double fy=sy-y0;
   if(y0<0){y0=0;fy=0;}if(y0>=DISTRO_H-1){y0=DISTRO_H-1;fy=0;}
   int y1=y0+1<DISTRO_H?y0+1:y0;
   const unsigned char *p[4]={img+((size_t)y0*DISTRO_W+x0)*4,img+((size_t)y0*DISTRO_W+x1)*4,
    img+((size_t)y1*DISTRO_W+x0)*4,img+((size_t)y1*DISTRO_W+x1)*4};
   double weights[4]={(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy};
   double alpha=0,r=0,g=0,b=0;
   for(int j=0;j<4;j++){double a=weights[j]*p[j][3];alpha+=a;r+=a*p[j][0];g+=a*p[j][1];b+=a*p[j][2];}
   color[k][3]=(unsigned char)lround(alpha);
   color[k][0]=alpha>0?(unsigned char)lround(r/alpha):0;
   color[k][1]=alpha>0?(unsigned char)lround(g/alpha):0;
   color[k][2]=alpha>0?(unsigned char)lround(b/alpha):0;
   tux_pixel_mix(color[k],mixed[k]);
  }
  pixel_pair(mixed[0],mixed[1],color[0][3]>=26,color[1][3]>=26);
 }
 if(output_color)fputs(R,stdout);
}

/* Small JSONC reader: strings, booleans, numbers, arrays, objects, comments.
   Unknown keys are ignored; invalid config is reported, never executed. */
typedef struct {const char *p;int error;} Json;
static void jspace(Json *j){
 for(;;){while(isspace((unsigned char)*j->p))j->p++;
  if(j->p[0]=='/'&&j->p[1]=='/'){j->p+=2;while(*j->p&&*j->p!='\n')j->p++;continue;}
  if(j->p[0]=='/'&&j->p[1]=='*'){j->p+=2;while(*j->p&&!(j->p[0]=='*'&&j->p[1]=='/'))j->p++;if(*j->p)j->p+=2;else j->error=1;continue;}
  break;
 }
}
static int jstring(Json *j,char *out,size_t cap){
 jspace(j);if(*j->p!='"'){j->error=1;return 0;}j->p++;
 size_t n=0;
 while(*j->p&&*j->p!='"'){
  unsigned char c=(unsigned char)*j->p++;
  if(c=='\\'){c=(unsigned char)*j->p++;if(!c){j->error=1;return 0;}
   if(c=='n')c='\n';else if(c=='t')c='\t';else if(c=='r')c='\r';
   else if(c=='u'){/* Skip 4 hex digits; no unicode keys are needed. */
    for(int k=0;k<4;k++){if(!isxdigit((unsigned char)*j->p)){j->error=1;return 0;}j->p++;}
    c='?';
   }
  }
  if(n+1<cap)out[n++]=(char)c;else j->error=1;
 }
 if(*j->p!='"'){j->error=1;return 0;}j->p++;if(cap)out[n]=0;return !j->error;
}
static void jskip(Json *j,int depth){
 if(depth>32){j->error=1;return;}jspace(j);
 if(*j->p=='"'){char v[512];jstring(j,v,sizeof v);return;}
 if(*j->p=='{'||*j->p=='['){
  char end=*j->p++=='{'?'}':']';jspace(j);
  while(*j->p&&*j->p!=end&&!j->error){
   if(*j->p==','||*j->p==':'){j->p++;continue;}
   jskip(j,depth+1);jspace(j);
  }
  if(*j->p==end)j->p++;else j->error=1;return;
 }
 if(!*j->p){j->error=1;return;}
 while(*j->p&&!isspace((unsigned char)*j->p)&&*j->p!=','&&*j->p!=']'&&*j->p!='}')j->p++;
}
static int jkey(Json *j,char *key,size_t cap){
 jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}
 if(*j->p==','){j->p++;jspace(j);if(*j->p=='}'){j->p++;return 0;}
 if(!*j->p){j->error=1;return 0;}}
 jstring(j,key,cap);jspace(j);if(*j->p==':')j->p++;else j->error=1;
 return !j->error;
}
static char cfg_order[8192]="";
static char cfg_logo_type[64]="tux";
static char cfg_image_path[1024]="";
static int cfg_logo=1,cfg_palette=1,cfg_auto=1,cfg_logo_width=0,cfg_gap=2;
static int cfg_key[3]={255,211,110},cfg_val[3]={255,255,255};
static void cfg_color(const char *v,int rgb[3]){
 if(strlen(v)!=7||v[0]!='#')return;
 unsigned int a,b,c;if(sscanf(v+1,"%2x%2x%2x",&a,&b,&c)==3){rgb[0]=(int)a;rgb[1]=(int)b;rgb[2]=(int)c;}
}
static void cfg_value(Json *j,char *v,size_t cap){
 jspace(j);if(*j->p=='"')jstring(j,v,cap);
 else {size_t n=0;while(*j->p&&*j->p!=','&&*j->p!='}'&&*j->p!=']'&&!isspace((unsigned char)*j->p)){
 if(n+1<cap)v[n++]=*j->p;
 j->p++;
 }v[n]=0;}
}
static void cfg_section(Json *j,const char *section){
 jspace(j);if(*j->p!='{'){j->error=1;return;}j->p++;
 char key[128],val[1024];
 while(jkey(j,key,sizeof key)&&!j->error){
  if(*j->p=='{'||*j->p=='['){jskip(j,0);continue;}
  cfg_value(j,val,sizeof val);
  if(!strcmp(section,"logo")){
   if(!strcmp(key,"enabled"))cfg_logo=strcmp(val,"false")!=0;
   else if(!strcmp(key,"autoScale"))cfg_auto=strcmp(val,"false")!=0;
   else if(!strcmp(key,"width"))cfg_logo_width=atoi(val);
   else if(!strcmp(key,"type"))snprintf(cfg_logo_type,sizeof cfg_logo_type,"%.63s",val);
   else if(!strcmp(key,"image"))snprintf(cfg_image_path,sizeof cfg_image_path,"%s",val);
  }else if(!strcmp(section,"display")){
   if(!strcmp(key,"palette"))cfg_palette=strcmp(val,"false")!=0;
   else if(!strcmp(key,"gap"))cfg_gap=atoi(val);
   else if(!strcmp(key,"keyColor"))cfg_color(val,cfg_key);
   else if(!strcmp(key,"valueColor"))cfg_color(val,cfg_val);
  }
 }
}
static int cfg_parse(const char *source){
 Json j={source,0};jspace(&j);if(*j.p!='{')return 0;j.p++;
 char key[128];
 while(jkey(&j,key,sizeof key)&&!j.error){
  jspace(&j);
  if(!strcmp(key,"logo")||!strcmp(key,"display"))cfg_section(&j,key);
  else if(!strcmp(key,"modules")){
   if(*j.p!='['){j.error=1;break;}j.p++;
   cfg_order[0]=0;
   while(!j.error){
    jspace(&j);if(*j.p==']'){j.p++;break;}
    if(*j.p==','){j.p++;continue;}
    char name[128];if(!jstring(&j,name,sizeof name))break;
    size_t len=strlen(cfg_order),n=strlen(name);
    if(len+n+2>=sizeof cfg_order){j.error=1;break;}
    if(len)strcat(cfg_order,":");
    strcat(cfg_order,name);
   }
  }else jskip(&j,0);
 }
 jspace(&j);return !j.error&&!*j.p;
}
static int cfg_load(const char *path,int required){
 FILE *f=fopen(path,"rb");if(!f){if(required)fprintf(stderr,"Cannot open config: %s\n",path);return !required;}
 if(fseek(f,0,SEEK_END)){fclose(f);return 0;}
 long n=ftell(f);rewind(f);
 if(n<0||n>262144){fprintf(stderr,"Config too large: %s\n",path);fclose(f);return 0;}
 char *buf=malloc((size_t)n+1);if(!buf){fclose(f);return 0;}
 size_t got=fread(buf,1,(size_t)n,f);fclose(f);buf[got]=0;
 int ok=got==(size_t)n&&cfg_parse(buf);free(buf);
 if(!ok)fprintf(stderr,"Invalid JSONC config: %s\n",path);
 return ok;
}
static char info[MAX_ROWS][512];
static int ninfo=0;
static char info_id[MAX_ROWS][64];
#define LABEL_WIDTH 16

static const char *selected_modules=NULL;
static int is_termux(void);
/* The default Termux preset hides desktop-only fields. Explicit --modules,
   --all and config module selections always retain full control. */
static int android_default_hidden(const char *name){
 static const char *const hidden[]={
  "display","desktop","wm","wmtheme","theme","plasmatheme",
  "icons","font","cursor","gpu"
 };
 if(!is_termux())return 0;
 for(size_t i=0;i<sizeof hidden/sizeof hidden[0];i++)
  if(!strcmp(name,hidden[i]))return 1;
 return 0;
}
static int module_enabled(const char *name){
 if(!selected_modules)return !android_default_hidden(name);
 const char *p=selected_modules;size_t n=strlen(name);
 while(*p){while(*p==':'||*p==' '||*p=='\n')p++;
  if(!strncmp(p,name,n)&&(p[n]==':'||p[n]==0||p[n]==' '||p[n]=='\n'))return 1;
  while(*p&&*p!=':'&&*p!='\n')p++;
 }
 return 0;
}
static const char *all_modules="title:separator:os:host:kernel:uptime:packages:display:desktop:wm:wmtheme:theme:plasmatheme:icons:font:cursor:session:terminal:cpu:gpu:memory:swap:disk:homedisk:localip:locale:board:bios:chassis:shell:processes:loadavg:load1:load5:load15:datetime:timezone:hostname:architecture:cpucores:cpufreq:battery:brightness:bluetooth:network:diskusage:diskfilesystem:termux:androidversion:androidsdk:androidmanufacturer:androidmodel:androidsoc:bootid:virtualization:editor:users:language:distro:osversion:kernelversion:kernelarch:machineid:cpuvendor:cpumodel:cpubogomips:cpuload:memtotal:memavailable:swaptotal:swapfree:diskfree:disktotal:diskpercent:rootfs:mounts:interfaces:ipv4:ipv6:gateway:dns:username:uid:gid:home:path:shellversion:terminaltype:displayserver:sessiondesktop:xdgconfig:xdgcache:xdgdata:pid:parentpid:threads:systemd:init:cgroup:entropy:thermalzones:fans:batterycount:powerstate:androiddevice:androidboard:androidfingerprint:androidsecuritypatch:termuxprefix:termuxhome:timezoneoffset:epoch:week:dayofyear:bootdate:procversion:filesystems:environment:cpuonline:cpuconfigured:procsrunning:procstotal:memused:mempercent:diskavailable:uptimeseconds:bootepoch:loadtasks:kernelhostname:systemhz:gpuusage:gpuvram:gpumemoryused:cpugovernor:cpufreqmin:cpufreqmax:memcached:batteryhealth:androidbrand:androidhardware:gpudriver:gpuvendor:cpul3:memorypressure:batterycycles:biosdate";
static const char *module_names[]={"title","separator","os","host","kernel","uptime","packages","display","desktop","wm","wmtheme","theme","plasmatheme","icons","font","cursor","session","terminal","cpu","gpu","memory","swap","disk","homedisk","localip","locale","board","bios","chassis","shell","processes","loadavg","load1","load5","load15","datetime","timezone","hostname","architecture","cpucores","cpufreq","battery","brightness","bluetooth","network","diskusage","diskfilesystem","termux","androidversion","androidsdk","androidmanufacturer","androidmodel","androidsoc","bootid","virtualization","editor","users","language","distro","osversion","kernelversion","kernelarch","machineid","cpuvendor","cpumodel","cpubogomips","cpuload","memtotal","memavailable","swaptotal","swapfree","diskfree","disktotal","diskpercent","rootfs","mounts","interfaces","ipv4","ipv6","gateway","dns","username","uid","gid","home","path","shellversion","terminaltype","displayserver","sessiondesktop","xdgconfig","xdgcache","xdgdata","pid","parentpid","threads","systemd","init","cgroup","entropy","thermalzones","fans","batterycount","powerstate","androiddevice","androidboard","androidfingerprint","androidsecuritypatch","termuxprefix","termuxhome","timezoneoffset","epoch","week","dayofyear","bootdate","procversion","filesystems","environment","cpuonline","cpuconfigured","procsrunning","procstotal","memused","mempercent","diskavailable","uptimeseconds","bootepoch","loadtasks","kernelhostname","systemhz","gpuusage","gpuvram","gpumemoryused","cpugovernor","cpufreqmin","cpufreqmax","memcached","batteryhealth","androidbrand","androidhardware","gpudriver","gpuvendor","cpul3","memorypressure","batterycycles","biosdate"};
static int valid_modules(const char *list){
 char buf[8192];snprintf(buf,sizeof buf,"%s",list);
 for(char *p=strtok(buf,": \t\r\n");p;p=strtok(NULL,": \t\r\n")){
  int found=0;
  for(size_t i=0;i<sizeof module_names/sizeof module_names[0];i++)if(!strcmp(p,module_names[i])){found=1;break;}
  if(!found){fprintf(stderr,"Unknown module: %s\n",p);return 0;}
 }
 return 1;
}
static void add(const char *label,const char *value) {
 if(ninfo>=MAX_ROWS)return;
 if(output_color)
  snprintf(info[ninfo],sizeof info[0],"\033[1;38;2;%d;%d;%dm%-*s" R "\033[38;2;%d;%d;%dm%s" R,
   cfg_key[0],cfg_key[1],cfg_key[2],LABEL_WIDTH,label,cfg_val[0],cfg_val[1],cfg_val[2],value&&*value?value:"Unknown");
 else snprintf(info[ninfo],sizeof info[0],"%-*s%s",LABEL_WIDTH,label,value&&*value?value:"Unknown");
 ninfo++;
}
static void add_module(const char *name,const char *label,const char *value){
 if(!module_enabled(name))return;
 /* Desktop defaults are adaptive; don't list KDE-only settings as N/A on
    GNOME, Sway, TTY, or unsupported hosts. Explicit requests remain visible. */
 if(!selected_modules && (!value||!*value||!strncmp(value,"Unavailable",11)) &&
    (!strcmp(name,"wmtheme")||!strcmp(name,"theme")||
     !strcmp(name,"plasmatheme")||!strcmp(name,"icons")||
     !strcmp(name,"font")||!strcmp(name,"cursor")||
     !strcmp(name,"wm")||!strcmp(name,"gpu")))return;
 int prev=ninfo;add(label,value);
 if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);
}
static void trim(char *s){size_t n=strlen(s);while(n&&(s[n-1]=='\n'||s[n-1]=='\r'||isspace((unsigned char)s[n-1])))s[--n]=0;}
static int is_termux(void){
 static int cached=-1;
 if(cached>=0)return cached;
 const char *p=getenv("PREFIX");
 const char *version=getenv("TERMUX_VERSION"),*app=getenv("TERMUX_APP__PACKAGE_NAME");
 cached=(p&&strstr(p,"com.termux")) || (version&&*version) ||
        (app&&strstr(app,"termux")) || access("/data/data/com.termux/files/usr",F_OK)==0;
 return cached;
}
#ifndef __ANDROID__
typedef struct {char key[96],value[384];} AndroidProp;
/* Some Linux-cross-built executables run in Termux without Bionic's property
   API. One getprop snapshot avoids spawning a shell for every requested field. */
static AndroidProp android_props[256];
static size_t android_prop_count=0;
static void load_android_properties(void){
 static int loaded=0;if(loaded)return;loaded=1;
 FILE *f=popen("getprop 2>/dev/null","r");if(!f)return;
 char line[768];
 while(android_prop_count<sizeof android_props/sizeof android_props[0] && fgets(line,sizeof line,f)){
  char *start=strchr(line,'[');if(!start)continue;
  char *mid=strstr(start, "]: [");if(!mid)continue;
  char *end=strchr(mid+4,']');if(!end)continue;
  size_t keylen=(size_t)(mid-(start+1)),valuelen=(size_t)(end-(mid+4));
  if(keylen<3||strncmp(start+1,"ro.",3))continue;
  if(!keylen||keylen>=sizeof android_props[0].key||valuelen>=sizeof android_props[0].value)continue;
  AndroidProp *item=&android_props[android_prop_count++];
  memcpy(item->key,start+1,keylen);item->key[keylen]=0;
  memcpy(item->value,mid+4,valuelen);item->value[valuelen]=0;
 }
 pclose(f);
}
#endif
static void property(const char *key,char *out,size_t cap){
 out[0]=0;
 if(!is_termux())return;
#ifdef __ANDROID__
 /* Termux builds can query bionic properties in-process instead of spawning
    getprop once per Android module. */
 char value[PROP_VALUE_MAX];
 if(__system_property_get(key,value)>0){snprintf(out,cap,"%s",value);return;}
 /* A missing property is expected on many devices; no subprocess needed. */
#else
 load_android_properties();
 for(size_t i=0;i<android_prop_count;i++)if(!strcmp(key,android_props[i].key)){
  snprintf(out,cap,"%s",android_props[i].value);break;
 }
#endif
}
static void motherboard(char *out,size_t cap){
 if(is_termux()){
  char model[256]="",brand[128]="";
  property("ro.product.model",model,sizeof model);
  property("ro.product.manufacturer",brand,sizeof brand);
  if(*model){snprintf(out,cap,"%s%s%s",brand,(*brand&&!strstr(model,brand))?" ":"",model);return;}
  snprintf(out,cap,"Android device");return;
 }
 char board[256]="",vendor[256]="",product[256]="";
 FILE *f=fopen("/sys/class/dmi/id/board_name","r");
 if(f){if(fgets(board,sizeof board,f))trim(board);fclose(f);}
 f=fopen("/sys/class/dmi/id/board_vendor","r");
 if(f){if(fgets(vendor,sizeof vendor,f))trim(vendor);fclose(f);}
 if(!*board||!strcmp(board,"Default string")||!strcmp(board,"To be filled by O.E.M.")||!strcmp(board,"Not Specified")){
  f=fopen("/sys/class/dmi/id/product_name","r");
  if(f){if(fgets(product,sizeof product,f))trim(product);fclose(f);}
  if(*product)snprintf(board,sizeof board,"%s",product);
 }
 if(!*board){snprintf(out,cap,"Unknown motherboard");return;}
 if(*vendor && !strstr(board,vendor))snprintf(out,cap,"%s %s",vendor,board);
 else snprintf(out,cap,"%s",board);
}
static void osname(char *out,size_t cap){
 if(is_termux()){
  char ver[80]="";property("ro.build.version.release",ver,sizeof ver);
  snprintf(out,cap,"Android%s%s (Termux)",*ver?" ":"",ver);return;
 }
 snprintf(out,cap,"Linux"); FILE *f=fopen("/etc/os-release","r");if(!f)return;
 char *line=NULL;size_t sz=0;
 while(getline(&line,&sz,f)>0){if(strncmp(line,"PRETTY_NAME=",12)==0){char *v=line+12;trim(v);if(*v=='\"'){v++;char *end=strrchr(v,'\"');if(end)*end=0;}snprintf(out,cap,"%s",v);break;}}
 free(line);fclose(f);
}
static void cpuinfo(char *out,size_t cap){
 if(is_termux()){
  property("ro.soc.model",out,cap);
  if(!*out)property("ro.board.platform",out,cap);
  if(*out)return;
 }
 snprintf(out,cap,"Unknown");FILE *f=fopen("/proc/cpuinfo","r");if(!f)return;
 char line[512];while(fgets(line,sizeof line,f)){if(!strncmp(line,"model name",10)||!strncmp(line,"Hardware",8)){
 char *v=strchr(line,':');if(v){v++;while(isspace((unsigned char)*v))v++;trim(v);snprintf(out,cap,"%s",v);break;}}}fclose(f);
}

static unsigned long long read_khz(const char *path){
 FILE *f=fopen(path,"r");unsigned long long v=0;
 if(f){if(fscanf(f,"%llu",&v)!=1)v=0;fclose(f);}return v;
}
static void cpu_max_frequency(char *cpu,size_t cap){
 unsigned long long best=0;
 DIR *d=opendir("/sys/devices/system/cpu/cpufreq");
 if(d){struct dirent *e;
  while((e=readdir(d))){
   if(strncmp(e->d_name,"policy",6))continue;
   char path[512];
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/cpuinfo_max_freq",e->d_name);
   unsigned long long v=read_khz(path);
   if(!v){snprintf(path,sizeof path,"/sys/devices/system/cpu/cpufreq/%s/scaling_max_freq",e->d_name);v=read_khz(path);}
   if(v>best)best=v;
  }
  closedir(d);
 }
 if(!best)best=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
 if(!best)return;
 size_t n=strlen(cpu);
 if(n+24<cap)snprintf(cpu+n,cap-n," @ %.2f GHz",best/1000000.0);
}
static void terminal_name(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Termux");return;}
 /* TERM describes capabilities, not the terminal emulator. */
 const char *v=getenv("KITTY_WINDOW_ID");
 if(v&&*v){snprintf(out,cap,"kitty");return;}
 v=getenv("KONSOLE_VERSION");if(v&&*v){snprintf(out,cap,"Konsole");return;}
 v=getenv("WEZTERM_PANE");if(v&&*v){snprintf(out,cap,"WezTerm");return;}
 v=getenv("ALACRITTY_WINDOW_ID");if(v&&*v){snprintf(out,cap,"Alacritty");return;}
 v=getenv("GHOSTTY_RESOURCES_DIR");if(v&&*v){snprintf(out,cap,"Ghostty");return;}
 v=getenv("WT_SESSION");if(v&&*v){snprintf(out,cap,"Windows Terminal");return;}
 v=getenv("TERM_PROGRAM");
 if(v&&*v && strcmp(v,"vscode")!=0){snprintf(out,cap,"%s",v);return;}
 if(v&&strcmp(v,"vscode")==0){snprintf(out,cap,"VS Code");return;}
 /* Walk process ancestry: shell -> terminal (also works when env is absent). */
 pid_t pid=getppid();
 for(int i=0;i<12 && pid>1;i++){
  char path[96],comm[128]="",statline[2048];
  snprintf(path,sizeof path,"/proc/%ld/comm",(long)pid);
  FILE *f=fopen(path,"r");
  if(f){if(fgets(comm,sizeof comm,f))trim(comm);fclose(f);}
  const char *name=NULL;
  if(strstr(comm,"konsole"))name="Konsole";
  else if(strstr(comm,"kitty"))name="kitty";
  else if(strstr(comm,"alacritty"))name="Alacritty";
  else if(strstr(comm,"wezterm"))name="WezTerm";
  else if(strstr(comm,"gnome-terminal"))name="GNOME Terminal";
  else if(strstr(comm,"ghostty"))name="Ghostty";
  else if(strstr(comm,"xfce4-terminal"))name="Xfce Terminal";
  else if(strstr(comm,"foot"))name="foot";
  else if(strstr(comm,"tilix"))name="Tilix";
  else if(strstr(comm,"terminator"))name="Terminator";
  else if(strstr(comm,"xterm"))name="xterm";
  if(name){snprintf(out,cap,"%s",name);return;}
  snprintf(path,sizeof path,"/proc/%ld/stat",(long)pid);
  f=fopen(path,"r");if(!f)break;
  if(!fgets(statline,sizeof statline,f)){fclose(f);break;}fclose(f);
  char *p=strrchr(statline,')');if(!p)break;
  char state;long ppid=0;
  if(sscanf(p+1," %c %ld",&state,&ppid)!=2)break;
  if(ppid<=1||ppid==pid)break;
  pid=(pid_t)ppid;
 }
 const char *term=getenv("TERM");snprintf(out,cap,"%s",term&&*term?term:"Unknown");
}
static void meminfo(char *out,size_t cap){
 FILE *f=fopen("/proc/meminfo","r");unsigned long long total=0,avail=0;
 if(f){char key[80],unit[20];unsigned long long v;
 while(fscanf(f,"%79s %llu %19s",key,&v,unit)==3){if(!strcmp(key,"MemTotal:"))total=v;if(!strcmp(key,"MemAvailable:"))avail=v;}
 fclose(f);}
 if(total){
  double pct=100.0*(total-avail)/total;
  const char *color=pct<50.0?"\033[1;32m":pct<=75.0?"\033[1;33m":"\033[1;31m";
  snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%\033[0m)",
           (total-avail)/1048576.,total/1048576.,color,pct);
  return;
 }

 snprintf(out,cap,"Unavailable");
}
static int cache_read(const char *key,char *out,size_t cap,long ttl){
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[512],file[640];struct stat st;
 if(base&&*base)snprintf(dir,sizeof dir,"%s/nisfetch",base);
 else if(home&&*home)snprintf(dir,sizeof dir,"%s/.cache/nisfetch",home);
 else return 0;
 if(snprintf(file,sizeof file,"%s/%s",dir,key)>=(int)sizeof file)return 0;
 time_t now=time(NULL);
 if(stat(file,&st)||!S_ISREG(st.st_mode)||st.st_size<=0||
    (size_t)st.st_size>=cap||st.st_mtime>now||now-st.st_mtime>ttl)return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 int ok=fgets(out,(int)cap,f)!=NULL;fclose(f);
 if(ok)trim(out);
 return ok&&*out;
}
static void cache_write(const char *key,const char *value){
 if(!value||!*value)return;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char dir[1024],file[1200],tmp[1240],parent[512];
 if(base&&*base)snprintf(parent,sizeof parent,"%s",base);
 else if(home&&*home)snprintf(parent,sizeof parent,"%s/.cache",home);
 else return;
 if(mkdir(parent,0700)&&errno!=EEXIST)return;
 if(snprintf(dir,sizeof dir,"%s/nisfetch",parent)>=(int)sizeof dir)return;
 if(mkdir(dir,0700)&&errno!=EEXIST)return;
 if(snprintf(file,sizeof file,"%s/%s",dir,key)>=(int)sizeof file)return;
 if(snprintf(tmp,sizeof tmp,"%s/.%s.XXXXXX",dir,key)>=(int)sizeof tmp)return;
 int fd=mkstemp(tmp);if(fd<0)return;
 size_t len=strlen(value);int ok=1;
 if(write(fd,value,len)!=(ssize_t)len||write(fd,"\n",1)!=1)ok=0;
 if(close(fd))ok=0;
 if(ok&&rename(tmp,file)==0)return; /* atomic, even across parallel shells */
 unlink(tmp);
}
static unsigned long count_lines(const char *cmd){
 FILE *f=popen(cmd,"r");unsigned long n=0;
 if(f){if(fscanf(f,"%lu",&n)!=1)n=0;pclose(f);}return n;
}
/* Count installed packages from their database directories without starting
   the package manager. Foreign classification uses optional runtime libalpm. */
static unsigned long count_subdirs(const char *path){
 DIR *d=opendir(path);if(!d)return 0;
 unsigned long n=0;struct dirent *e;
 while((e=readdir(d))!=NULL){
  if(e->d_name[0]=='.')continue;
#ifdef DT_DIR
  /* pacman's local DB has thousands of entries: d_type avoids one stat(2)
     per package on ext4/btrfs. Unknown d_type still gets a safe stat. */
  if(e->d_type==DT_DIR){n++;continue;}
  if(e->d_type!=DT_UNKNOWN)continue;
#endif
  {
   char file[PATH_MAX];struct stat st;
   if(snprintf(file,sizeof file,"%s/%s",path,e->d_name)<(int)sizeof file &&
      stat(file,&st)==0 && S_ISDIR(st.st_mode))n++;
  }
 }
 closedir(d);return n;
}
/* dpkg and Alpine apk both expose compact on-disk package status files.
   Reading them directly skips a shell, grep, wc and a package-manager spawn. */
static unsigned long dpkg_installed_count(const char *path){
 FILE *f=fopen(path,"r");if(!f)return 0;
 unsigned long n=0;char line[1024];
 while(fgets(line,sizeof line,f))
  if(!strncmp(line,"Status: install ok installed",28) &&
     (line[28]=='\n'||line[28]=='\r'||line[28]==0))n++;
 fclose(f);return n;
}
static unsigned long apk_installed_count(const char *path){
 FILE *f=fopen(path,"r");if(!f)return 0;
 unsigned long n=0;char line[1024];
 while(fgets(line,sizeof line,f))if(line[0]=='P'&&line[1]==':'&&line[2]!='\n')n++;
 fclose(f);return n;
}
static unsigned long portage_installed_count(void){
 DIR *d=opendir("/var/db/pkg");if(!d)return 0;
 unsigned long total=0;struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"/var/db/pkg/%s",e->d_name)>=(int)sizeof path)continue;
#ifdef DT_DIR
  if(e->d_type!=DT_DIR && e->d_type!=DT_UNKNOWN)continue;
#endif
  total+=count_subdirs(path);
 }
 closedir(d);return total;
}
/* Spawn a single package manager with no shell, grep, awk, or wc. */
static unsigned long count_process_lines(const char *program,const char *arg1,const char *arg2){
 int fds[2];if(pipe(fds)!=0)return 0;
 pid_t pid=fork();
 if(pid<0){close(fds[0]);close(fds[1]);return 0;}
 if(pid==0){
  close(fds[0]);if(dup2(fds[1],STDOUT_FILENO)<0)_exit(127);close(fds[1]);
  int null=open("/dev/null",O_WRONLY);
  if(null>=0){dup2(null,STDERR_FILENO);close(null);}
  execlp(program,program,arg1,arg2,(char*)NULL);_exit(127);
 }
 close(fds[1]);unsigned long n=0;char buf[4096];ssize_t got;
 for(;;){
  got=read(fds[0],buf,sizeof buf);
  if(got<0&&errno==EINTR)continue;
  if(got<=0)break;
  for(ssize_t i=0;i<got;i++)if(buf[i]=='\n')n++;
 }
 close(fds[0]);int status=0;pid_t waited;
 do{waited=waitpid(pid,&status,0);}while(waited<0&&errno==EINTR);
 return waited==pid&&WIFEXITED(status)&&WEXITSTATUS(status)==0?n:0;
}
/* Foreign means "installed package name absent from all enabled sync repos".
   Read the pacman configuration, then use libalpm in-process when available.
   No pacman headers are required; dlopen keeps other distros/Termux portable.
   Unsupported/custom configurations fall back to pacman -Qmq for accuracy. */
typedef struct {
 char root[PATH_MAX],dbpath[PATH_MAX],config_path[PATH_MAX],repos[48][128];
 size_t nrepos;
} PacmanConfig;
static int pacman_config_from(const char *config_path,PacmanConfig *cfg){
 memset(cfg,0,sizeof *cfg);
 snprintf(cfg->root,sizeof cfg->root,"/");
 snprintf(cfg->dbpath,sizeof cfg->dbpath,"/var/lib/pacman");
 if(snprintf(cfg->config_path,sizeof cfg->config_path,"%s",config_path)>=(int)sizeof cfg->config_path)return 0;
 FILE *f=fopen(config_path,"r");if(!f)return 0;
 char line[2048],section[128]="";int ok=1,custom_db=0;
 while(fgets(line,sizeof line,f)){
  char *p=line;while(isspace((unsigned char)*p))p++;
  if(!*p||*p=='#')continue;
  if(*p=='['){
   char *end=strchr(p+1,']');
   if(!end||end-p>=128){ok=0;break;}
   *end=0;snprintf(section,sizeof section,"%s",p+1);
   if(!strcasecmp(section,"options"))continue;
   for(const char *q=section;*q;q++)
    if(!isalnum((unsigned char)*q)&&*q!='-'&&*q!='_'&&*q!='.'&&*q!='+')ok=0;
   if(!ok||cfg->nrepos>=48){ok=0;break;}
   snprintf(cfg->repos[cfg->nrepos++],128,"%s",section);
   continue;
  }
  char *eq=strchr(p,'=');if(!eq)continue;
  *eq++=0;trim(p);
  while(isspace((unsigned char)*eq))eq++;
  char *comment=strchr(eq,'#');if(comment)*comment=0;
  trim(eq);
  if(strcasecmp(section,"options"))continue;
  if(!strcasecmp(p,"Include")){ok=0;break;} /* may contain more repos */
  if(!strcasecmp(p,"RootDir")){
   if(*eq!='/'){ok=0;break;}
   if(snprintf(cfg->root,sizeof cfg->root,"%s",eq)>=(int)sizeof cfg->root){ok=0;break;}
  }else if(!strcasecmp(p,"DBPath")){
   if(*eq!='/'){ok=0;break;}
   if(snprintf(cfg->dbpath,sizeof cfg->dbpath,"%s",eq)>=(int)sizeof cfg->dbpath){ok=0;break;}
   custom_db=1;
  }
 }
 fclose(f);
 if(!ok||!cfg->nrepos)return 0;
 if(!custom_db&&strcmp(cfg->root,"/")){
  if(snprintf(cfg->dbpath,sizeof cfg->dbpath,"%s/var/lib/pacman",cfg->root)>=(int)sizeof cfg->dbpath)return 0;
 }
 return 1;
}
static int pacman_config(PacmanConfig *cfg){
 return pacman_config_from("/etc/pacman.conf",cfg);
}
static int pacman_db_files_ready(const PacmanConfig *cfg,time_t newer_than){
 for(size_t i=0;i<cfg->nrepos;i++){
  char path[PATH_MAX];struct stat st;
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[i])>=(int)sizeof path ||
     stat(path,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<=0||st.st_mtime>newer_than)return 0;
 }
 return 1;
}
static void *pacman_load_alpm(void){
 static const char *names[]={"libalpm.so","libalpm.so.17","libalpm.so.16",
                            "libalpm.so.15","libalpm.so.14","libalpm.so.13",NULL};
 for(size_t i=0;names[i];i++){
  void *lib=dlopen(names[i],RTLD_NOW|RTLD_LOCAL);
  if(lib)return lib;
 }
 return NULL;
}
/* All signatures here are the public libalpm ABI; no struct layout assumed.
   The installed names come from pacman's name-version-release directory
   convention, avoiding a second scan of every local package desc file. */
static int pacman_foreign_libalpm(const PacmanConfig *cfg,unsigned long *result){
 void *lib=pacman_load_alpm();if(!lib)return 0;
 void *(*init)(const char*,const char*,int*)=dlsym(lib,"alpm_initialize");
 int (*release)(void*)=dlsym(lib,"alpm_release");
 void *(*register_db)(void*,const char*,int)=dlsym(lib,"alpm_register_syncdb");
 void *(*get_pkg)(void*,const char*)=dlsym(lib,"alpm_db_get_pkg");
 int (*db_valid)(void*)=dlsym(lib,"alpm_db_get_valid");
 if(!init||!release||!register_db||!get_pkg||!db_valid){dlclose(lib);return 0;}
 int err=0,ok=1;
 void *handle=init(cfg->root,cfg->dbpath,&err);
 if(!handle){dlclose(lib);return 0;}
 void *dbs[48];
 for(size_t i=0;i<cfg->nrepos;i++){
  dbs[i]=register_db(handle,cfg->repos[i],0);
  if(!dbs[i]||db_valid(dbs[i])!=0){ok=0;break;}
 }
 unsigned long foreign=0;
 if(ok){
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"%s/local",cfg->dbpath)>=(int)sizeof path)ok=0;
  DIR *dir=ok?opendir(path):NULL;
  if(!dir)ok=0;
  if(dir){
   struct dirent *e;
   while((e=readdir(dir))!=NULL){
    if(e->d_name[0]=='.')continue;
#ifdef DT_DIR
    if(e->d_type!=DT_DIR){
     if(e->d_type!=DT_UNKNOWN)continue;
     struct stat st;
     if(fstatat(dirfd(dir),e->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
    }
#else
    struct stat st;
    if(fstatat(dirfd(dir),e->d_name,&st,AT_SYMLINK_NOFOLLOW)!=0||!S_ISDIR(st.st_mode))continue;
#endif
    char name[NAME_MAX+1];snprintf(name,sizeof name,"%s",e->d_name);
    char *release_part=strrchr(name,'-');
    if(!release_part){ok=0;break;}
    *release_part=0;
    char *version_part=strrchr(name,'-');
    if(!version_part){ok=0;break;}
    *version_part=0;
    if(!*name){ok=0;break;}
    size_t i=0;
    for(;i<cfg->nrepos;i++)if(get_pkg(dbs[i],name))break;
    if(i==cfg->nrepos)foreign++;
   }
   closedir(dir);
  }
 }
 release(handle);dlclose(lib);
 if(ok)*result=foreign;
 return ok;
}
static unsigned long pacman_foreign_direct(void){
 return count_process_lines("pacman","-Qmq",NULL);
}
/* The authoritative foreign-package query must read every enabled sync DB.
   Keep its exact result in XDG_STATE_HOME and validate it against both the
   local DB and every configured sync DB. Clearing disposable XDG_CACHE_HOME
   then does not force a full repository parse. This is a persistent index,
   not a claim that a genuinely unindexed first launch is free. */
static uint64_t pacman_hash_byte(uint64_t h,unsigned char b){
 return (h^(uint64_t)b)*UINT64_C(1099511628211);
}
static uint64_t pacman_hash_u64(uint64_t h,uint64_t v){
 for(int i=0;i<8;i++){h=pacman_hash_byte(h,(unsigned char)v);v>>=8;}
 return h;
}
static uint64_t pacman_hash_str(uint64_t h,const char *s){
 for(;*s;s++)h=pacman_hash_byte(h,(unsigned char)*s);
 return pacman_hash_byte(h,0);
}
static uint64_t pacman_hash_stat(uint64_t h,const struct stat *st){
 h=pacman_hash_u64(h,(uint64_t)st->st_dev);
 h=pacman_hash_u64(h,(uint64_t)st->st_ino);
 h=pacman_hash_u64(h,(uint64_t)st->st_size);
 h=pacman_hash_u64(h,(uint64_t)st->st_mtim.tv_sec);
 h=pacman_hash_u64(h,(uint64_t)st->st_mtim.tv_nsec);
 h=pacman_hash_u64(h,(uint64_t)st->st_ctim.tv_sec);
 return pacman_hash_u64(h,(uint64_t)st->st_ctim.tv_nsec);
}
static int pacman_db_fingerprint(const PacmanConfig *cfg,uint64_t *fingerprint){
 uint64_t h=UINT64_C(14695981039346656037);
 h=pacman_hash_str(h,cfg->root);
 h=pacman_hash_str(h,cfg->dbpath);
 struct stat st;char path[PATH_MAX+16];
 if(stat(cfg->config_path,&st)!=0||!S_ISREG(st.st_mode))return 0;
 h=pacman_hash_stat(pacman_hash_str(h,cfg->config_path),&st);
 if(snprintf(path,sizeof path,"%s/local",cfg->dbpath)>=(int)sizeof path ||
    stat(path,&st)!=0||!S_ISDIR(st.st_mode))return 0;
 h=pacman_hash_stat(h,&st);
 for(size_t i=0;i<cfg->nrepos;i++){
  if(snprintf(path,sizeof path,"%s/sync/%s.db",cfg->dbpath,cfg->repos[i])>=(int)sizeof path ||
     stat(path,&st)!=0||!S_ISREG(st.st_mode)||st.st_size<=0)return 0;
  h=pacman_hash_stat(pacman_hash_str(h,cfg->repos[i]),&st);
 }
 *fingerprint=h;
 return 1;
}
static int pacman_state_file(char *file,size_t cap,int create){
 const char *xdg=getenv("XDG_STATE_HOME"),*home=getenv("HOME");
 char base[PATH_MAX],dir[PATH_MAX],parent[PATH_MAX];
 int default_state=!xdg||!*xdg;
 if(!default_state){
  if(snprintf(base,sizeof base,"%s",xdg)>=(int)sizeof base)return 0;
 }else{
  if(!home||!*home)return 0;
  if(snprintf(parent,sizeof parent,"%s/.local",home)>=(int)sizeof parent)return 0;
  if(snprintf(base,sizeof base,"%s/state",parent)>=(int)sizeof base)return 0;
 }
 if(snprintf(dir,sizeof dir,"%s/nisfetch",base)>=(int)sizeof dir ||
    snprintf(file,cap,"%s/pacman-foreign.index",dir)>=(int)cap)return 0;
 if(create){
  if(default_state&&mkdir(parent,0700)&&errno!=EEXIST)return 0;
  if(mkdir(base,0700)&&errno!=EEXIST)return 0;
  if(mkdir(dir,0700)&&errno!=EEXIST)return 0;
 }
 return 1;
}
static int pacman_index_read(uint64_t fingerprint,unsigned long *count){
 char file[PATH_MAX];
 if(!pacman_state_file(file,sizeof file,0))return 0;
 FILE *f=fopen(file,"r");if(!f)return 0;
 char line[128];int read_ok=fgets(line,sizeof line,f)!=NULL;
 fclose(f);if(!read_ok)return 0;
 unsigned long long key=0;unsigned long found=0;char extra=0;
 if(sscanf(line,"NISFETCH-ALPM1 %llx %lu %c",&key,&found,&extra)!=2 ||
    (uint64_t)key!=fingerprint)return 0;
 *count=found;
 return 1;
}
static void pacman_index_write(uint64_t fingerprint,unsigned long count){
 char file[PATH_MAX],tmp[PATH_MAX+32],content[128];
 if(!pacman_state_file(file,sizeof file,1))return;
 /* The index path is stable; staging in the same directory makes rename atomic. */
 if(snprintf(tmp,sizeof tmp,"%s.XXXXXXXX",file)>=(int)sizeof tmp)return;
 int fd=mkstemp(tmp);if(fd<0)return;
 int len=snprintf(content,sizeof content,"NISFETCH-ALPM1 %016llx %lu\n",
                  (unsigned long long)fingerprint,count);
 int ok=len>0&&(size_t)len<sizeof content&&
        write(fd,content,(size_t)len)==len;
 if(close(fd)!=0)ok=0;
 if(ok&&rename(tmp,file)==0)return;
 unlink(tmp);
}
static unsigned long foreign_packages(const PacmanConfig *cfg){
 char buf[80];struct stat db,cache,pacman_conf;
 uint64_t fingerprint=0;unsigned long indexed=0;
 int indexed_db=pacman_db_fingerprint(cfg,&fingerprint);
 if(indexed_db&&pacman_index_read(fingerprint,&indexed))return indexed;
 const char *base=getenv("XDG_CACHE_HOME"),*home=getenv("HOME");
 char file[PATH_MAX];
 if(base&&*base)snprintf(file,sizeof file,"%s/nisfetch/foreign_count",base);
 else if(home&&*home)snprintf(file,sizeof file,"%s/.cache/nisfetch/foreign_count",home);
 else file[0]=0;
 char local[PATH_MAX];
 if(snprintf(local,sizeof local,"%s/local",cfg->dbpath)>=(int)sizeof local)return pacman_foreign_direct();
 /* Invalidate on either an installed-package or sync-repository DB change. */
 if(file[0] && stat(local,&db)==0 &&
    stat(file,&cache)==0 && cache.st_mtime>=db.st_mtime &&
    (stat(cfg->config_path,&pacman_conf)!=0||cache.st_mtime>=pacman_conf.st_mtime) &&
    pacman_db_files_ready(cfg,cache.st_mtime) &&
    time(NULL)-cache.st_mtime<3600 && cache_read("foreign_count",buf,sizeof buf,3600)){
  char *end;unsigned long n=strtoul(buf,&end,10);
  if(end!=buf && !*end){
   if(indexed_db)pacman_index_write(fingerprint,n);
   return n;
  }
 }
 unsigned long n=0;
 int alpm_ok=indexed_db&&pacman_foreign_libalpm(cfg,&n);
 if(!alpm_ok)
  n=pacman_foreign_direct();
 else pacman_index_write(fingerprint,n);
 snprintf(buf,sizeof buf,"%lu",n);cache_write("foreign_count",buf);
 return n;
}
static unsigned long flatpak_apps(void){
 unsigned long n=0;
 const char *home=getenv("HOME");char path[PATH_MAX];
 n+=count_subdirs("/var/lib/flatpak/app");
 if(home&&*home && snprintf(path,sizeof path,"%s/.local/share/flatpak/app",home)<(int)sizeof path)
  n+=count_subdirs(path);
 return n;
}
static void packages_uncached(char *out,size_t cap){
 out[0]=0;
 size_t used=0;
 if(is_termux()){
  char path[PATH_MAX];unsigned long n=0;
  const char *prefix=getenv("PREFIX");
  if(prefix&&*prefix&&snprintf(path,sizeof path,"%s/var/lib/dpkg/status",prefix)<(int)sizeof path)
   n=dpkg_installed_count(path);
  if(!n)n=dpkg_installed_count("/data/data/com.termux/files/usr/var/lib/dpkg/status");
  if(!n)n=count_lines("dpkg-query -W -f='${db:Status-Abbrev}\\n' 2>/dev/null | grep -c '^ii'");
  if(n){snprintf(out,cap,"%lu (dpkg/Termux)",n);return;}
 }
 PacmanConfig pacman_cfg;int has_pacman_cfg=pacman_config(&pacman_cfg);
 char pacman_local[PATH_MAX+16]="/var/lib/pacman/local";
 if(has_pacman_cfg)snprintf(pacman_local,sizeof pacman_local,"%s/local",pacman_cfg.dbpath);
 if(access(pacman_local,F_OK)==0){
  /* Native = pacman -Qn; foreign = pacman -Qm (usually AUR). */
  unsigned long total=count_subdirs(pacman_local);
  unsigned long foreign=has_pacman_cfg?foreign_packages(&pacman_cfg):pacman_foreign_direct();
  unsigned long native=total>=foreign?total-foreign:0;
  if(native)used+=(size_t)snprintf(out+used,cap-used,"%lu (pacman)",native);
  if(foreign && used<cap)used+=(size_t)snprintf(out+used,cap-used,"%s%lu (AUR/foreign)",used?", ":"",foreign);
 }else if(access("/var/lib/dpkg/status",R_OK)==0){
  unsigned long n=dpkg_installed_count("/var/lib/dpkg/status");
  if(n)used=(size_t)snprintf(out,cap,"%lu (dpkg)",n);
 }else if(access("/usr/lib/sysimage/rpm",F_OK)==0||access("/var/lib/rpm",F_OK)==0){
  unsigned long n=count_process_lines("rpm","-qa",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (rpm)",n);
 }else if(access("/lib/apk/db/installed",R_OK)==0||access("/var/lib/apk/db/installed",R_OK)==0){
  unsigned long n=apk_installed_count(access("/lib/apk/db/installed",R_OK)==0?
   "/lib/apk/db/installed":"/var/lib/apk/db/installed");
  if(n)used=(size_t)snprintf(out,cap,"%lu (apk)",n);
 }else if(access("/etc/gentoo-release",F_OK)==0){
  unsigned long n=portage_installed_count();
  if(n)used=(size_t)snprintf(out,cap,"%lu (portage)",n);
 }else if(access("/var/db/xbps",F_OK)==0){
  unsigned long n=count_process_lines("xbps-query","-l",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (xbps)",n);
 }else if(access("/var/db/pkg",F_OK)==0){
  unsigned long n=count_process_lines("pkg","info",NULL);
  if(n)used=(size_t)snprintf(out,cap,"%lu (pkg)",n);
 }
 /* Flatpak apps across user and system installations, if installed. */
 unsigned long flat=flatpak_apps();
 if(flat && used<cap)snprintf(out+used,cap-used,"%s%lu (flatpak)",used?", ":"",flat);
 if(!*out)snprintf(out,cap,"Unavailable");
}
static void packages(char *out,size_t cap){
 if(cache_read("packages",out,cap,15))return;
 packages_uncached(out,cap);
 if(*out && strcmp(out,"Unavailable"))cache_write("packages",out);
}
static const char *env_or(const char *name,const char *fallback){const char *v=getenv(name);return v&&*v?v:fallback;}


static void command_first(const char *cmd,char *out,size_t cap){
 out[0]=0;
 FILE *f=popen(cmd,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 pclose(f);
}
static void ini_value(const char *path,const char *section,const char *key,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 char line[512];int active=0;
 while(fgets(line,sizeof line,f)){
  trim(line);
  if(line[0]=='['){active=(strlen(line)==strlen(section)+2 && line[1+strlen(section)]==']' && !strncmp(line+1,section,strlen(section)));continue;}
  if(active && !strncmp(line,key,strlen(key)) && line[strlen(key)]=='='){
   snprintf(out,cap,"%s",line+strlen(key)+1);break;
  }
 }
 fclose(f);
}
static void config_file(char *out,size_t cap,const char *name){
 const char *base=getenv("XDG_CONFIG_HOME");
 if(base&&*base)snprintf(out,cap,"%s/%s",base,name);
 else snprintf(out,cap,"%s/.config/%s",env_or("HOME",""),name);
}
static void swapinfo(char *out,size_t cap){
 struct sysinfo s;if(sysinfo(&s)){snprintf(out,cap,"Unavailable");return;}
 unsigned long long total=(unsigned long long)s.totalswap*s.mem_unit;
 unsigned long long used=(unsigned long long)(s.totalswap-s.freeswap)*s.mem_unit;
 if(!total){snprintf(out,cap,"Disabled");return;}
 snprintf(out,cap,"%.2f GiB / %.2f GiB",used/1073741824.,total/1073741824.);
}
static void displayinfo(char *out,size_t cap){
 if(is_termux()){snprintf(out,cap,"Android display");return;}
 const char *session=getenv("XDG_SESSION_TYPE");
 if(session&&!strcasecmp(session,"wayland")){
  /* Xrandr commonly reports a virtual XWayland screen, not the actual monitor. */
  snprintf(out,cap,"Wayland");return;
 }
 const char *display=getenv("DISPLAY");
 if(!display||!*display){
  snprintf(out,cap,"%s",session&&*session?session:"TTY");return;
 }
 command_first("command -v xrandr >/dev/null && xrandr --current 2>/dev/null | awk '/\\*/ {print $1 \" @ \" $2; exit}'",out,cap);
 if(!*out)snprintf(out,cap,"%s",session&&*session?session:"TTY");
}
static void kde_read(const char *file,const char *group,const char *key,char *out,size_t cap){
 char path[512];config_file(path,sizeof path,file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 /* KDE configuration can be inherited from system defaults. */
 snprintf(path,sizeof path,"/etc/xdg/%s",file);
 ini_value(path,group,key,out,cap);
 if(*out)return;
 const char *xdg=getenv("XDG_CONFIG_DIRS");
 if(xdg&&*xdg){
  char *copy=strdup(xdg);if(!copy)return;
  char *save=NULL;
  for(char *dir=strtok_r(copy,":",&save);dir;dir=strtok_r(NULL,":",&save)){
   if(snprintf(path,sizeof path,"%s/%s",dir,file)>=(int)sizeof path)continue;
   ini_value(path,group,key,out,cap);if(*out)break;
  }
  free(copy);
 }
}
static void kde_command(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* KDE's own configuration reader understands merged configuration. */
 char cmd[512];
 if(snprintf(cmd,sizeof cmd,
    "if command -v kreadconfig6 >/dev/null 2>&1; then kreadconfig6 --file %s --group %s --key %s 2>/dev/null; "
    "elif command -v kreadconfig5 >/dev/null 2>&1; then kreadconfig5 --file %s --group %s --key %s 2>/dev/null; fi",
    file,group,key,file,group,key)>=(int)sizeof cmd)return;
 command_first(cmd,out,cap);
}
static void kde_setting(const char *file,const char *group,const char *key,char *out,size_t cap){
 /* First read KDE's native INI files. Cache only the expensive KDE fallback,
    including missing keys; never cache the native path. */
 out[0]=0;
 kde_read(file,group,key,out,cap);
 if(*out)return;
 char cache_key[192],cached[512];
 snprintf(cache_key,sizeof cache_key,"kde_%s_%s_%s",file,group,key);
 if(cache_read(cache_key,cached,sizeof cached,60)){
  if(strcmp(cached,"__NISFETCH_EMPTY__"))snprintf(out,cap,"%.*s",(int)cap-1,cached);
  return;
 }
 kde_command(file,group,key,out,cap);
 cache_write(cache_key,*out?out:"__NISFETCH_EMPTY__");
}
static int is_kde(void){
 const char *d=getenv("XDG_CURRENT_DESKTOP");
 return d&&(strstr(d,"KDE")||strstr(d,"Plasma"));
}
/* Resolve only selected KDE modules, rather than eagerly resolving all six
   settings (and fontconfig) for every single-module request. */
static void themeinfo(char *wmtheme,size_t wtcap,char *theme,size_t tcap,
                      char *icons,size_t icap,char *font,size_t fcap,
                      char *cursor,size_t ccap,char *plasma,size_t pcap){
 const int want_wm=module_enabled("wmtheme");
 const int want_theme=module_enabled("theme");
 const int want_icons=module_enabled("icons");
 const int want_font=module_enabled("font");
 const int want_cursor=module_enabled("cursor");
 const int want_plasma=module_enabled("plasmatheme");
 if(!is_kde()){
  (void)wtcap;(void)pcap;(void)want_wm;(void)want_plasma;
  /* Direct environment overrides work across desktops at negligible cost.
     A GTK theme must not be mislabeled as a window-decoration theme. */
  if(want_theme){const char *e=getenv("GTK_THEME");if(e&&*e)snprintf(theme,tcap,"%s",e);}
  if(want_icons){const char *e=getenv("GTK_ICON_THEME");if(e&&*e)snprintf(icons,icap,"%s",e);}
  if(want_font){const char *e=getenv("GTK_FONT_NAME");if(e&&*e)snprintf(font,fcap,"%s",e);}
  if(want_cursor){const char *e=getenv("XCURSOR_THEME");if(e&&*e)snprintf(cursor,ccap,"%s",e);}
  return;
 }
 if(want_wm){
  kde_setting("kwinrc","org.kde.kdecoration2","theme",wmtheme,wtcap);
  if(!*wmtheme)kde_setting("kwinrc","org.kde.kdecoration2","library",wmtheme,wtcap);
  if(!*wmtheme)snprintf(wmtheme,wtcap,"Breeze (assumed default)");
 }
 if(want_theme){
  kde_setting("kdeglobals","General","ColorScheme",theme,tcap);
  if(!*theme)snprintf(theme,tcap,"Breeze (assumed default)");
 }
 if(want_icons){
  kde_setting("kdeglobals","Icons","Theme",icons,icap);
  if(!*icons)snprintf(icons,icap,"breeze (assumed default)");
 }
 if(want_font){
  kde_setting("kdeglobals","General","font",font,fcap);
  if(!*font){
   if(!cache_read("fontconfig_family",font,fcap,300)){
    command_first("fc-match -f '%{family}\n' sans-serif 2>/dev/null",font,fcap);
    if(*font)cache_write("fontconfig_family",font);
   }
   if(!*font)snprintf(font,fcap,"Not configured");
   else {size_t n=strlen(font);if(n<fcap)snprintf(font+n,fcap-n," (fontconfig)");}
  }
  char *comma=strchr(font,',');if(comma)*comma=0;
 }
 if(want_cursor){
  kde_setting("kcminputrc","Mouse","cursorTheme",cursor,ccap);
  if(!*cursor)snprintf(cursor,ccap,"Breeze (assumed default)");
 }
 if(want_plasma){
  kde_setting("plasmarc","Theme","name",plasma,pcap);
  if(!*plasma)snprintf(plasma,pcap,"Breeze (assumed default)");
 }
}
static void kde_display(char *out,size_t cap){
 /* KScreen DBus startup is relatively costly; keep the exact result for 30s. */
 if(cache_read("display",out,cap,30))return;
 if(is_kde()){
  char line[512];
  command_first("if command -v kscreen-doctor >/dev/null 2>&1; then kscreen-doctor -o 2>/dev/null | grep -m1 -E '([0-9]{3,5}x[0-9]{3,5})|([0-9]{3,5}/[0-9]{3,5})'; fi",line,sizeof line);
  /* The full kscreen-doctor line is verbose; extract a resolution. */
  for(char *p=line;*p;p++){
   if(p[0]>='0'&&p[0]<='9'){
    unsigned w,h;
    if(sscanf(p,"%ux%u",&w,&h)==2&&w>=320&&h>=200&&w<20000&&h<20000){
     snprintf(out,cap,"%ux%u (%s)",w,h,env_or("XDG_SESSION_TYPE","unknown"));
     cache_write("display",out);return;
    }
   }
  }
 }
 displayinfo(out,cap);
 if(*out && strcmp(out,"Unavailable"))cache_write("display",out);
}
static void wm_info(char *out,size_t cap){
 const char *desktop=env_or("XDG_CURRENT_DESKTOP",env_or("XDG_SESSION_DESKTOP",""));
 const char *wm=NULL;
 if(getenv("HYPRLAND_INSTANCE_SIGNATURE"))wm="Hyprland";
 else if(getenv("SWAYSOCK"))wm="Sway";
 else if(getenv("NIRI_SOCKET"))wm="niri";
 else if(getenv("I3SOCK"))wm="i3";
 else if(strstr(desktop,"Hyprland"))wm="Hyprland";
 else if(strstr(desktop,"sway")||strstr(desktop,"Sway"))wm="Sway";
 else if(strstr(desktop,"COSMIC"))wm="cosmic-comp";
 else if(strstr(desktop,"labwc"))wm="labwc";
 else if(strstr(desktop,"river"))wm="river";
 else if(strstr(desktop,"Wayfire"))wm="Wayfire";
 else if(strstr(desktop,"KDE")||strstr(desktop,"Plasma"))wm="KWin";
 else if(strstr(desktop,"GNOME"))wm="Mutter";
 else if(strstr(desktop,"Cinnamon"))wm="Muffin";
 else if(strstr(desktop,"MATE"))wm="Marco";
 else if(strstr(desktop,"XFCE")||strstr(desktop,"Xfce"))wm="Xfwm4";
 if(wm)snprintf(out,cap,"%s (%s)",wm,env_or("XDG_SESSION_TYPE","unknown"));
 else out[0]=0;
}
static void disk_path(const char *path,char *out,size_t cap){
 struct statvfs v;if(statvfs(path,&v)){snprintf(out,cap,"Unavailable");return;}
 double t=(double)v.f_blocks*v.f_frsize,used=(double)(v.f_blocks-v.f_bfree)*v.f_frsize;
 double pct=t?100*used/t:0;
 const char *c=pct<50?"\033[1;32m":pct<=75?"\033[1;33m":"\033[1;31m";
 snprintf(out,cap,"%.2f GiB / %.2f GiB (%s%.0f%%" R ")",used/1073741824.,t/1073741824.,c,pct);
}
static void palette_row(int row){
 for(int i=0;i<8;i++)printf("\033[48;5;%dm   ",row*8+i);
 fputs(R,stdout);
}

static int read_temp(const char *path,double *celsius){
 FILE *f=fopen(path,"r");if(!f)return 0;
 long val=0;int ok=fscanf(f,"%ld",&val)==1;fclose(f);
 if(!ok||val< -30000||val>150000)return 0;
 *celsius=val/1000.0;return 1;
}
static int sensor_temp(const char *driver,double *value){
 DIR *d=opendir("/sys/class/hwmon");if(!d)return 0;
 struct dirent *e;int found=0;
 while((e=readdir(d))){
  if(strncmp(e->d_name,"hwmon",5))continue;
  char path[512],name[128];
  snprintf(path,sizeof path,"/sys/class/hwmon/%s/name",e->d_name);
  FILE *f=fopen(path,"r");if(!f)continue;
  if(!fgets(name,sizeof name,f)){fclose(f);continue;}fclose(f);trim(name);
  if(strcmp(name,driver))continue;
  for(int i=1;i<=4;i++){
   snprintf(path,sizeof path,"/sys/class/hwmon/%s/temp%d_input",e->d_name,i);
   if(read_temp(path,value)){found=1;break;}
  }
  if(found)break;
 }
 closedir(d);return found;
}
static void temp_suffix(char *out,size_t cap,const char *driver1,const char *driver2){
 double temp;
 if(sensor_temp(driver1,&temp)||sensor_temp(driver2,&temp)){
  const char *color=temp<50?"\033[1;32m":temp<=75?"\033[1;33m":"\033[1;31m";
  size_t n=strlen(out);
  if(n<cap)snprintf(out+n,cap-n," (%s%.0f°C\033[0m)",color,temp);
 }
}
/* Linux DRM sysfs fast path. Only name IDs we can identify unambiguously;
   unknown GPUs retain the renderer/PCI fallbacks. No subprocesses. */
static int gpu_drm_fast(char *out,size_t cap){
#ifdef __linux__
 DIR *dir=opendir("/sys/class/drm");
 if(!dir)return 0;
 struct dirent *entry;
 while((entry=readdir(dir))!=NULL){
  if(strncmp(entry->d_name,"card",4)!=0)continue;
  const char *p=entry->d_name+4;
  if(!isdigit((unsigned char)*p))continue;
  while(isdigit((unsigned char)*p))p++;
  if(*p)continue; /* skip card0-DP-1 connectors */
  char file[PATH_MAX],buf[64];unsigned vendor=0,device=0;
  if(snprintf(file,sizeof file,"/sys/class/drm/%s/device/vendor",entry->d_name)>=(int)sizeof file)continue;
  FILE *f=fopen(file,"r");if(!f)continue;
  if(fgets(buf,sizeof buf,f))vendor=(unsigned)strtoul(buf,NULL,0);
  fclose(f);
  if(snprintf(file,sizeof file,"/sys/class/drm/%s/device/device",entry->d_name)>=(int)sizeof file)continue;
  f=fopen(file,"r");if(!f)continue;
  if(fgets(buf,sizeof buf,f))device=(unsigned)strtoul(buf,NULL,0);
  fclose(f);
  /* Navi 22: 0x73df is shared by several board variants. */
  if(vendor==0x1002 && device==0x73df){
   snprintf(out,cap,"AMD Radeon RX 6700 series (Navi 22)");
   closedir(dir);return 1;
  }
 }
 closedir(dir);
#else
 (void)out;(void)cap;
#endif
 return 0;
}
static void gpu_short_uncached(char *out,size_t cap){
 if(gpu_drm_fast(out,cap))return;
 char line[1024]="",raw[512]="";
 /* Renderer can distinguish cards sharing the same PCI device ID. */
 command_first("LC_ALL=C glxinfo -B 2>/dev/null | grep -m1 'OpenGL renderer string:'",line,sizeof line);
 if(*line){
  char *p=strchr(line,':');
  if(p){p++;while(isspace((unsigned char)*p))p++;
   char *end=strstr(p," (");if(end)*end=0;
   if(strstr(p,"Radeon RX ") || strstr(p,"GeForce ") || strstr(p,"Arc ")){
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C vulkaninfo --summary 2>/dev/null | grep -m1 'deviceName[[:space:]]*='",line,sizeof line);
 if(*line){
  char *p=strchr(line,'=');if(p){p++;while(isspace((unsigned char)*p))p++;
   if(strstr(p,"Radeon RX ")||strstr(p,"GeForce ")||strstr(p,"Arc ")){
    char *end=strstr(p," (");if(end)*end=0;
    snprintf(out,cap,"%s",p);return;
   }
  }
 }
 command_first("LC_ALL=C lspci -mm 2>/dev/null | grep -Ei 'VGA compatible controller|3D controller|Display controller' | head -n 1",line,sizeof line);
 char *parts[8]={0};int n=0;
 for(char *p=line;*p&&n<8;){
  if(*p!='"'){p++;continue;}p++;parts[n++]=p;
  char *end=strchr(p,'"');if(!end)break;*end=0;p=end+1;
 }
 if(n>=3)snprintf(raw,sizeof raw,"%s",parts[2]);
 else if(n>=2)snprintf(raw,sizeof raw,"%s",parts[n-1]);
 else {snprintf(out,cap,"Unavailable (pciutils)");return;}
 /* Ambiguous PCI identifiers are displayed as a family, not a guessed SKU. */
 if(strstr(raw,"6700/6700 XT/6750 XT") || strstr(raw,"6800M/6850M XT")){
  snprintf(out,cap,"AMD Radeon RX 6700 series (Navi 22)");return;
 }
 const char *mark=strstr(raw,"[Radeon ");
 if(mark){mark++;char *end=strchr((char*)mark,']');if(end)*end=0;snprintf(out,cap,"AMD %s",mark);}
 else snprintf(out,cap,"%s",raw);
}
static void gpu_short(char *out,size_t cap){
 if(cache_read("gpu",out,cap,86400))return;
 gpu_short_uncached(out,cap);
 if(*out && !strstr(out,"Unavailable"))cache_write("gpu",out);
}
/* Shorten only the ambiguous GPU model, never the temperature suffix. */
static void fit_gpu(char *gpu,size_t cap,int max_visible){
 const char *suffix=strrchr(gpu,'(');
 if(!suffix || suffix==gpu || suffix[-1]!=' ')return;
 size_t base=(size_t)(suffix-gpu)-1;
 int suffix_width=0;
 for(const char *p=suffix;*p;){
  if(p[0]==27 && p[1]=='['){p+=2;while(*p && *p!='m')p++;if(*p)p++;}
  else {unsigned char c=(unsigned char)*p;p+=c>=240?4:c>=224?3:c>=192?2:1;suffix_width++;}
 }
 int keep=max_visible-suffix_width-1;
 if(keep<4)return;
 if((int)base<=keep)return;
 char result[512];
 int n=keep-3;
 if(n<1)return;
 snprintf(result,sizeof result,"%.*s... %s",n,gpu,suffix);
 snprintf(gpu,cap,"%.*s",(int)(cap-1),result);
}
/* Clip by terminal cell width, not UTF-8 byte length. Never split a codepoint
   or a CSI color sequence. Control characters from system metadata are dropped. */
static void clip_ansi(const char *src,char *dst,size_t cap,int limit){
 size_t i=0,j=0;int cells=0;
 mbstate_t state={0};
 while(src[i] && j+8<cap && cells<limit){
  if((unsigned char)src[i]==27){
   if(src[i+1]=='['){
    size_t start=i++;i++;
    while(src[i] && (unsigned char)src[i]>=0x20 && (unsigned char)src[i]<=0x3f)i++;
    if(src[i]=='m'){
     size_t n=++i-start;
     if(output_color && j+n+5<cap){memcpy(dst+j,src+start,n);j+=n;}
    }else if(src[i])i++;
   }else i++;
   continue;
  }
  wchar_t wc;size_t n=mbrtowc(&wc,src+i,MB_CUR_MAX,&state);
  if(n==(size_t)-1 || n==(size_t)-2 || n==0){memset(&state,0,sizeof state);i++;continue;}
  int width=wcwidth(wc);
  if(width<0){i+=n;continue;}
  if(cells+width>limit)break;
  if(j+n+5>=cap)break;
  memcpy(dst+j,src+i,n);j+=n;i+=n;cells+=width;
 }
 if(output_color&&j+4<cap){memcpy(dst+j,"\033[0m",4);j+=4;}
 dst[j]=0;
}


static void read_first(const char *path,char *out,size_t cap){
 out[0]=0;FILE *f=fopen(path,"r");if(!f)return;
 if(fgets(out,(int)cap,f))trim(out);
 fclose(f);
}
static void read_first(const char *path,char *out,size_t cap);
static void meminfo_numbers(unsigned long long *total,unsigned long long *available){
 *total=*available=0;FILE *f=fopen("/proc/meminfo","r");if(!f)return;
 char line[256];while(fgets(line,sizeof line,f)){
  unsigned long long n;
  if(sscanf(line,"MemTotal: %llu",&n)==1)*total=n;
  else if(sscanf(line,"MemAvailable: %llu",&n)==1)*available=n;
 }fclose(f);
}
/* Additional modules use kernel files directly: no subprocesses, so custom
   module configurations keep the same fast startup characteristics. */
static unsigned long long read_ull_file(const char *path){
 char value[96]="";read_first(path,value,sizeof value);
 if(!*value)return 0;
 errno=0;char *end=NULL;unsigned long long result=strtoull(value,&end,10);
 return errno||end==value?0:result;
}
static void gpu_hwmon_value(const char *key,char *out,size_t cap){
 DIR *d=opendir("/sys/class/drm");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(strncmp(e->d_name,"card",4))continue;
  const char *suffix=e->d_name+4;
  if(!*suffix)continue;
  while(*suffix&&isdigit((unsigned char)*suffix))suffix++;
  if(*suffix)continue; /* exclude connectors such as card0-HDMI-A-1 */
  char path[PATH_MAX];
  if(snprintf(path,sizeof path,"/sys/class/drm/%s/device/%s",e->d_name,key)>=(int)sizeof path)continue;
  read_first(path,out,cap);
  if(*out)break;
 }
 closedir(d);
}
static void gpu_driver(char *out,size_t cap){
 DIR *d=opendir("/sys/class/drm");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  const char *suffix=e->d_name;
  if(strncmp(suffix,"card",4))continue;
  suffix+=4;if(!isdigit((unsigned char)*suffix))continue;
  while(isdigit((unsigned char)*suffix))suffix++;
  if(*suffix)continue;
  char path[PATH_MAX],target[PATH_MAX];
  if(snprintf(path,sizeof path,"/sys/class/drm/%s/device/driver",e->d_name)>=(int)sizeof path)continue;
  ssize_t n=readlink(path,target,sizeof target-1);
  if(n<=0)continue;
  target[n]=0;const char *last=strrchr(target,'/');
  snprintf(out,cap,"%.127s",last?last+1:target);break;
 }
 closedir(d);
}
static void battery_cycles(char *out,size_t cap){
 DIR *d=opendir("/sys/class/power_supply");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX],type[48]="";
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);
  read_first(path,type,sizeof type);if(strcmp(type,"Battery"))continue;
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/cycle_count",e->d_name);
  read_first(path,out,cap);if(*out)break;
 }
 closedir(d);
}
static void battery_health(char *out,size_t cap){
 DIR *d=opendir("/sys/class/power_supply");if(!d)return;
 struct dirent *e;
 while((e=readdir(d))){
  if(e->d_name[0]=='.')continue;
  char path[PATH_MAX],type[64]="";
  snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);
  read_first(path,type,sizeof type);if(strcmp(type,"Battery"))continue;
  const char *parts[][2]={{"energy_full","energy_full_design"},{"charge_full","charge_full_design"}};
  for(size_t i=0;i<sizeof parts/sizeof parts[0];i++){
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/%s",e->d_name,parts[i][0]);
   unsigned long long full=read_ull_file(path);
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/%s",e->d_name,parts[i][1]);
   unsigned long long design=read_ull_file(path);
   if(full&&design){snprintf(out,cap,"%.0f%%",100.0*(double)full/design);break;}
  }
  if(*out)break;
 }
 closedir(d);
}
static void xdg_default(const char *key,const char *suffix,char *out,size_t cap){
 const char *e=getenv(key);if(e&&*e){snprintf(out,cap,"%s",e);return;}
 const char *home=getenv("HOME");if(home&&*home)snprintf(out,cap,"%s/%s",home,suffix);
}
static void os_release_version(char *out,size_t cap){
 FILE *f=fopen("/etc/os-release","r");if(!f)return;
 char line[512],version[256]="",id[128]="";
 while(fgets(line,sizeof line,f)){
  char *v=NULL;
  if(!strncmp(line,"VERSION_ID=",11))v=line+11;
  else if(!strncmp(line,"VERSION=",8)&&!*version)v=line+8;
  else if(!strncmp(line,"ID=",3)){
   v=line+3;size_t n=strcspn(v,"\r\n");v[n]=0;snprintf(id,sizeof id,"%.127s",v);continue;
  }
  if(v){size_t n=strcspn(v,"\r\n");v[n]=0;if(*v=='\"'){v++;n=strlen(v);if(n&&v[n-1]=='\"')v[n-1]=0;}if(*v)snprintf(version,sizeof version,"%.255s",v);}
 }fclose(f);
 if(*version)snprintf(out,cap,"%s",version);
 else if(!strcmp(id,"arch")||!strcmp(id,"artix")||!strcmp(id,"gentoo"))snprintf(out,cap,"Rolling Release");
}
static void count_file_lines(const char *path,char *out,size_t cap){
 FILE *f=fopen(path,"r");if(!f)return;unsigned long n=0;int c;
 while((c=fgetc(f))!=EOF)if(c=='\n')n++;
 fclose(f);snprintf(out,cap,"%lu",n);
}
static void proc_status_threads(char *out,size_t cap){
 FILE *f=fopen("/proc/self/status","r");if(!f)return;char line[256];
 while(fgets(line,sizeof line,f))if(!strncmp(line,"Threads:",8)){unsigned n;if(sscanf(line+8,"%u",&n)==1)snprintf(out,cap,"%u",n);break;}
 fclose(f);
}
static void root_fs_type(char *out,size_t cap){
 FILE *f=fopen("/proc/self/mountinfo","r");if(!f)return;
 char line[4096];while(fgets(line,sizeof line,f)){
  char *p=line;int field=0;char *mount=NULL;
  while(*p&&field<5){while(*p==' ')p++;char *start=p;while(*p&&*p!=' ')p++;field++;if(field==5)mount=start;if(*p)*p++=0;}
  if(mount&&strcmp(mount,"/")==0){char *sep=strstr(p," - ");if(!sep)continue;sep+=3;size_t n=strcspn(sep," ");if(n>=cap)n=cap-1;memcpy(out,sep,n);out[n]=0;break;}
 }fclose(f);
}
static void proc_cpuinfo_value(const char *first,const char *second,char *out,size_t cap){
 FILE *f=fopen("/proc/cpuinfo","r");if(!f)return;
 char line[512];
 while(fgets(line,sizeof line,f)){
  char *colon=strchr(line,':');if(!colon)continue;
  *colon=0;trim(line);
  if(strcmp(line,first)&&(!second||strcmp(line,second)))continue;
  char *value=colon+1;while(isspace((unsigned char)*value))value++;
  snprintf(out,cap,"%s",value);trim(out);break;
 }
 fclose(f);
}
static unsigned count_named_entries(const char *directory,const char *prefix){
 DIR *d=opendir(directory);if(!d)return 0;
 size_t n=strlen(prefix);unsigned count=0;struct dirent *e;
 while((e=readdir(d)))if(!strncmp(e->d_name,prefix,n))count++;
 closedir(d);return count;
}
static void network_interfaces(char *out,size_t cap){
 DIR *d=opendir("/sys/class/net");if(!d)return;
 struct dirent *e;size_t pos=0;
 while((e=readdir(d))){if(e->d_name[0]=='.')continue;
  size_t n=strlen(e->d_name);
  if(pos+n+2>=cap)break;
  if(pos)out[pos++]=',';
  memcpy(out+pos,e->d_name,n);pos+=n;out[pos]=0;
 }
 closedir(d);
}
static void hwmon_fans(char *out,size_t cap){
 DIR *d=opendir("/sys/class/hwmon");if(!d)return;
 struct dirent *e;unsigned count=0;
 while((e=readdir(d))){if(strncmp(e->d_name,"hwmon",5))continue;
  char path[PATH_MAX];snprintf(path,sizeof path,"/sys/class/hwmon/%s",e->d_name);
  DIR *sub=opendir(path);if(!sub)continue;
  struct dirent *file;
  while((file=readdir(sub))){
   if(strncmp(file->d_name,"fan",3))continue;
   const char *p=file->d_name+3;while(isdigit((unsigned char)*p))p++;
   if(p>file->d_name+3&&!strcmp(p,"_input"))count++;
  }
  closedir(sub);
 }
 closedir(d);snprintf(out,cap,"%u",count);
}
static void proc_filesystems(char *out,size_t cap){
 FILE *f=fopen("/proc/filesystems","r");if(!f)return;
 char line[160];size_t len=0;
 while(fgets(line,sizeof line,f)){
  char *name=line;while(isspace((unsigned char)*name))name++;
  if(!strncmp(name,"nodev",5)&&isspace((unsigned char)name[5])){name+=5;while(isspace((unsigned char)*name))name++;}
  trim(name);size_t n=strlen(name);if(!n||len+n+2>=cap)continue;
  if(len)out[len++]=',';
  memcpy(out+len,name,n);len+=n;out[len]=0;
 }
 fclose(f);
}
static void boot_date(char *out,size_t cap){
 FILE *f=fopen("/proc/stat","r");if(!f)return;
 char line[192];
 while(fgets(line,sizeof line,f)){
  long long epoch=0;if(sscanf(line,"btime %lld",&epoch)==1&&epoch>0){
   time_t t=(time_t)epoch;struct tm tmv;
   if(localtime_r(&t,&tmv))strftime(out,cap,"%Y-%m-%d %H:%M:%S",&tmv);
   break;
  }
 }
 fclose(f);
}
static int command_available(const char *name){
 const char *path=getenv("PATH");if(!path||!*path)return 0;
 size_t nlen=strlen(name);if(!nlen||strchr(name,'/'))return 0;
 const char *p=path;
 while(*p){
  const char *end=strchr(p,':');if(!end)end=p+strlen(p);
  size_t dlen=(size_t)(end-p);char full[PATH_MAX];
  if(dlen&&dlen+nlen+2<sizeof full){
   memcpy(full,p,dlen);full[dlen]='/';memcpy(full+dlen+1,name,nlen+1);
   if(access(full,X_OK)==0)return 1;
  }
  if(!*end)break;
  p=end+1;
 }
 return 0;
}
static void optional_module(const char *name){
 if(!module_enabled(name))return;
 char v[512]="",p[512]="";
 if(!strcmp(name,"board")){motherboard(v,sizeof v);}
 else if(!strcmp(name,"bios")){read_first("/sys/class/dmi/id/bios_version",v,sizeof v);}
 else if(!strcmp(name,"chassis")){read_first("/sys/class/dmi/id/chassis_type",v,sizeof v);if(!strcmp(v,"3"))snprintf(v,sizeof v,"Desktop");else if(!strcmp(v,"9")||!strcmp(v,"10")||!strcmp(v,"14"))snprintf(v,sizeof v,"Laptop");else if(!strcmp(v,"4"))snprintf(v,sizeof v,"Low Profile Desktop");else if(!strcmp(v,"6"))snprintf(v,sizeof v,"Mini Tower");else if(!strcmp(v,"7"))snprintf(v,sizeof v,"Tower");}
 else if(!strcmp(name,"shell")){snprintf(v,sizeof v,"%s",env_or("SHELL","Unknown"));}
 else if(!strcmp(name,"processes")){struct sysinfo si;if(!sysinfo(&si))snprintf(v,sizeof v,"%u",si.procs);}
 else if(!strcmp(name,"loadavg")){read_first("/proc/loadavg",v,sizeof v);char *q=strrchr(v,' ');if(q)*q=0;}
 else if(!strcmp(name,"load1")||!strcmp(name,"load5")||!strcmp(name,"load15")){
  FILE *f=fopen("/proc/loadavg","r");
  if(f){double a,b,d;if(fscanf(f,"%lf %lf %lf",&a,&b,&d)==3){
   double n=!strcmp(name,"load1")?a:(!strcmp(name,"load5")?b:d);
   snprintf(v,sizeof v,"%.2f",n);
  }fclose(f);}
 }
 else if(!strcmp(name,"datetime")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%Y-%m-%d %H:%M:%S",&tmv);}
 else if(!strcmp(name,"timezone")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%Z",&tmv);}
 else if(!strcmp(name,"hostname")){gethostname(v,sizeof v);v[sizeof v-1]=0;}
 else if(!strcmp(name,"architecture")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"cpucores")){long n=sysconf(_SC_NPROCESSORS_ONLN);if(n>0)snprintf(v,sizeof v,"%ld",n);}
 else if(!strcmp(name,"cpufreq")){unsigned long long khz=read_khz("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");if(khz)snprintf(v,sizeof v,"%.2f GHz",khz/1000000.0);}
 else if(!strcmp(name,"cpufreqmin")||!strcmp(name,"cpufreqmax")){
  const char *file=!strcmp(name,"cpufreqmin")?"/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq":"/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq";
  unsigned long long khz=read_ull_file(file);if(khz)snprintf(v,sizeof v,"%.2f GHz",khz/1000000.0);
 }
 else if(!strcmp(name,"cpugovernor")){read_first("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor",v,sizeof v);}
 else if(!strcmp(name,"gpuusage")){gpu_hwmon_value("gpu_busy_percent",v,sizeof v);if(*v){size_t n=strlen(v);snprintf(v+n,sizeof v-n,"%%");}}
 else if(!strcmp(name,"gpudriver")){gpu_driver(v,sizeof v);}
 else if(!strcmp(name,"gpuvendor")){
  char raw[64]="";gpu_hwmon_value("vendor",raw,sizeof raw);
  if(!strcmp(raw,"0x1002"))snprintf(v,sizeof v,"AMD");
  else if(!strcmp(raw,"0x10de"))snprintf(v,sizeof v,"NVIDIA");
  else if(!strcmp(raw,"0x8086"))snprintf(v,sizeof v,"Intel");
  else if(*raw)snprintf(v,sizeof v,"%s",raw);
 }
 else if(!strcmp(name,"gpuvram")||!strcmp(name,"gpumemoryused")){
  char raw[96]="";gpu_hwmon_value(!strcmp(name,"gpuvram")?"mem_info_vram_total":"mem_info_vram_used",raw,sizeof raw);
  unsigned long long bytes=strtoull(raw,NULL,10);if(bytes)snprintf(v,sizeof v,"%.2f GiB",(double)bytes/1073741824.0);
 }
 else if(!strcmp(name,"memcached")){
  FILE *f=fopen("/proc/meminfo","r");if(f){char line[256];unsigned long long n;
   while(fgets(line,sizeof line,f))if(sscanf(line,"Cached: %llu",&n)==1){snprintf(v,sizeof v,"%.2f GiB",(double)n/1048576.0);break;}
   fclose(f);
  }
 }
 else if(!strcmp(name,"cpul3")){
  for(int i=0;i<10;i++){
   char path[160],level[32]="";
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/level",i);
   read_first(path,level,sizeof level);
   if(strcmp(level,"3"))continue;
   snprintf(path,sizeof path,"/sys/devices/system/cpu/cpu0/cache/index%d/size",i);
   read_first(path,v,sizeof v);if(*v)break;
  }
 }
 else if(!strcmp(name,"memorypressure")){
  char line[256]="";read_first("/proc/pressure/memory",line,sizeof line);
  char *avg=strstr(line,"avg10=");
  if(avg){double p=0;if(sscanf(avg,"avg10=%lf",&p)==1)snprintf(v,sizeof v,"%.2f%% (10s)",p);}
 }
 else if(!strcmp(name,"batterycycles")){battery_cycles(v,sizeof v);}
 else if(!strcmp(name,"biosdate")){read_first("/sys/class/dmi/id/bios_date",v,sizeof v);}
 else if(!strcmp(name,"batteryhealth")){battery_health(v,sizeof v);}
 else if(!strcmp(name,"androidbrand")){property("ro.product.brand",v,sizeof v);}
 else if(!strcmp(name,"androidhardware")){property("ro.hardware",v,sizeof v);}
 else if(!strcmp(name,"battery")){
  DIR *d=opendir("/sys/class/power_supply");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],typ[80]="",pct[80]="";
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/type",e->d_name);read_first(path,typ,sizeof typ);
   if(strcmp(typ,"Battery"))continue;
   snprintf(path,sizeof path,"/sys/class/power_supply/%s/capacity",e->d_name);read_first(path,pct,sizeof pct);
   if(*pct){snprintf(v,sizeof v,"%s%%",pct);break;}
  }closedir(d);}
  /* Android often hides /sys/class/power_supply from unprivileged apps.
     Termux:API is an optional fallback, never required on desktop. */
  if(!*v && is_termux() && command_available("termux-battery-status")){
   command_first("termux-battery-status 2>/dev/null | grep -m1 '\"percentage\"' | sed -n 's/.*: *\\([0-9][0-9]*\\).*/\\1%/p'",v,sizeof v);
  }
 }
 else if(!strcmp(name,"brightness")){
  DIR *d=opendir("/sys/class/backlight");
  if(d){struct dirent *e;while((e=readdir(d))){if(e->d_name[0]=='.')continue;
   char path[512],cur[80]="",max[80]="";
   snprintf(path,sizeof path,"/sys/class/backlight/%s/brightness",e->d_name);read_first(path,cur,sizeof cur);
   snprintf(path,sizeof path,"/sys/class/backlight/%s/max_brightness",e->d_name);read_first(path,max,sizeof max);
   long a=atol(cur),b=atol(max);if(b>0){snprintf(v,sizeof v,"%ld%%",a*100/b);break;}
  }closedir(d);}
 }
 else if(!strcmp(name,"bluetooth")){command_first("bluetoothctl list 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"network")){command_first("ip route show default 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"diskusage")){disk_path("/",v,sizeof v);}
 else if(!strcmp(name,"diskfilesystem")){root_fs_type(v,sizeof v);}
 else if(!strcmp(name,"termux")){if(is_termux())snprintf(v,sizeof v,"Termux");}
 else if(!strcmp(name,"androidversion")){property("ro.build.version.release",v,sizeof v);}
 else if(!strcmp(name,"androidsdk")){property("ro.build.version.sdk",v,sizeof v);}
 else if(!strcmp(name,"androidmanufacturer")){property("ro.product.manufacturer",v,sizeof v);}
 else if(!strcmp(name,"androidmodel")){property("ro.product.model",v,sizeof v);}
 else if(!strcmp(name,"androidsoc")){property("ro.soc.model",v,sizeof v);}
 else if(!strcmp(name,"bootid")){read_first("/proc/sys/kernel/random/boot_id",v,sizeof v);}
 else if(!strcmp(name,"virtualization")){command_first("systemd-detect-virt 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"editor")){snprintf(v,sizeof v,"%s",env_or("EDITOR","Unknown"));}
 else if(!strcmp(name,"users")){command_first("who 2>/dev/null | wc -l",v,sizeof v);}
 else if(!strcmp(name,"language")){snprintf(v,sizeof v,"%s",env_or("LANG","Unknown"));}

 else if(!strcmp(name,"distro")){osname(v,sizeof v);}
 else if(!strcmp(name,"osversion")){os_release_version(v,sizeof v);}
 else if(!strcmp(name,"kernelversion")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.release);}
 else if(!strcmp(name,"kernelarch")){struct utsname u;if(!uname(&u))snprintf(v,sizeof v,"%s",u.machine);}
 else if(!strcmp(name,"machineid")){read_first("/etc/machine-id",v,sizeof v);}
 else if(!strcmp(name,"cpuvendor")){proc_cpuinfo_value("vendor_id","CPU implementer",v,sizeof v);}
 else if(!strcmp(name,"cpumodel")){cpuinfo(v,sizeof v);}
 else if(!strcmp(name,"cpubogomips")){proc_cpuinfo_value("bogomips",NULL,v,sizeof v);}
 else if(!strcmp(name,"cpuload")){read_first("/proc/loadavg",v,sizeof v);char *q=strchr(v,' ');if(q){q=strchr(q+1,' ');if(q){q=strchr(q+1,' ');if(q)*q=0;}}}
 else if(!strcmp(name,"memtotal")||!strcmp(name,"memavailable")||!strcmp(name,"swaptotal")||!strcmp(name,"swapfree")){
  struct sysinfo si;if(!sysinfo(&si)){unsigned long long n=0;
   if(!strcmp(name,"memtotal"))n=(unsigned long long)si.totalram*si.mem_unit;
   if(!strcmp(name,"memavailable")){unsigned long long a=0,t=0;meminfo_numbers(&t,&a);n=a?a*1024ULL:(unsigned long long)si.freeram*si.mem_unit;}
   if(!strcmp(name,"swaptotal"))n=(unsigned long long)si.totalswap*si.mem_unit;
   if(!strcmp(name,"swapfree"))n=(unsigned long long)si.freeswap*si.mem_unit;
   snprintf(v,sizeof v,"%.2f GiB",(double)n/1073741824.0);}}
 else if(!strcmp(name,"diskfree")||!strcmp(name,"disktotal")||!strcmp(name,"diskpercent")){
  struct statvfs fs;if(!statvfs("/",&fs)){double total=(double)fs.f_blocks*fs.f_frsize,freeb=(double)fs.f_bavail*fs.f_frsize;
   if(!strcmp(name,"diskfree"))snprintf(v,sizeof v,"%.2f GiB",freeb/1073741824.0);
   if(!strcmp(name,"disktotal"))snprintf(v,sizeof v,"%.2f GiB",total/1073741824.0);
   if(!strcmp(name,"diskpercent")&&total>0)snprintf(v,sizeof v,"%.1f%%",(total-freeb)*100.0/total);}}
 else if(!strcmp(name,"rootfs")){root_fs_type(v,sizeof v);}
 else if(!strcmp(name,"mounts")){count_file_lines("/proc/mounts",v,sizeof v);}
 else if(!strcmp(name,"interfaces")){network_interfaces(v,sizeof v);}
 else if(!strcmp(name,"ipv4")){command_first("ip -4 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"ipv6")){command_first("ip -6 -o addr show scope global 2>/dev/null | awk 'NR==1{print $4}'",v,sizeof v);}
 else if(!strcmp(name,"gateway")){command_first("ip route show default 2>/dev/null | awk 'NR==1{print $3}'",v,sizeof v);}
 else if(!strcmp(name,"dns")){command_first("awk '/^nameserver/{print $2;exit}' /etc/resolv.conf 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"username")){snprintf(v,sizeof v,"%s",env_or("USER","Unknown"));}
 else if(!strcmp(name,"uid")){snprintf(v,sizeof v,"%lu",(unsigned long)getuid());}
 else if(!strcmp(name,"gid")){snprintf(v,sizeof v,"%lu",(unsigned long)getgid());}
 else if(!strcmp(name,"home")){snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"path")){snprintf(v,sizeof v,"%.200s",env_or("PATH","Unknown"));}
 else if(!strcmp(name,"shellversion")){command_first("${SHELL:-/bin/sh} --version 2>/dev/null | head -n 1",v,sizeof v);}
 else if(!strcmp(name,"terminaltype")){snprintf(v,sizeof v,"%s",env_or("TERM","Unknown"));}
 else if(!strcmp(name,"displayserver")){snprintf(v,sizeof v,"%s",env_or("XDG_SESSION_TYPE","Unknown"));}
 else if(!strcmp(name,"sessiondesktop")){snprintf(v,sizeof v,"%s",env_or("XDG_CURRENT_DESKTOP","Unknown"));}
 else if(!strcmp(name,"xdgconfig")){xdg_default("XDG_CONFIG_HOME",".config",v,sizeof v);}
 else if(!strcmp(name,"xdgcache")){xdg_default("XDG_CACHE_HOME",".cache",v,sizeof v);}
 else if(!strcmp(name,"xdgdata")){xdg_default("XDG_DATA_HOME",".local/share",v,sizeof v);}
 else if(!strcmp(name,"pid")){snprintf(v,sizeof v,"%ld",(long)getpid());}
 else if(!strcmp(name,"parentpid")){snprintf(v,sizeof v,"%ld",(long)getppid());}
 else if(!strcmp(name,"threads")){proc_status_threads(v,sizeof v);}
 else if(!strcmp(name,"systemd")){if(access("/run/systemd/system",F_OK)==0)snprintf(v,sizeof v,"running");}
 else if(!strcmp(name,"init")){read_first("/proc/1/comm",v,sizeof v);}
 else if(!strcmp(name,"cgroup")){read_first("/proc/self/cgroup",v,sizeof v);}
 else if(!strcmp(name,"entropy")){read_first("/proc/sys/kernel/random/entropy_avail",v,sizeof v);}
 else if(!strcmp(name,"thermalzones")){snprintf(v,sizeof v,"%u",count_named_entries("/sys/class/thermal","thermal_zone"));}
 else if(!strcmp(name,"fans")){hwmon_fans(v,sizeof v);}
 else if(!strcmp(name,"batterycount")){snprintf(v,sizeof v,"%u",count_named_entries("/sys/class/power_supply","BAT"));}
 else if(!strcmp(name,"powerstate")){command_first("cat /sys/class/power_supply/BAT0/status 2>/dev/null",v,sizeof v);}
 else if(!strcmp(name,"androiddevice")){property("ro.product.device",v,sizeof v);}
 else if(!strcmp(name,"androidboard")){property("ro.product.board",v,sizeof v);}
 else if(!strcmp(name,"androidfingerprint")){property("ro.build.fingerprint",v,sizeof v);}
 else if(!strcmp(name,"androidsecuritypatch")){property("ro.build.version.security_patch",v,sizeof v);}
 else if(!strcmp(name,"termuxprefix")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("PREFIX","Unknown"));}
 else if(!strcmp(name,"termuxhome")){if(is_termux())snprintf(v,sizeof v,"%s",env_or("HOME","Unknown"));}
 else if(!strcmp(name,"timezoneoffset")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%z",&tmv);}
 else if(!strcmp(name,"epoch")){snprintf(v,sizeof v,"%lld",(long long)time(NULL));}
 else if(!strcmp(name,"week")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%V",&tmv);}
 else if(!strcmp(name,"dayofyear")){time_t t=time(NULL);struct tm tmv;if(localtime_r(&t,&tmv))strftime(v,sizeof v,"%j",&tmv);}
 else if(!strcmp(name,"bootdate")){boot_date(v,sizeof v);}
 else if(!strcmp(name,"procversion")){read_first("/proc/version",v,sizeof v);}
 else if(!strcmp(name,"filesystems")){proc_filesystems(v,sizeof v);}
 else if(!strcmp(name,"environment")){snprintf(v,sizeof v,"%s",is_termux()?"Termux":"Linux");}
 else if(!strcmp(name,"cpuonline")||!strcmp(name,"cpuconfigured")){
  long n=sysconf(!strcmp(name,"cpuonline")?_SC_NPROCESSORS_ONLN:_SC_NPROCESSORS_CONF);
  if(n>0)snprintf(v,sizeof v,"%ld",n);
 }
 else if(!strcmp(name,"procsrunning")||!strcmp(name,"procstotal")||!strcmp(name,"loadtasks")){
  FILE *f=fopen("/proc/loadavg","r");
  if(f){char line[128];if(fgets(line,sizeof line,f)){
   char *p=strchr(line,'/');
   if(p){char *a=p;while(a>line&&a[-1]>='0'&&a[-1]<='9')a--;
    if(!strcmp(name,"loadtasks"))snprintf(v,sizeof v,"%.*s",(int)(strchr(p,' ')?(size_t)(strchr(p,' ')-a):strlen(a)),a);
    else if(!strcmp(name,"procsrunning"))snprintf(v,sizeof v,"%.*s",(int)(p-a),a);
    else {p++;size_t n=0;while(p[n]>='0'&&p[n]<='9')n++;snprintf(v,sizeof v,"%.*s",(int)n,p);}
   }
  }fclose(f);}
 }
 else if(!strcmp(name,"memused")||!strcmp(name,"mempercent")){
  unsigned long long total=0,avail=0;meminfo_numbers(&total,&avail);
  if(total){double used=(double)(total-avail);
   if(!strcmp(name,"memused"))snprintf(v,sizeof v,"%.2f GiB",used/1048576.0);
   else snprintf(v,sizeof v,"%.1f%%",100.0*used/total);
  }
 }
 else if(!strcmp(name,"diskavailable")){
  struct statvfs fs;if(!statvfs("/",&fs))snprintf(v,sizeof v,"%.2f GiB",(double)fs.f_bavail*fs.f_frsize/1073741824.0);
 }
 else if(!strcmp(name,"uptimeseconds")||!strcmp(name,"bootepoch")){
  struct sysinfo si;if(!sysinfo(&si)){
   if(!strcmp(name,"uptimeseconds"))snprintf(v,sizeof v,"%ld",si.uptime);
   else snprintf(v,sizeof v,"%lld",(long long)time(NULL)-(long long)si.uptime);
  }
 }
 else if(!strcmp(name,"kernelhostname")){if(gethostname(v,sizeof v))v[0]=0;v[sizeof v-1]=0;}
 else if(!strcmp(name,"systemhz")){long n=sysconf(_SC_CLK_TCK);if(n>0)snprintf(v,sizeof v,"%ld Hz",n);}

 if(*v && strcmp(v,"Unknown")){
  const char *label=name;
  if(!selected_modules){
   if(!strcmp(name,"cpucores"))label="CPU Cores";
   else if(!strcmp(name,"processes"))label="Processes";
   else if(!strcmp(name,"load1"))label="Load (1m)";
  }
  snprintf(p,sizeof p,"%s:",label);int prev=ninfo;add(p,v);if(ninfo>prev)snprintf(info_id[prev],sizeof info_id[prev],"%s",name);}
}

static void reorder_info(void){
 /* Default visual grouping: CPU metrics directly below the CPU line.
    User-defined module order always takes precedence. */
 if(!*cfg_order && !selected_modules){
  int cpu_index=-1;
  for(int i=0;i<ninfo;i++)if(!strcmp(info_id[i],"cpu")){cpu_index=i;break;}
  if(cpu_index>=0){
   const char *near_cpu[]={"cpucores","processes"};
   int dest=cpu_index+1;
   for(size_t k=0;k<sizeof near_cpu/sizeof near_cpu[0];k++){
    for(int j=dest;j<ninfo;j++)if(!strcmp(info_id[j],near_cpu[k])){
     char saved[512],saved_id[64];
     memcpy(saved,info[j],sizeof saved);
     memcpy(saved_id,info_id[j],sizeof saved_id);
     for(int t=j;t>dest;t--){memcpy(info[t],info[t-1],sizeof info[t]);memcpy(info_id[t],info_id[t-1],sizeof info_id[t]);}
     memcpy(info[dest],saved,sizeof saved);
     memcpy(info_id[dest],saved_id,sizeof saved_id);
     dest++;break;
    }
   }
  }
  /* Put Load (1m) at the very bottom of the default info list,
     after Locale on desktop and after phone details in Termux. */
  for(int j=0;j<ninfo;j++)if(!strcmp(info_id[j],"load1")){
   char saved[512],saved_id[64];
   memcpy(saved,info[j],sizeof saved);
   memcpy(saved_id,info_id[j],sizeof saved_id);
   for(int t=j;t<ninfo-1;t++){
    memcpy(info[t],info[t+1],sizeof info[t]);
    memcpy(info_id[t],info_id[t+1],sizeof info_id[t]);
   }
   memcpy(info[ninfo-1],saved,sizeof saved);
   memcpy(info_id[ninfo-1],saved_id,sizeof saved_id);
   break;
  }
  return;
 }
 if(!*cfg_order)return;
 char reordered[MAX_ROWS][512];char ids[MAX_ROWS][64];
 int used[MAX_ROWS]={0},count=0;
 char copy[sizeof cfg_order];snprintf(copy,sizeof copy,"%s",cfg_order);
 for(char *name=strtok(copy,":");name;name=strtok(NULL,":")){
  for(int i=0;i<ninfo;i++)if(!used[i]&&!strcmp(name,info_id[i])){
   memcpy(reordered[count],info[i],sizeof info[i]);
   memcpy(ids[count],info_id[i],sizeof ids[count]);
   used[i]=1;count++;break;
  }
 }
 for(int i=0;i<ninfo;i++)if(!used[i]){
  memcpy(reordered[count],info[i],sizeof info[i]);
  memcpy(ids[count],info_id[i],sizeof ids[count]);count++;
 }
 for(int i=0;i<count;i++){memcpy(info[i],reordered[i],sizeof info[i]);memcpy(info_id[i],ids[i],sizeof info_id[i]);}
}
static double now_ms(void){
 struct timespec ts;
 if(clock_gettime(CLOCK_MONOTONIC,&ts))return 0;
 return (double)ts.tv_sec*1000.0+(double)ts.tv_nsec/1000000.0;
}
int main(int argc,char **argv){
 const double run_start=now_ms();
 int profile=0;
 setlocale(LC_CTYPE,"");
 static char output_buffer[262144];setvbuf(stdout,output_buffer,_IOFBF,sizeof output_buffer);
 int animate_cycles=0;int animate_preview=0;int no_logo=0,no_color=0;const char *cli_logo=NULL;const char *cli_image=NULL;const char *custom=NULL;const char *config_path=NULL;int no_config=0,check_config=0;
 for(int i=1;i<argc;i++){
  if(!strcmp(argv[i],"--no-logo"))no_logo=1;
  else if(!strcmp(argv[i],"--no-color"))no_color=1;
  else if(!strcmp(argv[i],"--profile"))profile=1;
  else if(!strcmp(argv[i],"--version")){puts("NISFETCH 3.0.0");return 0;}
  else if(!strcmp(argv[i],"--config")&&i+1<argc)config_path=argv[++i];
  else if(!strcmp(argv[i],"--no-config"))no_config=1;
  else if(!strcmp(argv[i],"--check-config"))check_config=1;
  else if(!strcmp(argv[i],"--list-logos")){list_logos();return 0;}
  else if(!strcmp(argv[i],"--logo")&&i+1<argc)cli_logo=argv[++i];
  else if(!strcmp(argv[i],"--image")&&i+1<argc)cli_image=argv[++i];
  else if(!strcmp(argv[i],"--image-backend")&&i+1<argc){
   const char *mode=argv[++i];
   if(!strcmp(mode,"auto"))image_backend=0;
   else if(!strcmp(mode,"ansi"))image_backend=1;
   else if(!strcmp(mode,"kitty"))image_backend=2;
   else if(!strcmp(mode,"konsole"))image_backend=3;
   else {fprintf(stderr,"Unknown image backend: %s (auto, kitty, konsole, ansi)\n",mode);return 2;}
  }
  else if(!strcmp(argv[i],"--animate")){animate_cycles=0;}
  else if(!strcmp(argv[i],"--animate-preview")){animate_cycles=0;animate_preview=1;}
  else if(!strcmp(argv[i],"--no-animate"))animate_cycles=-2;
  else if(!strcmp(argv[i],"--animate-cycles")&&i+1<argc){animate_cycles=atoi(argv[++i]);}
  else if(!strcmp(argv[i],"--gen-config")){
   const char *sample="{\n  // NISFETCH 3.0.0\n  \"logo\": {\"type\": \"tux\", \"image\": \"\", \"enabled\": true, \"autoScale\": true, \"width\": 0},\n  \"display\": {\"gap\": 2, \"palette\": true, \"keyColor\": \"#ffd36e\", \"valueColor\": \"#ffffff\"},\n  \"modules\": [\"title\", \"separator\", \"os\", \"host\", \"kernel\", \"uptime\", \"packages\", \"display\", \"desktop\", \"wm\", \"wmtheme\", \"theme\", \"plasmatheme\", \"icons\", \"font\", \"cursor\", \"session\", \"terminal\", \"cpu\", \"gpu\", \"memory\", \"swap\", \"disk\", \"homedisk\", \"localip\", \"locale\", \"cpucores\", \"processes\", \"load1\"]\n}\n";
   fputs(sample,stdout);return 0;
  }
  else if(!strcmp(argv[i],"--help")){puts("Usage: nisfetch [--config PATH] [--check-config] [--no-config] [--gen-config] [--logo NAME] [--image FILE.png|FILE.gif] [--image-backend auto|kitty|konsole|ansi] [--animate | --animate-preview] [--no-animate] [--animate-cycles N (0=forever)] [--list-logos] [--no-logo] [--no-color] [--modules name:name | --all] [--list-modules] [--profile] [--version]");return 0;}
  else if(!strcmp(argv[i],"--list-modules")){for(size_t j=0;j<sizeof module_names/sizeof module_names[0];j++)puts(module_names[j]);return 0;}
  else if(!strcmp(argv[i],"--all"))custom=all_modules;
  else if(!strcmp(argv[i],"--modules")&&i+1<argc)custom=argv[++i];
  else {fprintf(stderr,"Unknown option: %s\\n",argv[i]);return 2;}
 }
 output_color=!no_color&&isatty(STDOUT_FILENO)&&getenv("NO_COLOR")==NULL;
 if(!isatty(STDOUT_FILENO)&&!cli_logo&&!cli_image)no_logo=1;
 if(!no_config){
  if(config_path){if(!cfg_load(config_path,1))return 2;}
  else{
   char path[1024];const char *xdg=getenv("XDG_CONFIG_HOME"),*home=getenv("HOME");
   if(xdg&&*xdg)snprintf(path,sizeof path,"%s/nisfetch/config.jsonc",xdg);
   else if(home&&*home)snprintf(path,sizeof path,"%s/.config/nisfetch/config.jsonc",home);
   else path[0]=0;
   if(*path&&!cfg_load(path,0))return 2;
  }
 }
 if(cli_logo){
  snprintf(cfg_logo_type,sizeof cfg_logo_type,"%s",cli_logo);
  cfg_logo=1;
  if(!cli_image)cfg_image_path[0]=0; /* --logo overrides a configured image */
 }
 if(!output_color)cfg_palette=0;
 if(cli_image){snprintf(cfg_image_path,sizeof cfg_image_path,"%s",cli_image);cfg_logo=1;}
 if(!custom&&*cfg_order)custom=cfg_order;
 if(custom&&!valid_modules(custom))return 2;
 if(custom && custom!=cfg_order)cfg_order[0]=0;
 if(check_config){puts("Config OK");return 0;}
 UserImage user_image={0};
 if(!no_logo&&cfg_logo&&*cfg_image_path&&!image_load(cfg_image_path,&user_image)){
  fprintf(stderr,"Cannot decode image: %s (PNG/GIF, max 2048x2048)\n",cfg_image_path);return 2;
 }
 int has_custom_image=user_image.w>0&&user_image.h>0;
 /* Cursor query is only needed in non-fixed mode; fixed GIFs start at row 1. */
 /* Cursor position is not used in normal scrollback mode. */
 if(!no_logo&&cfg_logo&&!has_custom_image&&strcmp(cfg_logo_type,"tux")&&!find_logo(cfg_logo_type)){
  fprintf(stderr,"Unknown logo: %s (see --list-logos)\\n",cfg_logo_type);return 2;
 }
 if(cfg_gap<0)cfg_gap=0;
 if(cfg_gap>12)cfg_gap=12;
 if(cfg_logo_width<0)cfg_logo_width=0;
 if(cfg_logo_width>TUX_W)cfg_logo_width=TUX_W;
 selected_modules=custom;
 const double setup_end=now_ms();
 struct utsname u;struct sysinfo si;if(uname(&u)||sysinfo(&si)){perror("nisfetch");return 1;}
 char os[256],cpu[256],mem[128],disk[128]="",pkgs[128],tmp[512],hostname[256],board[512]="";
 char terminal[128]="",swap[128],gpu[256],display[128],theme[128],icons[128],font[256],wm[128],home_disk[128]="",wmtheme[128],cursor[128],plasma[128];
 os[0]=cpu[0]=mem[0]=pkgs[0]=0;
 if(module_enabled("os"))osname(os,sizeof os);
 if(module_enabled("cpu"))cpuinfo(cpu,sizeof cpu);
 if(module_enabled("memory"))meminfo(mem,sizeof mem);
 if(module_enabled("packages"))packages(pkgs,sizeof pkgs);
 if(gethostname(hostname,sizeof hostname))snprintf(hostname,sizeof hostname,"unknown");
 hostname[sizeof hostname-1]=0;
 struct passwd *pw=getpwuid(getuid());const char *user=env_or("USER",pw?pw->pw_name:"user");
 swap[0]=gpu[0]=display[0]=0;
 if(module_enabled("swap"))swapinfo(swap,sizeof swap);
 if(module_enabled("gpu"))gpu_short(gpu,sizeof gpu);
 if(module_enabled("display"))kde_display(display,sizeof display);
 wmtheme[0]=theme[0]=icons[0]=font[0]=cursor[0]=plasma[0]=wm[0]=0;
 if(module_enabled("wmtheme")||module_enabled("theme")||module_enabled("icons")||module_enabled("font")||module_enabled("cursor")||module_enabled("plasmatheme"))
  themeinfo(wmtheme,sizeof wmtheme,theme,sizeof theme,icons,sizeof icons,font,sizeof font,cursor,sizeof cursor,plasma,sizeof plasma);
 if(module_enabled("wm"))wm_info(wm,sizeof wm);
 if(module_enabled("homedisk"))disk_path(env_or("HOME","/"),home_disk,sizeof home_disk);
 if(output_color)snprintf(tmp,sizeof tmp,"\033[1;38;2;255;207;92m%s@%s\033[0m",user,hostname);
 else snprintf(tmp,sizeof tmp,"%s@%s",user,hostname);
 add_module("title","",tmp);
 /* Underline exactly the visible width of user@hostname. */
 size_t title_width=strlen(user)+1+strlen(hostname);
 if(title_width>100)title_width=100;
 char underline[512];size_t off=0;
 for(size_t i=0;i<title_width && off+4<sizeof underline;i++){
  memcpy(underline+off,"─",3);off+=3;
 }
 underline[off]='\0';
 add_module("separator","",underline);
 snprintf(tmp,sizeof tmp,"%s %s",os,u.machine);add_module("os","OS:",tmp);
 if(module_enabled("host"))motherboard(board,sizeof board);
 add_module("host","Host:",board);
 snprintf(tmp,sizeof tmp,"%s %s",u.sysname,u.release);add_module("kernel","Kernel:",tmp);
 long uptime_hours=si.uptime/3600, uptime_minutes=(si.uptime/60)%60;
 if(uptime_hours)snprintf(tmp,sizeof tmp,"%ld %s, %ld %s",uptime_hours,uptime_hours==1?"hour":"hours",uptime_minutes,uptime_minutes==1?"min":"mins");
 else snprintf(tmp,sizeof tmp,"%ld %s",uptime_minutes,uptime_minutes==1?"min":"mins");
 add_module("uptime","Uptime:",tmp);
 add_module("packages","Packages:",pkgs);
 add_module("display","Display:",display);
 add_module("desktop","Desktop:",is_termux()?"Android":env_or("XDG_CURRENT_DESKTOP",env_or("XDG_SESSION_DESKTOP","TTY")));
 add_module("wm","WM:",wm);
 add_module("wmtheme","WM Theme:",wmtheme);
 add_module("theme","Theme:",theme);
 add_module("plasmatheme","Plasma Theme:",plasma);
 add_module("icons","Icons:",icons);
 add_module("font","Font:",font);
 add_module("cursor","Cursor:",cursor);
 add_module("session","Session:",is_termux()?"Termux":env_or("XDG_SESSION_TYPE","TTY"));
 if(module_enabled("terminal"))terminal_name(terminal,sizeof terminal);
 add_module("terminal","Terminal:",terminal);
 if(module_enabled("cpu")){cpu_max_frequency(cpu,sizeof cpu);temp_suffix(cpu,sizeof cpu,"k10temp","coretemp");}
 if(module_enabled("gpu"))temp_suffix(gpu,sizeof gpu,"amdgpu","nouveau");
 struct winsize ws={0};
 int termcols=100,termrows=40;
 if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&ws)!=0)ioctl(STDIN_FILENO,TIOCGWINSZ,&ws);
 if(ws.ws_col>0)termcols=ws.ws_col;
 if(ws.ws_row>0)termrows=ws.ws_row;
 /* Balanced layout: logo gets ~42% of columns; text gets the majority.
    Never exceed the native 58-pixel source width (no blurry upscaling).
    Small terminals keep at least 38 columns for the info panel. */
 const DistroLogo *dlogo=has_custom_image?NULL:(strcmp(cfg_logo_type,"tux")?find_logo(cfg_logo_type):NULL);
 const unsigned char *pixlogo=dlogo?distro_pixels(cfg_logo_type):NULL;
 int allowed_width=termcols-38-cfg_gap;
 int balanced_width=(termcols*43)/100;
 int artwidth=cfg_logo_width?cfg_logo_width:balanced_width,artheight=0;
 if(artwidth>(has_custom_image?120:TUX_W))artwidth=has_custom_image?120:TUX_W;
 int show_tux=0,show_distro=0,show_pixel=0,show_image=0;
 int pix_top=0,pix_bottom=DISTRO_H;
 if(pixlogo)pixel_logo_bounds(pixlogo,&pix_top,&pix_bottom);
 /* All high-resolution logos use the exact same layout geometry as Tux. */
 if(!dlogo || pixlogo){
  int allowed_height=termrows-2;
  if(artwidth>allowed_width)artwidth=allowed_width;
  if(allowed_height>0){
   int by_height=(int)((long)allowed_height*TUX_W*2/TUX_H);
   if(artwidth>by_height)artwidth=by_height;
  }
  artheight=artwidth>0?(int)lround((double)artwidth*(has_custom_image?user_image.h:TUX_H)/(2.0*(has_custom_image?user_image.w:TUX_W))):0;
  if(artheight>allowed_height){artheight=allowed_height;artwidth=(int)lround((double)artheight*2.0*(has_custom_image?user_image.w:TUX_W)/(has_custom_image?user_image.h:TUX_H));}
  int visible=!no_logo&&cfg_logo&&artwidth>=12&&artheight>=8;
  if(!cfg_auto&&cfg_logo_width>0&&artwidth<cfg_logo_width)visible=0;
  show_tux=visible&&!pixlogo&&!has_custom_image;
  show_image=visible&&has_custom_image;
  show_pixel=visible&&pixlogo;
  if(!visible){artwidth=0;artheight=0;}
 }else{
  /* Retain legacy compact fallback for logos without supplied pixel artwork. */
  artwidth=distro_width(dlogo);
  artheight=dlogo->height;
  show_distro=!no_logo&&cfg_logo&&artwidth<=allowed_width&&artheight<=termrows;
  if(!show_distro){artwidth=0;artheight=0;}
 }
 int show_logo=show_tux||show_pixel||show_distro||show_image;
 fit_gpu(gpu,sizeof gpu,termcols-artwidth-cfg_gap-LABEL_WIDTH);
 add_module("cpu","CPU:",cpu);
 add_module("gpu","GPU:",gpu);
 add_module("memory","Memory:",mem);
 add_module("swap","Swap:",swap);
 if(module_enabled("disk"))disk_path("/",disk,sizeof disk);
 add_module("disk","Disk (/):",disk);
 add_module("homedisk",is_termux()?"Disk (HOME):":"Disk (/home):",home_disk);
 add_module("localip","Local IP:","1337.1337.1337");
 add_module("locale","Locale:",env_or("LANG","Unknown"));
 if(!selected_modules){
  optional_module("cpucores");
  optional_module("processes");
  optional_module("load1");
  if(is_termux()){
   /* Compact phone preset; optional fields disappear when unavailable. */
   static const char *phone_modules[]={
    "androidbrand","androidmanufacturer","androidmodel","androidsoc","androidversion",
    "androidsdk","androidsecuritypatch","battery","batteryhealth","batterycycles",
    "brightness","timezone"
   };
   for(size_t k=0;k<sizeof phone_modules/sizeof phone_modules[0];k++)
    optional_module(phone_modules[k]);
  }
 }
 if(selected_modules){
  for(size_t k=26;k<sizeof module_names/sizeof module_names[0];k++)
   optional_module(module_names[k]);
 }
 reorder_info();
 const double collect_end=now_ms();
 /* Pixel distro logos may use a shorter visible height to align with the text. */
 if(show_pixel && cfg_logo_width==0){
  int balanced_height=ninfo+(cfg_palette?3:0);
  if(balanced_height<22)balanced_height=22;
  if(balanced_height>artheight)balanced_height=artheight;
  if(balanced_height>termrows-3)balanced_height=termrows-3;
  if(balanced_height>=9)artheight=balanced_height;
 }
 /* Fastfetch-style: compact, consecutive info rows starting at the top. */
 size_t artrows=show_logo?(size_t)artheight:0;
 size_t rows=artrows;
 if((size_t)ninfo+(cfg_palette?3:0)>rows)rows=(size_t)ninfo+(cfg_palette?3:0);
 /* PNG: exact source bytes in Kitty or Konsole. Konsole needs a regular
    cursor placement, never the unsupported Unicode placeholders. GIFs retain
    their previous experimental Kitty implementation for compatibility. */
 int render_mode=0;
 if(show_image){
  const char *ext=strrchr(cfg_image_path,'.');
  if(ext&&!strcasecmp(ext,".png")){
   int mode=png_graphics_mode();
   if(mode&&kitty_png_render(cfg_image_path,artwidth,artheight,mode==2))render_mode=mode;
  }else if(kitty_render(cfg_image_path,&user_image,artwidth,artheight,animate_cycles))render_mode=1;
 }
 if(show_image&&!render_mode&&!user_image.rgba && !image_png_full(cfg_image_path,&user_image)){
  fprintf(stderr,"Cannot decode PNG fallback: %s\n",cfg_image_path);
  image_free(&user_image);return 2;
 }
 for(size_t i=0;i<rows;i++){
   if(show_logo){
    if(i<artrows){
     if(show_image){
      if(render_mode==1)kitty_placeholder_row((int)i,artwidth);
      else if(render_mode==2)printf("\033[%dC",artwidth);
      else image_row(&user_image,i,artwidth,artheight);
     }else if(show_tux)tux_row_scaled(i,artwidth,artheight);
     else if(show_pixel)pixel_logo_row(pixlogo,i,artwidth,artheight,pix_top,pix_bottom);
     else distro_row(dlogo,(int)i,artwidth);
    }else printf("%*s",artwidth,"");
   }
   if(i<(size_t)ninfo){
     int remaining=termcols-artwidth-(show_logo?cfg_gap:0);
     if(remaining<1)remaining=1;
     char clipped[1024];clip_ansi(info[i],clipped,sizeof clipped,remaining);
     printf("%*s%s",show_logo?cfg_gap:0,"",clipped);
   }else if(cfg_palette && (i==(size_t)ninfo+1 || i==(size_t)ninfo+2) && termcols-artwidth>=26){
     fputs("          ",stdout);
     palette_row((int)(i-(size_t)ninfo-1));
   }
   putchar('\n');
 }
 /* Restore the full terminal scroll region even if a previous hotfix
    left DECSTBM enabled.  Do not clear the screen or reposition the cursor. */
 if(show_image && !render_mode && animate_preview && animate_cycles>=0 &&
    strrchr(cfg_image_path,'.') && !strcasecmp(strrchr(cfg_image_path,'.'),".gif")){
  fflush(stdout);
  gif_preview(cfg_image_path,&user_image,artwidth,artheight,animate_cycles);
 }
 image_free(&user_image);
 /* Keep the cursor after the entire fetch; Bash starts below the artwork. */
 fputs("\n\n\n",stdout);
 /* --profile is opt-in and writes timings to stderr only. */
 if(profile){
  fflush(stdout);
  const double end=now_ms();
  fprintf(stderr,"NISFETCH profile: setup %.2f ms | collect %.2f ms | render %.2f ms | total %.2f ms\n",setup_end-run_start,collect_end-setup_end,end-collect_end,end-run_start);
 }
 return 0;
}
