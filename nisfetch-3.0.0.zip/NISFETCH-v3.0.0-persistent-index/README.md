# NISFETCH 3.0.0 — Universal Stability Release

**3.0.0 persistent package-index hotfix (version unchanged).** Arch systems
can keep the precise native/foreign split without opening all repository
databases at every launch. The foreign count is first calculated through
runtime-loaded libalpm and saved as a small persistent index in XDG_STATE_HOME.
A full pacman fallback remains for unusual or unreadable configurations.

The fast path reads installed package names from the local directory database
and searches enabled sync databases through libalpm. It tracks changes to
pacman.conf, the local database and every enabled sync database. When any of
these change, the index is invalidated and rebuilt accurately.
It does not modify the original PNG or terminal-rendering behavior.

**Made by Nisve.** NISFETCH was inspired by the idea of [Fastfetch](https://github.com/fastfetch-cli/fastfetch); its source code was **not** used in this project.

NISFETCH is a native C system-information fetch for Linux desktops and
Android/Termux. It shows a colorful system summary next to a built-in Tux,
supported distribution logo, or a custom PNG image. The ordinary shell prompt
remains below the output, with no resident background process required.

## Highlights of 3.0.0

- **Safer cache:** updates are written to a private temporary file and
  atomically renamed. Multiple terminals opening simultaneously can no longer
  read a half-written cache value.
- **Faster Linux package counting:** native scans for pacman, dpkg and apk,
  native Gentoo Portage folder counting, and single-process RPM/XBPS/pkg
  queries without a `grep | wc` pipeline.
- **Termux-aware:** hides KDE/desktop/GPU fields that do not belong in a phone
  preset, finds Android brand, model, SoC, version and security patch if the
  OS allows access, and reads installed packages directly from Termux's dpkg
  status file. Android property lookup uses Bionic's native API where possible
  or **one** getprop snapshot rather than separate commands for each property.
- **Broader desktops:** knows KDE Plasma/KWin, GNOME/Mutter, Cinnamon/Muffin,
  MATE/Marco, Xfce/Xfwm4, Hyprland, Sway, niri, i3, COSMIC, labwc, river and
  Wayfire. KDE-only settings are omitted on other desktops when using the
  default module list; they remain selectable explicitly.
- **Accurate display fallback:** Wayland without a compatible output detector
  says "Wayland" rather than reporting an XWayland virtual display as a real
  monitor resolution. KDE/X11 no longer gets mislabeled as Wayland.
- **Clean scripts:** redirected output is plain text by default, without color
  escape sequences, a huge logo or an ANSI palette. Use `--no-color` on a TTY
  to request monochrome output manually.
- **Better CLI precedence:** `--image` and `--logo` override stored image
  settings; `--no-logo` skips image decoding entirely; `--check-config`
  validates configuration without requiring an image file to be present.
- **Install safety:** build in a temporary directory, keep a uniquely named
  copy of the previous executable, and atomically install the new binary.
  Existing 2.9.x configurations are supported.
- **PNG and logos unchanged in spirit:** native PNG bytes in Kitty and Konsole,
  terminal-safe ANSI fallback elsewhere, smooth transparent distro logos and
  the original large Tux layout. GIF remains experimental and is not the
  focus of this release.

## Modules

`nisfetch --list-modules` shows **146 registered modules**. The standard KDE
desktop layout requests **29**, including CPU cores, processes and load.
Phone and non-KDE defaults are adaptive, so the number actually displayed can
be lower depending on which fields are available.

Among the available optional modules are `gpudriver`, `gpuvendor`, `cpul3`,
`memorypressure`, `batterycycles`, `biosdate`, `androidbrand`,
`androidhardware`, `androidsecuritypatch`, `gpuusage`, `gpuvram`, `memcached`,
`cpugovernor`, `ipv4`, `interfaces`, `battery` and `brightness`.

```bash
nisfetch --no-logo --modules os:cpu:cpucores:cpul3:gpu:gpudriver:memory:memorypressure:battery:batteryhealth:packages
```

## Install on Arch Linux

Download `NISFETCH-v3.0.0-persistent-index.zip` into `~/Загрузки` and run:

```bash
sudo pacman -S --needed gcc libpng giflib zlib unzip
cd ~/Загрузки
unzip NISFETCH-v3.0.0-persistent-index.zip
cd NISFETCH-v3.0.0-persistent-index
sh install.sh
nisfetch --version
```

The installer detects `cc`, `clang` or `gcc`, and also accepts the `CC`
environment variable. It installs to `~/.local/bin/nisfetch` on normal Linux,
or `$PREFIX/bin/nisfetch` in Termux.

Every replacement preserves the previous binary as a uniquely named file
like `nisfetch.backup.A1B2C3D4` in the same destination folder. The installer
prints the exact backup path.
On Arch, installation also prepares the package index once, so normal first
terminal launches do not have to decompress all Pacman sync databases.

## Install on Termux / Android

In Termux, first make sure you have the ZIP in a readable directory. For a
file in Android's Downloads directory, grant storage access if needed:

```bash
termux-setup-storage
pkg update
pkg install clang libpng giflib zlib unzip
cd ~/storage/downloads
unzip NISFETCH-v3.0.0-persistent-index.zip
cd NISFETCH-v3.0.0-persistent-index
sh install.sh
nisfetch --version
```

If the archive is somewhere else, change the `cd` path to that directory.
Termux:API and its Android companion app are **optional**; some restricted
battery fields may not be available without them. The program does not require
root permissions or assume a desktop environment on a phone.

## Other distributions

The source is designed for Linux using C11, libc, libpng, giflib, zlib and libdl. The
package name of the corresponding development headers varies by distribution.
Install a C compiler and those development libraries, then run:

```bash
sh install.sh
nisfetch --version
```

Native package counting supports Arch-family systems (pacman), Debian/Ubuntu
(dpkg), Alpine (apk), Gentoo (Portage), plus command-based RPM, XBPS and pkg
families when their package managers are available. Other distributions can
still display OS, kernel, CPU, memory, uptime and other general Linux fields;
unsupported specific fields are omitted or marked unavailable. Support for
every configuration cannot be guaranteed without testing on that device.

## PNG instead of Tux

```bash
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png'
```

The default backend chooses Kitty's scrollback-linked Unicode placeholders,
Konsole's physical graphics placement, or a truecolor ANSI fallback. You can
override the choice:

```bash
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png' --image-backend konsole
nisfetch --image '/home/nisve/Загрузки/Telegram Desktop/1789823484807.png' --image-backend ansi
```

PNG bytes are transferred unmodified when native graphics are available;
the terminal itself decides the final on-screen pixel scaling. Konsole's
actual scrollback and resize behavior depends on the version of Konsole.
On Termux and non-graphics terminals, the image falls back to ANSI half-block
characters and is necessarily limited by terminal-cell resolution.

Animated GIF remains a legacy **experimental** feature. This major release
does not claim animated GIF support across Konsole or other terminals.

## Configuration and testing

```bash
nisfetch --no-config
nisfetch --gen-config
nisfetch --list-logos
nisfetch --list-modules | wc -l
nisfetch --no-logo --no-color --modules os:kernel:cpu:memory:packages
nisfetch --profile
hyperfine -N --warmup 30 --runs 200 "$HOME/.local/bin/nisfetch" fastfetch
```

The ZIP includes Python/Pillow-based regression tests:

```bash
python -m unittest discover -s tests -v
```

Set `NISFETCH_BIN` to the compiled executable for test runs when it is not yet
installed; the Python tests also require Pillow (`python-pillow` on Arch).

Caching keeps repeat launches fast, while the first uncached run can still be
slower due to package-manager, GPU and monitor probes. Performance claims
should be measured on the same system with the same configured modules.
The persistent index logic passes a mocked libalpm regression test, but real
Arch speeds still need checking on the target device.

### Arch AUR index and honest benchmarking

For Arch, the verified foreign count is persisted at
`~/.local/state/nisfetch/pacman-foreign.index` (or below `XDG_STATE_HOME`).
That file survives deletion of `~/.cache/nisfetch`. It is checked against
local and sync package DB metadata, including nanosecond timestamps and sizes,
so package transactions invalidate it. First index creation or a DB change
still incurs the full libalpm classification cost. It is a prepared index,
**not** a faster truly empty-cache repository scan.

Clearing only `~/.cache/nisfetch` benchmarks a cache-cleared launch with the
prepared index. For a genuinely unindexed run, also remove the exact index
file or move it temporarily out of the way, then restore it.

```bash
# Cache-cleared, but with the persistent package index retained:
hyperfine -N --warmup 0 --runs 30 \
  --prepare 'rm -rf "$HOME/.cache/nisfetch"' \
  "$HOME/.local/bin/nisfetch --no-config --no-logo --modules os:kernel:cpu:gpu:memory:packages"

# Recompute foreign package classification after package DB changes:
nisfetch --no-config --no-logo --modules packages --profile
```

Use the same module set when comparing to Fastfetch, and be explicit about
whether the persistent index is present.

## Privacy and license

The default `Local IP` value remains the screenshot-friendly
`1337.1337.1337`; request `ipv4` or `interfaces` explicitly to inspect actual
network details. Sensitive modules such as `machineid` and `bootid` are
optional, not part of the default preset.

The code is released under the **MIT License**; see [LICENSE](LICENSE).
Distribution names and logos may be trademarks of their respective owners.

**Made by Nisve.**
